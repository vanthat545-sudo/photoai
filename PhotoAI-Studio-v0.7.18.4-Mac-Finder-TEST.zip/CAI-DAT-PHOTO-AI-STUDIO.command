#!/bin/bash
# Photo AI Studio v0.7.18.4 -- visible Finder installer fallback.
# Does NOT overwrite projects, personal photos or other app installations.
set -Eeuo pipefail
export PATH="$HOME/.cargo/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
cd "$HOME" || exit 1
SELF_DIR="$(cd "$(dirname "$0")" && pwd -P)"
SOURCE="$SELF_DIR/Cai-PhotoAI-Studio.app/Contents/Resources/Source"
CACHE_ROOT="$HOME/Library/Caches/PhotoAIStudioInstaller"
LOG_DIR="$HOME/Desktop"
if [[ ! -d "$LOG_DIR" || ! -w "$LOG_DIR" ]]; then LOG_DIR="$HOME/Library/Logs"; fi
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/PHOTOAI-V0718-INSTALL-LOG.txt"
# Show output in Terminal while keeping a copy outside of any temporary directory.
exec > >(tee "$LOG") 2>&1
WORK=''
cleanup() {
  if [[ -n "$WORK" && "$WORK" == "$CACHE_ROOT"/build.* && -d "$WORK" && ! -L "$WORK" ]]; then
    rm -rf -- "$WORK" || true
  fi
}
finish() {
  status=$?
  trap - EXIT
  if [[ $status -ne 0 ]]; then
    printf '\n❌ CÀI ĐẶT CHƯA ĐẠT (mã lỗi %s). Không xóa ứng dụng cũ.\n' "$status"
    printf 'Hãy gửi tệp nhật ký: %s\n' "$LOG"
  else
    printf '\n✅ BỘ CÀI ĐÃ CHẠY XONG. Kiểm tra ứng dụng Photo AI Studio vừa mở.\n'
  fi
  cleanup
}
trap finish EXIT
printf '\n=== PHOTO AI STUDIO v0.7.18.4 - BỘ CÀI HIỂN THỊ TIẾN TRÌNH ===\n'
printf 'Nhật ký: %s\n' "$LOG"
printf 'Nguồn mã: %s\n\n' "$SOURCE"
if [[ "$(uname -s)" != 'Darwin' ]]; then
  echo 'Bộ cài này chỉ dành cho macOS.'
  exit 1
fi
if [[ ! -f "$SOURCE/BUILD-PREVIEW-MAC.command" || ! -f "$SOURCE/Cargo.toml" ]]; then
  echo 'Không tìm thấy mã nguồn trong thư mục .app. Hãy giải nén trọn bộ ZIP trước khi mở.'
  exit 1
fi
if [[ -f "$HOME/.cargo/env" ]]; then source "$HOME/.cargo/env"; fi
for tool in cargo rustc swiftc codesign plutil; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Thiếu công cụ: $tool. Chưa cài đè ứng dụng cũ."
    exit 1
  fi
done
if [[ -L "$CACHE_ROOT" ]]; then
  echo 'Thư mục cache là symbolic link. Dừng cài để tránh ghi/xóa nhầm dữ liệu.'
  exit 1
fi
mkdir -p "$CACHE_ROOT"
WORK="$(mktemp -d "$CACHE_ROOT/build.XXXXXXXX")"
printf 'Đang sao chép mã nguồn sang thư mục có quyền ghi...\n'
/usr/bin/ditto "$SOURCE" "$WORK/Source"
cd "$WORK/Source"
if [[ ! -f Cargo.toml || ! -f BUILD-PREVIEW-MAC.command ]]; then
  echo 'Sao chép mã nguồn không đầy đủ.'
  exit 1
fi
unset CARGO_TARGET_DIR || true
printf '\nĐang kiểm thử và biên dịch (có thể cần một lúc trên Mac M1).\n'
printf 'Chỉ thay ứng dụng Preview sau khi kiểm thử đạt.\n\n'
export CARGO_BUILD_JOBS=2
/bin/bash ./BUILD-PREVIEW-MAC.command
printf '\nCài đặt kết thúc, xem nhật ký ở %s\n' "$LOG"
