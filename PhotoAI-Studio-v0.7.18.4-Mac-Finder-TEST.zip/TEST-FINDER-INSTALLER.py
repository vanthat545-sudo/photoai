from pathlib import Path
import unittest, re, subprocess, plistlib
BASE=Path(__file__).resolve().parent
SCRIPT=BASE/'Cai-PhotoAI-Studio.app/Contents/MacOS/installer'
class InstallerTests(unittest.TestCase):
 def test_shell_parses(self):
  self.assertEqual(subprocess.run(['bash','-n',str(SCRIPT)], capture_output=True).returncode,0)
 def test_writable_staging_before_build(self):
  src=SCRIPT.read_text()
  self.assertIn('mktemp -d "$CACHE_ROOT/build.XXXXXXXX"',src)
  self.assertIn('/usr/bin/ditto "$BUNDLED_SOURCE" "$WORK/Source"',src)
  self.assertLess(src.index('/usr/bin/ditto "$BUNDLED_SOURCE"'),src.index('/bin/bash ./BUILD-PREVIEW-MAC.command'))
  self.assertIn('cd "$WORK/Source"',src)
  self.assertNotIn('cd "$BUNDLED_SOURCE"',src)
 def test_cleanup_only_work_dir(self):
  src=SCRIPT.read_text()
  self.assertIn('"$WORK" == "$CACHE_ROOT"/build.*',src)
  self.assertIn('! -L "$WORK"',src)
  self.assertNotIn('rm -rf "$HOME/Downloads"',src)
 def test_source_and_identity(self):
  app=BASE/'Cai-PhotoAI-Studio.app'
  self.assertTrue((app/'Contents/Resources/Source/Cargo.toml').exists())
  self.assertTrue((app/'Contents/Resources/Source/BUILD-PREVIEW-MAC.command').exists())
  with (app/'Contents/Info.plist').open('rb') as f: info=plistlib.load(f)
  self.assertEqual(info['CFBundleShortVersionString'],'0.7.18.4')
 def test_launch_gate_remains_present(self):
  build=(BASE/'Cai-PhotoAI-Studio.app/Contents/Resources/Source/BUILD-PREVIEW-MAC.command').read_text()
  self.assertIn('cargo test --locked -p photocraft-engine --lib',build)
  self.assertIn('cargo test --locked -p photocraft-ui-egui --lib',build)
  self.assertIn('LAUNCH_OK',build)
  self.assertIn('restore_previous',build)
if __name__=='__main__': unittest.main(verbosity=2)
