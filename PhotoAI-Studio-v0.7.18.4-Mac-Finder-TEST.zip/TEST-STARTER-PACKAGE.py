from pathlib import Path
import unittest,subprocess,stat
base=Path(__file__).parent
f=base/'CAI-DAT-PHOTO-AI-STUDIO.command'
s=f.read_text()
class Checks(unittest.TestCase):
 def test_shell_syntax(self):
  self.assertEqual(subprocess.call(['bash','-n',str(f)]),0)
 def test_executable(self):
  self.assertTrue(f.stat().st_mode&stat.S_IXUSR)
 def test_reads_bundled_source(self):
  self.assertIn('Cai-PhotoAI-Studio.app/Contents/Resources/Source',s)
  self.assertIn('ditto "$SOURCE" "$WORK/Source"',s)
 def test_diagnostics_visible(self):
  self.assertIn('exec > >(tee "$LOG") 2>&1',s)
 def test_cleanup_safe(self):
  self.assertIn('"$WORK" == "$CACHE_ROOT"/build.*',s)
  self.assertIn('! -L "$WORK"',s)
  self.assertNotIn('rm -rf "$HOME/Downloads"',s)
 def test_build_gated(self):
  b=(base/'Cai-PhotoAI-Studio.app/Contents/Resources/Source/BUILD-PREVIEW-MAC.command').read_text()
  self.assertIn('cargo test --locked -p photocraft-engine --lib',b)
  self.assertIn('cargo test --locked -p photocraft-ui-egui --lib',b)
  self.assertIn('LAUNCH_OK',b)
if __name__=='__main__': unittest.main(verbosity=2)
