// PhotoAI: local, offline face/landmark detection using Apple's Vision framework.
// Reads: 8-byte little-endian UInt32 width + height followed by tightly packed RGBA8.
// Writes: one JSON object, normalized [left, top, right, bottom] rectangles.
// No image data leaves this process or the Mac; no network use.
import AppKit
import CoreGraphics
import Foundation
import Vision

func fail(_ reason: String) -> Never {
    let data = (try? JSONSerialization.data(withJSONObject: ["error": reason])) ?? Data("{}".utf8)
    FileHandle.standardOutput.write(data)
    exit(2)
}

let incoming = FileHandle.standardInput.readDataToEndOfFile()
guard incoming.count >= 8 else { fail("Invalid image buffer") }
func number(_ start: Int) -> Int {
    return (0..<4).reduce(0) { acc, index in
        acc | (Int(incoming[start + index]) << (8 * index))
    }
}
let width = number(0)
let height = number(4)
guard width > 0, height > 0, width <= 8000, height <= 8000,
      width <= 13_000_000 / height,
      incoming.count == 8 + width * height * 4 else { fail("Image size invalid or exceeds 13 million pixels") }

let pixels = incoming.subdata(in: 8..<incoming.count)
guard let provider = CGDataProvider(data: pixels as CFData),
      let image = CGImage(
          width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
          bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
          provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent
      ) else { fail("Could not decode RGBA image") }

let request = VNDetectFaceLandmarksRequest()
let handler = VNImageRequestHandler(cgImage: image, options: [:])
do { try handler.perform([request]) }
catch { fail("Vision face detection failed: \(error.localizedDescription)") }

func bounds(_ normalized: CGRect) -> [Double] {
    // Apple Vision origins are lower left; PhotoAI raster origins are upper left.
    return [Double(normalized.minX), Double(1.0 - normalized.maxY),
            Double(normalized.maxX), Double(1.0 - normalized.minY)]
}
func feature(_ points: VNFaceLandmarkRegion2D?, face: CGRect) -> [Double]? {
    guard let points = points, points.pointCount > 0 else { return nil }
    let coords = points.normalizedPoints
    let xs = coords.map { CGFloat($0.x) }
    let ys = coords.map { CGFloat($0.y) }
    guard let minX = xs.min(), let maxX = xs.max(),
          let minY = ys.min(), let maxY = ys.max() else { return nil }
    let global = CGRect(x: face.minX + face.width * minX,
                        y: face.minY + face.height * minY,
                        width: face.width * (maxX - minX),
                        height: face.height * (maxY - minY))
    return bounds(global)
}
// Ordered mouth contour points, transformed into image-normalized top-left space.
// Rectangles alone include skin and teeth; precise polygons are needed for lipstick.
func contour(_ feature: VNFaceLandmarkRegion2D?, face: CGRect) -> [[Double]]? {
    guard let feature = feature, feature.pointCount >= 6 else { return nil }
    let coords = feature.normalizedPoints
    let points = coords.map { point -> [Double] in
        let x = face.minX + face.width * CGFloat(point.x)
        let y = face.minY + face.height * CGFloat(point.y)
        return [Double(x), Double(1.0 - y)]
    }
    guard points.allSatisfy({ $0.allSatisfy { $0.isFinite && $0 >= 0 && $0 <= 1 } }) else { return nil }
    return points
}
let results: [[String: Any]] = (request.results ?? []).prefix(8).map { face in
    let b = face.boundingBox
    var result: [String: Any] = ["box": bounds(b)]
    result["leftEye"] = feature(face.landmarks?.leftEye, face: b)
    result["rightEye"] = feature(face.landmarks?.rightEye, face: b)
    result["mouth"] = feature(face.landmarks?.outerLips, face: b)
    result["outerLipsPoints"] = contour(face.landmarks?.outerLips, face: b)
    result["innerLipsPoints"] = contour(face.landmarks?.innerLips, face: b)
    return result
}
let payload: [String: Any] = ["faces": results, "model": "Apple Vision face landmarks", "version": 1]
let data = (try? JSONSerialization.data(withJSONObject: payload)) ?? Data("{}".utf8)
FileHandle.standardOutput.write(data)
