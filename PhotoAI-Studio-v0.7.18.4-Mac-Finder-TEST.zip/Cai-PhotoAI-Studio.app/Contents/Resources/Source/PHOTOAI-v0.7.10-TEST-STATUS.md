# Photo AI 0.7.10 — Thông báo kết quả Retouch

Bản mã nguồn chờ kiểm thử Mac, chưa phải bản app đã chạy đạt.

## Đã thay đổi
Tất cả 5 điểm gọi lệnh chỉnh ảnh trong bảng Retouch (hiệu ứng, bộ điều phối tự động và 3 vị trí gọi retouch khuôn mặt/xoá mụn) dùng chung bộ thông báo. Kết quả dựa trên so sánh tài liệu thực tế trước và sau, không tin riêng bộ đếm pixel của công cụ.
- THÀNH CÔNG: ảnh thật sự thay đổi và không có cảnh báo.
- THẤT BẠI: lệnh trả lỗi, kèm tên chức năng và nguyên nhân. Nói ảnh giữ nguyên chỉ khi so sánh xác nhận; nếu đã đổi trước lỗi thì nhắc kiểm tra/hoàn tác.
- KHÔNG THAY ĐỔI: không có thay đổi tài liệu; phân biệt cường độ 0, không có mặt và các trường hợp khác.
- HOÀN TẤT CÓ LƯU Ý: ảnh đổi nhưng có bước bị bỏ qua, không có mặt hoặc báo cáo công cụ mâu thuẫn.
- CHƯA CHẠY: thao tác cần vùng chọn nhưng người dùng chưa chọn vùng.
Bổ sung khung KẾT QUẢ THAO TÁC trong Retouch, đồng thời giữ thông báo ở thanh trạng thái. Các nút bật cọ/chọn công cụ chỉ báo đã bật, không báo ảnh đã sửa.

## Kiểm thử
Đạt: kiểm tra tĩnh liên kết nguồn, 4 bài test cơ chế gate, cú pháp bộ cài, kiểm tra gói ZIP. Các bài này không chạy engine.
Thêm 5 Rust test: không đổi ảnh dù bộ đếm giả; cường độ 0 ưu tiên hơn không có mặt; nhận diện no-face ở lệnh trực tiếp và workflow; cảnh báo/không nhất quán không báo thành công toàn bộ; lệnh lỗi gắn cờ và tên chức năng.
5 test mới CHƯA CHẠY, cũng như 7 test workflow trước đó. Gate thực tế dừng vì thiếu Cargo. Chưa compile/UI/macOS/Vision/ảnh chụp hay thử trên ảnh thật. Cổng phát hành tiếp tục chặn khi thiếu công cụ hoặc test lỗi.

## Giới hạn
Thông báo kết quả xuất hiện sau khi lệnh đồng bộ trả về, có thể ở khung hình kế tiếp. Chưa có xử lý nền, thanh tiến độ hoặc nút huỷ. Khung trong Retouch hiện trạng thái ứng dụng gần nhất, chưa có lịch sử riêng từng nút. Phạm vi đợt này là nút chỉnh ảnh trong Retouch, không thay đổi thông báo của toàn bộ menu khác.

## Test Mac cần làm
Bấm từng nút tự động/hiệu ứng, thử lớp khóa, ảnh không có mặt, cường độ 0, thiếu vùng chọn, helper Vision lỗi, chỉnh màu được nhưng không có mặt. Đối chiếu thông báo với ảnh thật, undo/redo; chụp màn hình khung kết quả sau thành công/thất bại. Không đánh dấu bản app hoạt động trước khi đạt.
