PHOTO AI RETOUCH 0.4 - THU NGHIEM - MAC M1

Nguon phat trien tu PhotoCraft (MIT/Apache-2.0), duy tri giay phep goc.

CHUC NANG
- Photo AI | Retouch trong panel ben phai.
- Spot Healing (thu cong) va lenh paint.autoBlemish (ban thu nghiem).
- Chon Marquee (phim M) khoanh mot vung da o ma hoac tran.
- Chon layer pixel, khong chon mask.
- Chinh Do nhay va Co not (px), nhan 'Xoa mun trong vung chon'.
- Lenh dung thuat toan phat hien dom do cuc bo; KHONG phai mo hinh AI da huan luyen.
- Ban nguon gioi han 20 not moi lan bam. Undo: Cmd+Z.
- Hieu qua tuy anh va cau truc mun, co the con thieu sot.

CAI DAT (MAC, neu DA CO Cargo/Rust tu ban truoc)
1. Giai nen ZIP trong Downloads.
2. Nhan dup vao Build-and-Install-PhotoAI-Mac.command (co the macOS yeu cau Open).
3. Chuong trinh se bien dich release va tao ~/Applications/PhotoAI.app.
4. Mo PhotoAI trong thu muc Applications cua nguoi dung.
5. Ban PhotoAI cu duoc sao luu trong ~/Applications neu trung ten.

KIEM CHUNG
- Da kiem tra lien ket nut UI -> lenh engine, va can chinh mot loi muon tham chieu trong test.
- KHONG chay cargo build/cargo test vi moi truong hien tai khong co Rust toolchain.
- CHUA KIEM THU app/macOS/Apple M1 hay chat luong tren anh thuc.
- Anh minh hoa truoc/sau trong hoi thoai duoc xu ly bang demo OpenCV Python tuong tu,
  KHONG xuat boi lenh Rust ben trong PhotoAI; khong coi la kiem thu PhotoAI 0.4.

LUU Y: Day la MA NGUON + tap lenh bien dich, KHONG phai file .app da build san.
