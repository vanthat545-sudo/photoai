# PhotoAI v0.6.1 — Sửa bảng Retouch

## Đã thay đổi trong mã
- Sửa độ mạnh: trước đây bright/under-eye/eyelid/contour bị nhân strength hai lần; giờ trộn hiệu ứng đúng một lần.
- Gọn mặt: sửa cùng lỗi strength hai lần.
- Hiển thị cảnh báo rõ khi thiếu lớp ảnh, đang chọn mask, hoặc chưa khoanh vùng.
- Bổ sung hai bài unit test: công thức pha trộn và màu son / đen trắng khác đầu vào.
- Giữ nguyên 25 preset, các công cụ chỉnh mắt, màu môi và các lệnh cũ.

## Chưa hoàn thiện / chưa kiểm chứng
- Chưa chạy `cargo test` hoặc chạy GUI trên macOS trong môi trường này.
- Auto Blemish vẫn là nhận dạng đốm đỏ trên vùng được khoanh; không nhận dạng toàn khuôn mặt bằng AI.
- Tự tách môi/mắt, xóa tóc rối, kéo dài chân, tự tạo mí mắt và tái tạo da AI chưa có engine hoạt động.
- Chức năng son môi cần chọn vùng đúng bằng Lasso.

## Thử nghiệm trên máy Mac
Biên dịch bằng script Build-and-Install-PhotoAI-Mac.command. Mở ảnh raster có nội dung, chọn layer pixel, thử preset Black & White 100%, undo, Lasso khoanh môi rồi đổi son 100%, và chỉnh sáng 50%; chụp màn hình kết quả để kiểm chứng.
