## v0.7.3 - Lip Protection Fix (experimental)
- Guard mouth/eyes during automatic brush healing; restore exact original protected pixels; guarded AI acne tile; protection toggles.

## PhotoAI v0.6.5 — Retouch thao tác dễ hơn

- Xoá mụn không yêu cầu vùng chọn (lớp raster, giới hạn 12 MP).
- Nút chọn vùng hiển thị hướng dẫn thay vì khoá im lặng.
- Icon tile và kích thước dock to hơn.
- Thêm test Rust cho tự dò mụn khi không có vùng chọn.

# Photo AI – Native Portrait Panel v0.1 (source patch)

## Đã thay đổi
- `crates/ui-egui/src/panels.rs`: bảng Photo AI tích hợp bên phải, trực tiếp chọn công cụ lõi Rust `SpotHealing`, `Healing`, `CloneStamp`, `Blur`.
- Giữ nguyên lõi xử lý ảnh và thư viện gốc.
- Chưa có AI phát hiện mụn, chưa biên dịch thành .app.

## Kiểm chứng
- Đã kiểm tra cấu trúc nguồn và vị trí tích hợp.
- Chưa chạy `cargo check`/`cargo test` vì môi trường này không có Rust toolchain.
- Chưa kiểm thử giao diện trên Mac.

## Build trên Mac
- Cài Rust toolchain, Xcode Command Line Tools và dependencies dự án theo README upstream.
- Trong thư mục nguồn chạy `cargo check -p photocraft` rồi `cargo build --release -p photocraft`.
- Chỉ thay bản đang sử dụng khi build, ký app và kiểm thử hoàn tất.

Giữ thông báo giấy phép MIT/Apache-2.0 từ bản gốc.


## v0.6.4 — Function-first Retouch
- Real localized image-processing routines: skinSmooth, flyawayHair, legLength, skinTone, blush.
- Icon-grid shortcuts in AI Beauty, previous controls accessible under advanced disclosure.
- Per-command changedPixels for honest "no change" feedback.
- Installer unique-version backup strategy.
- Not trained ML; Mac Rust compile and GUI tests pending.
