# PhotoAI v0.7.1 — vá lỗi biên dịch AI Auto Retouch

Sửa **4 lỗi E0308/E0277** tại `crates/engine/src/retouch_cmds/ai_auto_retouch.rs`, dòng 144–145 của bản v0.7:
- Chuyển độ rộng mắt `u32` sang `i32` có kiểm tra giới hạn.
- Dùng `saturating_add`/`saturating_sub` cho tọa độ, tránh số nguyên tràn.
- Bổ sung 2 bài kiểm thử đơn vị về vùng quầng thâm và giới hạn số nguyên.
- Dọn hai cảnh báo biến không dùng (`bounds` và `strength`).

Đây là bản vá **lỗi biên dịch**, **không chứng minh** chất lượng hoặc tính ổn định của Apple Vision, xoá mụn, làm mịn, và Retouch.

## Tình trạng xác minh tại thời điểm đóng gói
| Mục | Kết quả |
|---|---|
| Xác định nguyên nhân `u32`/`i32` từ `Rect::width()` | Đạt |
| So khớp mã lỗi cũ và thay thế một lần duy nhất | Đạt |
| Kiểm tra tĩnh phép toán hai tọa độ | Đạt |
| Kiểm tra `bash -n` script | Đạt |
| ZIP CRC | Đạt |
| `cargo build` | **Chưa chạy** (môi trường không có Rust) |
| `cargo test -p photocraft-engine --lib ai_auto_retouch` | **Chưa chạy** |
| Apple Vision nhận diện thực tế | **Chưa kiểm chứng** |
| Thử nghiệm trên Mac M1 và xuất ảnh | **Chưa kiểm chứng** |

## Cách sử dụng
**Cách A (đã giải nén v0.7):** tải `Sua-loi-PhotoAI-v0.7.1.command`, đặt cùng thư mục nguồn v0.7, hoặc chạy trực tiếp nếu nguồn nằm tại `~/Downloads/PhotoAI-v0.7-Auto-AI-Retouch-Source`. Script chỉ sửa đúng đoạn lỗi và gọi script build/install có sẵn. Trước khi chỉnh, nó sao lưu một bản `.pre-v071-backup`.

**Cách B:** giải nén ZIP nguồn v0.7.1 rồi chạy `Build-and-Install-PhotoAI-Mac.command` (cần Rust và Xcode Command Line Tools).

Cảnh báo thiếu `contributors/contributors.json`, `contributors/people.toml` không cản biên dịch; cửa sổ About chỉ không hiện đầy đủ tên đóng góp.
