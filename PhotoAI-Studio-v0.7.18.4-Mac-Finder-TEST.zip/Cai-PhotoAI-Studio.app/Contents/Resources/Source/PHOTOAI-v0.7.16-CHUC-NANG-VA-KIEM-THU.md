# Photo AI Studio v0.7.16 – Tình trạng thực tế

Đây là **bản nguồn tích hợp để kiểm thử trên Mac M1**, không phải bản thương mại đã chứng nhận.

| Hạng mục | Có trong mã nguồn | Cần xác nhận trên Mac/ảnh thật |
|---|---|---|
| Studio mặc định (5 nhóm) / bảng Router phải / tách bảng | Có | Chụp màn hình app thật |
| Theme dark xanh than/cyan cho Studio | Có | Render Retina và tương phản |
| Icon ống kính ngoài app / icon hacker mũ vàng rõ hơn | Có | Dock/Finder icon caching |
| Open/import, layer, crop, text, brush, undo, xuất ảnh | Nền tảng PhotoCraft | Regression, formats và dự án |
| Nhận diện mặt và viền môi Apple Vision (offline) | Có, chỉ macOS | Ảnh mặt 3/4, ánh sáng khó |
| Son môi 5 màu + custom, mặt nạ viền môi + undo | Có | Biên dịch Rust; đường viền ảnh thật |
| Xoá mụn tự động (độ nhạy) + cọ xóa mụn | Có | Khả năng sạch mụn & bảo vệ môi, mắt |
| Mịn da, sáng mặt, dưới mắt | Có, thuật toán cục bộ | Chất lượng texture/lem viền |
| 25 look màu, HSL 6 dải, Pro grade | Có | Độ thẩm mỹ, đối chiếu hình ảnh |
| 120 lựa chọn trong 10 nhóm | Có, ánh xạ vào 25 look | Không phải 120 LUT riêng |
| Mưa/tuyết, thay áo, đổi tóc AI, xoá người/đổi nền AI tự động | CHƯA CÓ | Không gắn thành công giả |

## Cổng kiểm thử

1. QA Python kiểm tra điều hướng, dây nối nút, tính toàn vẹn icon, bộ cài và chú thích.
2. `cargo test --locked -p photocraft-engine --lib` trên macOS.
3. `cargo test --locked -p photocraft-ui-egui --lib` trên macOS.
4. `swiftc` Apple Vision helper, `cargo build -p photocraft`.
5. Đóng gói, sign ad hoc, verify và chỉ thay Preview sau khi tất cả bước trên đạt.
6. Kiểm chứng ảnh thật cho xóa mụn, son và màu; chưa thực hiện ở đây.

**Ghi chú:** Môi trường tạo gói này không có Rust/macOS, nên không thể xác nhận bước 2–6. Không dùng kết quả 2.957 bài của bản trước để tuyên bố bản này đã kiểm thử đạt.
