#!/bin/bash
# Safe alias: always install the independent Preview with verified tests.
# NEVER overwrite PhotoAI.app or existing user projects.
set -euo pipefail
cd "$(dirname "$0")"
exec bash ./BUILD-PREVIEW-MAC.command
