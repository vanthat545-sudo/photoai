# PhotoAI v0.7.3 - Lip and Eye Protection

## Source changes
- Vision-guided full-image automatic acne tile replaces unprotected `paint.autoBlemish` invocation.
- Default eye and mouth protection uses enlarged rectangular mouth mask and conservative fallback if landmarks are missing.
- Every healing brush center AND footprint are checked before editing.
- Protected eye and mouth pixels are restored from the pre-edit document, even if the inpainting solver touched them.
- Advanced mode retains opt-out toggles with clear warning; **both enabled by default**.
- Result reports `skippedNearFeatures` and actual healing stroke count separately.

## Scope / limitations
- `paint.autoBlemish` remains an advanced/manual tool that is NOT Vision-guided; avoid selecting eyes/lips with it.
- Apple Vision mouth bounds are approximations; a severely occluded/turned face may need manual correction.
- This is classical redness detection / healing, not a trained acne-removal generative model.
- Test fixtures and source checks are NOT equivalent to a full macOS build / visual retouch QA.
- Actual Rust/macOS build, rendering, real face before/after still **NOT verified** in this environment.
- The source updates the separate PhotoAI Retouch app, NOT the standalone camera-icon Photo AI app.

## Current verification log
- Bash syntax: `bash -n Build-and-Install-PhotoAI-Mac.command` passed.
- Python geometry and simulated restoration checks: `python3 CHECK-TESTS-v073.py` passed.
- Static UI calls: neither automatic-retouch tile nor advanced automatic button invokes legacy `paint.autoBlemish`.
- Mac build and live photo test: **NOT RUN**.
