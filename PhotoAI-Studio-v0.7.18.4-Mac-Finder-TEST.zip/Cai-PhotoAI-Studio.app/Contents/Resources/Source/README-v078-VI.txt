PHOTOAI 0.7.8 — BẢN MÃ NGUỒN THỬ NGHIỆM

Mới: Trong Retouch có bốn nút Tự cân sáng, Tự cân bằng trắng,
Tự chỉnh tương phản, Tự động kết hợp. Dùng thanh Cường độ phía trên;
có vùng chọn thì chỉ chỉnh vùng đó. Command+Z hoàn tác một bước.
Các nút này chỉnh ánh sáng/màu, không tự xoá mụn hoặc làm mịn.

Đã sửa thêm giới hạn ảnh của nhóm chỉnh màu, xử lý cường độ 0,
bảo vệ dự phòng khi vị trí môi nhận diện bất hợp lý và kiểm tra
định danh ứng dụng trước khi thay bản cũ.

CHƯA PHẢI APP CÀI ĐỘC LẬP. Chưa biên dịch/chạy trên Mac.
Các kiểm tra tĩnh đã đạt; kiểm thử Rust và ảnh thật còn chờ.
Xem PHOTOAI-v0.7.8-TEST-STATUS.md để biết giới hạn và phần chưa xong.
