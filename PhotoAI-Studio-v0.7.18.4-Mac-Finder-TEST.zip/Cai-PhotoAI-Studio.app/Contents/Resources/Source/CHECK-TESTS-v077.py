from pathlib import Path
import zipfile, subprocess
r=Path(__file__).parent
u=(r/'crates/ui-egui/src/panels.rs').read_text()
a=(r/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
e=(r/'crates/engine/src/retouch_cmds/photo_ai_effects.rs').read_text()
checks={
'2 blemish buttons use blemishOnly true':u.count('"blemishOnly":true')>=2,
'full AI action still separate': '"mode":name' in u,
'zero-change UI reports failure':u.count('app.ui.status_error = unchanged ||')>=2,
'spot-only cannot smooth': 'if blemish_only { continue; }' in a,
'guards in blemish mode forced on': 'lips: blemish_only ||' in a and 'eyes: blemish_only ||' in a,
'no-candidate quick exit': 'if blemish_only && spots.is_empty()' in a,
'HSL UI wired': 'photo_ai_pro_hsl_panel(app, ui, has_pixels, strength)' in u and '"effect":"proHsl"' in u,
'HSL engine wired': 'else if effect == "proHsl"' in e,
'HSL command described': 'proGrade|proHsl|proSharpen' in (r/'crates/engine/src/retouch_cmds.rs').read_text(),
'0.7.7 UI version': 'PHOTO AI | RETOUCH 0.7.7' in u,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
assert all(checks.values())
p=subprocess.run(['bash','-n',str(r/'Build-and-Install-PhotoAI-Mac.command')], capture_output=True,text=True)
print('PASS bash installer syntax' if p.returncode==0 else 'FAIL '+p.stderr)
assert p.returncode==0

# Source-contract checks only; these do not run the Rust engine.
swift=(r/'native/macos/PhotoAIVision.swift').read_text()
assert 'const MAX_PIXELS: usize = 13_000_000;' in a
assert 'width <= 13_000_000 / height' in swift
assert '} else if opaque_pixel(pixels[idx]) {' in a
assert 'hole[i] = eligible && at_spot && chosen && opaque_pixel(px);' in a
assert 'source[i] = eligible && !at_spot && skin_tone(px);' in a
assert 'red_blemish_outside_skin_prior_is_healed_without_touching_surroundings' in a
print('PASS source contracts: camera pixel budget, separate target/donor masks, Rust regression present')
print('NOT RUN: Rust compilation, runtime tests, macOS Vision, native UI')
