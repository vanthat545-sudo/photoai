# PhotoAI v0.7.8 — source candidate, 2026-10-26

## Added to source
Four native Retouch actions using paint.photoAiEffects, the existing strength control and one journaled edit:
- autoExposure: median-luminance correction with bounded gain and a high-percentile highlight cap.
- autoWhiteBalance: mild channel balancing using near-neutral pixels only; leaves WB unchanged when fewer than 32 weighted neutral samples exist.
- autoContrast: bounded monotonic contrast adjustment from luminance percentiles; skips flat and already broad-range scenes.
- autoTone: combines those corrections in one pass and one undo operation.
Analysis respects selection weights, ignores transparent/non-finite pixels, and is bounded by the existing region budget. The operations preserve geometry and native alpha; no blur, acne removal or model inference is included in these new tonal actions. Corrections are conservative heuristics, not scene understanding. They may still be inappropriate for intentional lighting/color casts; use strength/undo.

## Source fixes
- Photo effects now also allow 13,000,000 pixels, consistent with the v0.7.7 retouch fix for 4032×3024 photos.
- Zero-strength photo effects return changedPixels:0 and noChange:true instead of a response the UI could treat as unmeasured success.
- Zero-strength face retouch validates the layer then exits without launching Apple Vision.
- An implausibly positioned mouth landmark now activates the existing central-lower-face fallback guard while retaining the actual landmark guard. This addresses the existing shifted-landmarks regression; it does not guarantee all landmark errors are detected.
- Effects skip non-finite pixel/selection values.
- Installer checks the existing bundle identity before moving PhotoAI.app; another app with the same name remains untouched.
- Previous v0.7.7 red-center repair and blemish-only protection remain.

## Executed checks
CHECK-TESTS-v078.py passed: source contracts for prior fixes, four UI/command/algorithm paths, presence of new regression tests, shell installer syntax. ZIP CRC passed. These are static/package checks, NOT proof of image quality or successful Rust compilation.

## Added Rust tests — NOT RUN
- Dark scene exposure, neutral cast correction, saturated scene white-balance skip.
- Transparent/invalid/excluded samples; monotonic bounded contrast.
- Each automatic action at 8/16/32-bit: selected pixels change, unselected pixels and alpha remain identical, one undo restores the document.
- Zero-strength effects and zero-strength Vision command preserve document.
- Existing mouth-placement regression retained, implementation amended.

## Blocked / not verified
No cargo/rustc or macOS framework is available here. Engine/UI compilation, clippy, layers, wasm, panic_hunt, perf and native UI rendering have not run. Full workspace gates in AGENTS.md remain required. No real portrait processing or Apple Vision validation performed. Source references documentation absent from the provided archive.

## Not delivered
No compiled .app, signed installer, background/cancellable processing, batch-photo export, learned acne model, semantic clothing/makeup model, automatic crop or advanced curves. Processing remains synchronous; large images can pause the UI. Large originals beyond the processing cap still need a resized copy. Existing functionality outside the touched paths has not been fully audited.

## Mac release gate
Run cargo test -p photocraft-engine and cargo test -p photocraft-ui-egui, then the remaining AGENTS.md checks. Build the Mac app; test duplicate portraits, landscape and mixed-light images, masks and selections, locked layers, no-face/no-donor cases, zero strength, undo, 4032×3024 and oversized inputs. Visually compare before/after and inspect eye/lip protection at 200%. Test installer identity checks and rollback before distributing a standalone app.
