#!/bin/bash
# Test the real Rust lipstick-pixel regression and existing UI, no installation.
set -uo pipefail
cd "$(dirname "$0")" || exit 1
[[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
python3 qa/check_lipstick_wiring.py || exit 2
LOG="$HOME/Desktop/PHOTOAI-LIPSTICK-RETEST.txt"
mkdir -p "$HOME/Desktop"
: > "$LOG"
printf 'Đang kiểm thử sửa lỗi SON MÔI; nhật ký: %s\n' "$LOG"
(
  echo '=== Pixel regression / auto lip contour ==='
  cargo test --locked -p photocraft-engine --lib retouch_cmds::ai_lipstick::tests -- --nocapture
  rc=$?
  if [[ $rc -ne 0 ]]; then exit "$rc"; fi
  echo '=== Full UI regression ==='
  cargo test --locked -p photocraft-ui-egui --lib
) > "$LOG" 2>&1
rc=$?
tail -n 26 "$LOG"
if [[ "$rc" -ne 0 ]]; then
  echo 'CHƯA ĐẠT: không cài bản mới. Gửi PHOTOAI-LIPSTICK-RETEST.txt trên Desktop.'
else
  echo 'ĐÃ ĐẠT KIỂM THỬ SON MÔI VÀ GIAO DIỆN. Tiếp theo: bash ./BUILD-PREVIEW-MAC.command'
fi
exit "$rc"
