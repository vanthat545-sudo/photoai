PhotoAI 0.7.11 — bản mã nguồn, chưa phải app cài sẵn.
Đọc PHOTOAI-v0.7.11-TEST-STATUS.md trước khi dùng.
Gói đầu vào thiếu phần xtask; cần khôi phục bộ nguồn build đầy đủ trước khi biên dịch.
