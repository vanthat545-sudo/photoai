#!/bin/bash
# Photo AI Studio v0.7.18: macOS local Preview builder, no system-wide dependencies installed.
# Open from Finder or run `bash CAI-DAT-PHOTO-AI-STUDIO.command` inside the extracted folder.
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'Chỉ hỗ trợ macOS.'; exit 1
fi
if [[ ! -f Cargo.toml || ! -f BUILD-PREVIEW-MAC.command ]]; then
  echo 'Gói source bị thiếu. Hãy giải nén đầy đủ ZIP trước.'; exit 1
fi
printf 'Đang kiểm tra và đóng gói Photo AI Studio v0.7.18.
'
bash ./BUILD-PREVIEW-MAC.command
