#!/usr/bin/env python3
"""Static structure check only; not a replacement for cargo test or Mac GUI tests."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
engine=(root/'crates/engine/src/retouch_cmds.rs').read_text()
ui=(root/'crates/ui-egui/src/panels.rs').read_text()
auto=(root/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
assert 'id: "paint.aiAutoRetouch"' in engine and 'run: ai_auto_retouch::run' in engine
assert 'mod ai_auto_retouch;' in engine
assert 'app.run("paint.aiAutoRetouch"' in ui
assert 'AI NHẬN DIỆN' in ui and 'Chân dung' in ui
assert 'photo_ai_effects::skin_pixel' in auto and 'auto_blemish::detect' in auto
assert 'apple_vision(&pixels' in auto
assert 'run_stroke(' in auto and 'eligible_skin' in auto
assert (root/'assets/icons/wand-sparkles.svg').exists()
assert 'swiftc ' in (root/'Build-and-Install-PhotoAI-Mac.command').read_text()
subprocess.run(['bash','-n',str(root/'Build-and-Install-PhotoAI-Mac.command')],check=True)
print('PASS static check: registered command, UI, helper, effects and shell syntax.')
