# PhotoAI v0.7.2 – Trạng thái kiểm tra

## Đã thực hiện trong mã nguồn
- Pro Retouch: 13 thông số chỉnh tone/màu trong lệnh `paint.photoAiEffects` (`effect=proGrade`), có riêng nút áp dụng một lần, dùng vùng chọn / ảnh và Undo.
- Tăng nét `proSharpen` có cường độ và vùng chọn.
- Tăng giới hạn chữa nốt 120; thông báo phân biệt số nốt phát hiện và số vùng thay đổi. AI Apple Vision vẫn giữ phương thức nhận diện mặt sẵn có.
- Đã viết thêm kiểm thử Rust cho: giá trị 0 không đổi màu; exposure tăng độ sáng; saturation -100 chuyển đen trắng; độ nét không làm biến đổi vùng đồng màu; áp dụng + Undo; đầu vào giới hạn đốm.

## Xác minh được trong môi trường Linux
- `bash -n` cho script cài Mac.
- Kiểm tra tĩnh liên kết UI ↔ lệnh Rust, các khóa thông số, đăng ký command, tài nguyên icon và giữ chức năng cũ.
- ZIP và CRC kiểm tra sau đóng gói.

## CHƯA kiểm chứng / không được coi là đạt
- `cargo check` / `cargo test` / `cargo build`: **môi trường này không có Rust/cargo**.
- Biên dịch Swift helper, ký ứng dụng và khởi chạy trên Mac M1.
- Hiệu quả xoá mụn thực tế, thời gian chạy nhiều ảnh, chuẩn màu ICC, màn hình Trước/Sau, tính năng nhận diện trên ảnh thực.
- UI chưa khớp 100% ảnh mẫu. Các tính năng tự chỉnh tóc/chân/quần áo bằng mô hình AI chưa được triển khai.

## Kiểm tra trên Mac
1. Sao lưu ứng dụng và ảnh dự án quan trọng.
2. Giải nén và nhấp đúp `Build-and-Install-PhotoAI-Mac.command` trên Mac có Rust + Xcode CLT. Nếu macOS chặn quyền chạy, kiểm tra thuộc tính file và cấp quyền thực thi chỉ cho script tin cậy.
3. Trong ứng dụng, chọn **Pro Retouch → Ánh sáng · độ tương phản** → Phơi sáng +1 EV, Áp dụng. Đảm bảo ảnh thay đổi và `⌘Z` trả về ảnh cũ.
4. Thử Saturation -100 để kiểm tra thành đen trắng; thử Tăng nét trên vùng có biên tương phản.
5. Chọn AI Beauty và thử trên bản sao ảnh chân dung; đếm nốt không phải thước đo ảnh đã sạch mụn.
