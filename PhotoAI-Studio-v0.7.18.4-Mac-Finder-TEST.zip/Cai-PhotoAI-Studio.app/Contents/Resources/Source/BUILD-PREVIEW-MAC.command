#!/bin/bash
# PhotoAI Mac M1 preview: one-click build and safe independent installation.
# Replaces only own Preview app. Never edits Photo AI.app or user projects.
set -euo pipefail
cd "$(dirname "$0")"
if [[ -f "$HOME/.cargo/env" ]]; then source "$HOME/.cargo/env"; fi
LOG="$PWD/PHOTOAI-PREVIEW-BUILD-LOG.txt"
mkdir -p "$(dirname "$LOG")"
# All build output also goes to file; errors are preserved for troubleshooting.
exec > >(tee -a "$LOG") 2>&1
printf 'Photo AI Studio v0.7.18.4 · build started at %s\n' "$(date)"
fail() { echo "BUILD/CÀI ĐẶT THẤT BẠI tại dòng $1. Không thay ứng dụng cũ. Xem PHOTOAI-PREVIEW-BUILD-LOG.txt"; }
trap 'fail "$LINENO"' ERR
[[ "$(uname -s)" == Darwin ]] || { echo 'Chỉ build trên macOS.'; exit 1; }
for c in cargo rustc swiftc codesign plutil; do
  command -v "$c" >/dev/null 2>&1 || { echo "Thiếu $c. Cài Rust và Xcode Command Line Tools."; exit 1; }
done
[[ -f xtask/src/main.rs ]] || { echo 'Thiếu xtask; gói mã nguồn không hoàn chỉnh.'; exit 1; }
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-2}" # Avoid overloading M1/8GB
python3 qa/check_retouch_v0711.py
python3 qa/check_automation_source.py
python3 qa/test_preview_gate.py
python3 qa/test_release_gate.py
python3 qa/test_critical_fixes_v07184.py
python3 qa/check_router_dock_isolation.py
python3 qa/check_router_studio_default.py
python3 qa/check_lipstick_wiring.py
python3 qa/check_integrated_release.py
python3 qa/check_v0717_features.py
python3 qa/check_v0718_studio_layout.py
python3 qa/test_egui_context_api_gate.py
python3 qa/check_vision_pointer_safety.py
python3 -m unittest discover -s qa -p "test_auto_cleanup.py"
# Check Rust panel parsing BEFORE running lengthy unit tests on Mac.
if command -v rustfmt >/dev/null 2>&1; then
  rustfmt --edition 2024 --emit stdout crates/ui-egui/src/panels.rs >/dev/null
fi
# Engine and UI unit tests are enforced before install; full release tests
# remain in qa/check-release.sh and MUST pass before public release.
# Safety gate: the reported 1746/1747 engine test failure MUST prevent install.
# Run real Rust unit tests before compiling the Swift helper or staging an app.
cargo test --locked -p photocraft-engine --lib
cargo test --locked -p photocraft-ui-egui --lib
mkdir -p target/debug
swiftc -framework Vision -framework AppKit -framework CoreGraphics \
  native/macos/PhotoAIVision.swift -o target/debug/PhotoAIVision
cargo build --locked -p photocraft
BIN="$PWD/target/debug/photocraft"
HELPER="$PWD/target/debug/PhotoAIVision"
[[ -x "$BIN" && -x "$HELPER" ]] || { echo 'Missing compiled binary/helper'; exit 1; }
APPDIR="$HOME/Applications"
DEST="$APPDIR/PhotoAI Retouch Preview.app"
mkdir -p "$APPDIR"
STAGE="$(mktemp -d "$APPDIR/.photoai-preview.XXXXXXXX")"
BACKUP=''
trap 'rm -rf "$STAGE"' EXIT
NEW="$STAGE/PhotoAI Retouch Preview.app"
mkdir -p "$NEW/Contents/MacOS" "$NEW/Contents/Resources"
cp "$BIN" "$NEW/Contents/MacOS/photocraft"
cp "$HELPER" "$NEW/Contents/MacOS/PhotoAIVision"
chmod 755 "$NEW/Contents/MacOS/"*
cp assets/app-icon/PhotoAI-Pro.icns "$NEW/Contents/Resources/PhotoAI-Pro.icns"
cat > "$NEW/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>photocraft</string>
<key>CFBundleIdentifier</key><string>local.photoai.retouch.preview</string>
<key>CFBundleName</key><string>Photo AI Studio</string>
<key>CFBundleDisplayName</key><string>Photo AI Studio</string>
<key>CFBundleShortVersionString</key><string>0.7.18.4</string>
<key>CFBundleVersion</key><string>4</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleIconFile</key><string>PhotoAI-Pro.icns</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
plutil -lint "$NEW/Contents/Info.plist"
codesign --force --sign - "$NEW/Contents/MacOS/PhotoAIVision"
codesign --force --sign - "$NEW/Contents/MacOS/photocraft"
codesign --force --sign - "$NEW"
codesign --verify --strict --deep "$NEW"
# Never overwrite user projects or differently named Photo AI.app.
# Old Preview is retained until the new binary has launched successfully.
# Existing open preview must be quit by the user; never kill a running editing session.
if /usr/bin/pgrep -f '/PhotoAI Retouch Preview\.app/Contents/MacOS/photocraft' >/dev/null 2>&1; then
  echo 'Hãy lưu ảnh và thoát PhotoAI Retouch Preview trước khi cập nhật. Không cài khi ứng dụng còn chạy.'
  exit 1
fi
if [[ -e "$DEST" ]]; then
  OLD_ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$DEST/Contents/Info.plist" 2>/dev/null || true)
  [[ "$OLD_ID" == 'local.photoai.retouch.preview' ]] || { echo 'Preview name occupied by another application; abort.'; exit 1; }
  BACKUP="$APPDIR/PhotoAI Retouch Preview-backup-$(date +%Y%m%d-%H%M%S)-$$.app"
  mv "$DEST" "$BACKUP"
fi
if ! mv "$NEW" "$DEST"; then
  if [[ -n "$BACKUP" && -e "$BACKUP" ]]; then mv "$BACKUP" "$DEST"; fi
  echo 'Không thể chuyển ứng dụng mới; đã khôi phục bản preview cũ.'; exit 1
fi
# Launch smoke-check before deleting the only rollback copy.
# `open` confirms Launch Services accepted the request, not that the app stayed up.
restore_previous() {
  if [[ -n "$BACKUP" && -d "$BACKUP" ]]; then
    local FAILED_APP="$STAGE/new-app-failed.app"
    if [[ -d "$DEST" ]]; then mv "$DEST" "$FAILED_APP"; fi
    if mv "$BACKUP" "$DEST"; then
      echo 'Đã khôi phục Preview cũ do bản mới không mở ổn định.'
    else
      echo "CẢNH BÁO: Khôi phục thất bại. Bản cũ vẫn ở: $BACKUP"
    fi
  fi
}
if ! open "$DEST"; then
  echo 'Lỗi mở ứng dụng mới. Không dọn bản cũ.'
  restore_previous
  exit 1
fi
# macOS may take a few seconds to launch the GUI process.
LAUNCH_OK=0
for ((i=0; i<20; i++)); do
  if /usr/bin/pgrep -f '/PhotoAI Retouch Preview\.app/Contents/MacOS/photocraft' >/dev/null 2>&1; then
    LAUNCH_OK=1
    break
  fi
  sleep 1
done
if [[ "$LAUNCH_OK" != 1 ]]; then
  echo 'Không xác minh được ứng dụng mới đang chạy. Không xóa bản cũ.'
  restore_previous
  exit 1
fi
# Confirm the GUI did not immediately crash after appearing in the process list.
sleep 4
if ! /usr/bin/pgrep -f '/PhotoAI Retouch Preview\.app/Contents/MacOS/photocraft' >/dev/null 2>&1; then
  echo 'Ứng dụng thoát ngay khi mở. Không xóa bản cũ.'
  restore_previous
  exit 1
fi
trap - ERR
printf '\nĐÃ CÀI VÀ MỞ: %s\n' "$DEST"
echo 'Chỉ sau xác minh khởi động mới dọn bản Preview cũ và cache biên dịch.'
# The cleanup helper only deletes Preview backups owned by this installer and
# this release's local target/ folder; it never scans Downloads or user projects.
if ! python3 qa/cleanup_auto_preview.py --app-dir "$APPDIR" --installed-app "$DEST" --build-root "$PWD"; then
  echo 'CẢNH BÁO: cài đặt thành công nhưng chưa dọn hết dữ liệu build/bản cũ.'
fi
echo 'Bạn có thể sử dụng app độc lập, không cần Terminal.'
echo 'Chất lượng xử lý chân dung thật vẫn cần kiểm tra trên ảnh thực tế.'
