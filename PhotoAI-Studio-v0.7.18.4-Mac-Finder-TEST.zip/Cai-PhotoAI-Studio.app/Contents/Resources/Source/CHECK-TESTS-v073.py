#!/usr/bin/env python3
"""Supplementary Python geometry tests. These DO NOT execute Rust or Apple Vision."""
from pathlib import Path

def guarded_lip(box, x, y):
    x0,y0,x1,y1=box
    mx=max(12, __import__('math').ceil((x1-x0)*0.35))
    my=max(12, __import__('math').ceil((y1-y0)*0.85))
    return x0-mx<=x<x1+mx and y0-my<=y<y1+my

def dab_safe(lip_box, x, y):
    for dx,dy in [(0,0),(-12,0),(12,0),(0,-12),(0,12),(-12,-12),(-12,12),(12,-12),(12,12)]:
        if guarded_lip(lip_box,x+dx,y+dy):return False
    return True

def test_protect_lips():
    box=(110,90,190,115)
    for x in range(80,220):
        for y in range(70,140):
            if guarded_lip(box,x,y):assert not dab_safe(box,x,y)
    assert dab_safe(box,45,150)

def test_restore_after_inpainting():
    box=(110,90,190,115)
    original=[[12+(x*3+y)%217 for x in range(260)] for y in range(220)]
    changed=[row[:] for row in original]
    for y in range(50,165):
        for x in range(75,225):changed[y][x]=255  # emulate worst-case overpainting
    for y in range(220):
        for x in range(260):
            if guarded_lip(box,x,y):changed[y][x]=original[y][x]
    assert all(changed[y][x]==original[y][x] for y in range(220) for x in range(260) if guarded_lip(box,x,y))
    assert changed[65][100]!=original[65][100]

def test_source_wiring():
    root=Path(__file__).resolve().parent
    ai=(root/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
    ui=(root/'crates/ui-egui/src/panels.rs').read_text()
    assert 'fn safe_healing_dab(' in ai and 'fn lip_guard(' in ai
    assert 'copy_from_slice(&pristine.data[start..end])' in ai
    assert '"protectLips":true,"protectEyes":true' in ui or '"protectLips":true, "protectEyes":true' in ui
    assert 'app.run("paint.autoBlemish"' not in ui

if __name__=='__main__':
    for t in (test_protect_lips,test_restore_after_inpainting,test_source_wiring):
        t();print('PASS',t.__name__)
    print('Note: these are Python reference/static tests, NOT a Rust/macOS runtime test.')
