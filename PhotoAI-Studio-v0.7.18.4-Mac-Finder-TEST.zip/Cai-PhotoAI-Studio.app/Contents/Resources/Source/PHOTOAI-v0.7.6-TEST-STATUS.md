# PhotoAI v0.7.6 — Hotfix verification status

## Fixed in source
- Both Retouch buttons labelled **Xoá mụn** now send `blemishOnly:true` to `paint.aiAutoRetouch`; no auto smoothing of whole face on those actions.
- The full **AI Tự động chỉnh** button remains separate and can deliberately combine skin smoothing and under-eye correction.
- Both blemish buttons now check `noChange`/healed counts and display an error when nothing was changed, instead of reporting success.
- Blemish-only mode always protects lips and eyes even if an external command asks to turn off guards.
- When no safe acne candidates are found, core returns `noChange:true` without starting the edit.
- The existing 6-color `proHsl` engine command is now exposed via 18 independent sliders (hue/saturation/brightness) in Pro Retouch; effects require Apply and support undo.
- Mac installer and UI identify the source build as 0.7.6.

## Verification here
- Python static source-link checks and ZIP CRC are available in `CHECK-TESTS-v076.py`.
- `bash -n` on the installer: check at packaging time.
- On this Linux runner, **no Rust/Cargo/Swift/macOS Vision**: complete compilation, native image processing, and integration tests **cannot be claimed**.
- This patch **does not** guarantee that large/inflamed acne or marks are removed on real portraits. No trained acne model has been integrated; existing acne detection still relies on heuristics.

## Known limitations
- Auto healing uses Apple Vision for facial landmarks but heuristic redness/dark-spot detection and safe skin-source inpainting for blemishes.
- No face found / no safe donor / missing app helper can still cause no result (now communicated honestly).
- HSL is six broad color bands, backed by HSV-like value adjustment, not precise Lightroom-grade parametric HSL or adjustment layers.
- Curves, semantic garment AI, lip/eye automatic makeup and model-powered reconstruction are **not complete**.
- **A .app is not included**. macOS installation requires a locally available Rust compiler and Xcode Command Line Tools, and is not a 1-click self-contained installer.

## Mac user checklist
1. Back up your previous PhotoAI.app and open a **duplicate** test portrait.
2. Build using `Build-and-Install-PhotoAI-Mac.command` on Mac.
3. Verify menu header says `PHOTO AI | RETOUCH 0.7.6` and app metadata 0.7.6.
4. Run **Xoá mụn AI an toàn**. If 0 patches, error must state there is no change (not success). If patches reported, check mouth/eye at 200% and compare before/after.
5. Test Pro Retouch HSL red saturation +50, confirm visible change and `⌘Z` undo.
