# PhotoAI v0.6.5 – Test status / tình trạng

## Đã sửa trong mã
- Xoá mụn: không bắt buộc vùng chọn; quét toàn bộ ảnh raster tối đa 12 MP, tối đa 40 điểm đỏ; nếu có vùng chọn, giữ giới hạn vùng. Có bảo vệ bằng tiền kiểm màu da đơn giản, không phải mô hình nhận diện mặt.
- Các icon Retouch bấm được khi có layer pixel; tính năng cần chọn vùng hiển thị hướng dẫn cụ thể thay vì khoá im lặng.
- Ảnh hưởng toàn ảnh khi không chọn vùng: Xoá mụn tự động (dò đốm đỏ), Làm mịn da (chỉ pixel qua ngưỡng màu da đơn giản), Làm sáng.
- Ô công cụ có icon lớn 30 px, chiều cao 86 px, chữ 11.5; dock rộng mặc định 440 pt.
- Bổ sung kiểm tra Rust cho dò mụn không vùng chọn và hoàn tác; CHƯA chạy các kiểm tra Rust này.

## Đã kiểm tra
- Kiểm tra tĩnh các tham chiếu icon/lệnh của UI.
- Kiểm tra nội dung bản vá và ZIP.

## Chưa kiểm tra
- Chưa có Cargo/Rust trong môi trường này: không biên dịch được, chưa xác nhận không có lỗi biên dịch.
- Chưa chạy chức năng thực tế trên macOS.
- Chưa kiểm thử chất lượng trên ảnh mụn thật; vùng da tối/phức tạp có thể không được nhận diện, vùng không phải mặt có thể dính lỗi nhận nhầm.
- Chưa có AI nhận diện môi, mắt, chân, tóc; các công cụ đó vẫn dựa vào vùng chọn.
- Chưa tích hợp vào bản Photo AI có icon máy ảnh tím-xanh mà người dùng đã cài.
