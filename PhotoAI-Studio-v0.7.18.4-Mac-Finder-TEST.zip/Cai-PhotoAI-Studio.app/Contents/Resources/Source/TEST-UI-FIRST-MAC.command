#!/bin/bash
# Run only the problematic UI tests; do not install or overwrite any app.
set -uo pipefail
cd "$(dirname "$0")" || exit 1
[[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
LOG="$HOME/Desktop/PHOTOAI-UI-RETEST.txt"
python3 qa/check_router_dock_isolation.py || exit 2
python3 qa/check_router_studio_default.py || exit 2
printf 'Đang kiểm thử giao diện... Nhật ký: %s\n' "$LOG"
cargo test --locked -p photocraft-ui-egui --lib > "$LOG" 2>&1
rc=$?
tail -n 25 "$LOG"
if [[ $rc -ne 0 ]]; then
  printf '\nKIỂM THỬ THẤT BẠI. Gửi file %s, KHÔNG cài đặt.\n' "$LOG"
else
  printf '\nKIỂM THỬ GIAO DIỆN ĐẠT. Có thể chạy bash BUILD-PREVIEW-MAC.command để test engine và build.\n'
fi
exit "$rc"
