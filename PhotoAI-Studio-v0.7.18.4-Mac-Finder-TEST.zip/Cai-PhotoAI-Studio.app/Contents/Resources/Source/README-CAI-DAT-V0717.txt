PHOTO AI STUDIO v0.7.17 — BẢN XEM TRƯỚC CHO MAC M1

ĐỂ CÀI: Giải nén ZIP, nhấp đúp vào "Cai-PhotoAI-Studio.app" ở Finder.
Giữ cả thư mục bên trong .app; bộ cài chứa mã nguồn và tự biên dịch trên Mac.
Nếu macOS chặn ứng dụng chưa được notarize, nhấn Control+click > Open.
CẦN CÓ SẴN: Rust/Cargo, Xcode Command Line Tools, Python 3 (Mac của bạn đã dùng chúng trong lần build trước).
Đợi 5–20 phút tùy máy và cache. Nhật ký ghi ở Desktop/PHOTOAI-V0717-INSTALL-LOG.txt.
Bộ cài chỉ thay ~/Applications/PhotoAI Retouch Preview.app nếu test, biên dịch,
đóng gói và khởi chạy đạt. Không thay Photo AI.app cũ, không xóa ảnh/dự án.
Chỉ sau khi bản mới khởi động ổn mới dọn bản Preview cũ và cache target.

TÍNH NĂNG MỚI TRONG v0.7.17:
- 17 icon chức năng độc lập, hình hacker mũ vàng 3D trong AI Router.
- Hiệu ứng mưa, tuyết, bokeh, ánh nắng tạo pixel thật, có undo.
- 120 biến thể tham số dựa trên 25 look gốc; KHÔNG phải 120 LUT .cube độc lập.
- Các công cụ hiện có như xóa mụn, son môi, AI Vision vẫn giữ từ bản trước.

CHƯA HOÀN THIỆN:
- Thay quần áo bằng AI, xóa người AI, thay nền AI, làm trắng răng AI tự động,
  tái tạo da bằng mô hình sinh ảnh, nhận diện tự động mọi vùng khuôn mặt/cơ thể.
- Hiệu quả xóa mụn, son môi, preset trên ảnh thật cần kiểm thử trên Mac.
- Không có binary macOS build sẵn trong ZIP (môi trường tạo file là Linux).
BẢN NÀY LÀ PREVIEW CÓ THỂ TỰ BUILD/CÀI, KHÔNG PHẢI BẢN FULL HOÀN THIỆN.
