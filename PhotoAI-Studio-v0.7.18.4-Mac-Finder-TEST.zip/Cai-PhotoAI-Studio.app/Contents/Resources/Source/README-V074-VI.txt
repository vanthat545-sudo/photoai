PhotoAI 0.7.4 - BẢN THỬ AN TOÀN MÔI / MẮT (MÃ NGUỒN)

Lý do: Công cụ chữa mụn phiên bản trước có thể lấy pixel môi làm mẫu,
ngay cả khi không tô trực tiếp lên môi.

Thay đổi: bộ tự động chỉnh dùng mask nguồn chỉ lấy da hợp lệ,
không lấy môi/mắt; làm mịn cũng bỏ qua pixel nguồn được bảo vệ.
Bổ sung vùng cấm giữa phần dưới của khuôn mặt khi mốc nhận diện bị lệch.

CẢNH BÁO:
- Chưa biên dịch trên macOS và chưa kiểm tra Apple Vision trực tiếp.
- Test độc lập bằng Python/OpenCV trên ảnh chân dung cũ: 0 pixel môi/mắt
  bị thay đổi, NHƯNG hiệu quả xoá mụn còn yếu.
- Đừng xoá hoặc ghi đè bản PhotoAI cũ trước khi thử.
- Nếu vừa thử và môi vẫn bị lem, dùng Cmd+Z và gửi ảnh trước/sau.
- Có thể một số nốt bị bỏ qua để ưu tiên an toàn.

Hướng dẫn build: dùng Build-and-Install-PhotoAI-Mac.command khi đã sao lưu.
Chi tiết ở PHOTOAI-v0.7.4-TEST-STATUS.md.
