#!/bin/bash
# Run on Mac AFTER Build-and-Install; tests the Vision helper on synthetic blank pixels
# and the Rust logic unit tests. Synthetic tests are not a portrait quality benchmark.
set -euo pipefail
cd "$(dirname "$0")"
echo "[1/3] Running Rust auto-retouch unit tests..."
cargo test -p photocraft-engine --lib ai_auto_retouch
HELPER="$HOME/Applications/PhotoAI.app/Contents/MacOS/PhotoAIVision"
[[ -x "$HELPER" ]] || { echo "[FAIL] Apple Vision helper missing from installed app" >&2; exit 1; }
echo "[2/3] Running Vision helper smoke test on blank RGBA frame..."
python3 - "$HELPER" <<'PY'
import json,struct,subprocess,sys
w=h=100
image=struct.pack('<II',w,h)+bytes((127,117,106,255))*(w*h)
r=subprocess.run([sys.argv[1]],input=image,capture_output=True,check=True,timeout=45)
data=json.loads(r.stdout)
assert isinstance(data.get('faces'),list),data
print('Vision helper responds with',len(data['faces']),'faces on blank image')
PY
echo "[3/3] Inspect a REAL portrait in the UI and verify face count, changes and Cmd-Z manually."
echo "PASS: automated smoke tests completed (not a quality guarantee)."
