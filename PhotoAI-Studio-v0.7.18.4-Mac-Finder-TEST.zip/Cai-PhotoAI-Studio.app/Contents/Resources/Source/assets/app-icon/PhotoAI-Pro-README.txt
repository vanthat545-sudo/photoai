Photo AI Studio app icon: PhotoAI-Pro.png / PhotoAI-Pro.icns (approved existing icon).
PhotoCraft's historic icon assets are retained solely for compatibility with tests and other targets.
The Mac Preview bundle uses PhotoAI-Pro.icns; unbundled macOS runtime uses PhotoAI-Pro.png.
