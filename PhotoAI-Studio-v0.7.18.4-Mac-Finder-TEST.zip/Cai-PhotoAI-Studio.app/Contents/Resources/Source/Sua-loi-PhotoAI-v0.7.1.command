#!/bin/bash
# PhotoAI v0.7 -> v0.7.1: targeted Rust type-fix and reinstall, retains existing projects.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATH_IN_APP="crates/engine/src/retouch_cmds/ai_auto_retouch.rs"
if [[ -f "$SCRIPT_DIR/$PATH_IN_APP" ]]; then
    SRC="$SCRIPT_DIR"
elif [[ -f "$HOME/Downloads/PhotoAI-v0.7-Auto-AI-Retouch-Source/$PATH_IN_APP" ]]; then
    SRC="$HOME/Downloads/PhotoAI-v0.7-Auto-AI-Retouch-Source"
else
    echo "Khong tim thay nguon PhotoAI v0.7. Hay dat script trong thu muc nguon va mo lai."
    read -r -p "Nhan Enter de dong..." _
    exit 1
fi
export PHOTOAI_SRC="$SRC"
python3 - <<'PYFIX'
import os, pathlib
p = pathlib.Path(os.environ['PHOTOAI_SRC'])/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs'
s=p.read_text(encoding='utf-8')
old='''        let left = eye.x0 - eye.width() / 5;
        let right = eye.x1 + eye.width() / 5;
        let below = (eye.height() as f32 * 0.45).max(3.0) as i32;
        let bottom = (eye.height() as f32 * 1.3).max(8.0) as i32;
        x >= left && x <= right && y >= eye.y1 + below && y <= eye.y1 + bottom'''
new='''        let pad = i32::try_from(eye.width() / 5).unwrap_or(i32::MAX);
        let left = eye.x0.saturating_sub(pad);
        let right = eye.x1.saturating_add(pad);
        let below = (eye.height() as f32 * 0.45).max(3.0) as i32;
        let bottom = (eye.height() as f32 * 1.3).max(8.0) as i32;
        let top = eye.y1.saturating_add(below);
        let end = eye.y1.saturating_add(bottom);
        x >= left && x <= right && y >= top && y <= end'''
if old in s:
    p.with_suffix('.rs.pre-v071-backup').write_text(s, encoding='utf-8')
    p.write_text(s.replace(old,new,1), encoding='utf-8')
    print('Da sua E0308/E0277; da sao luu ai_auto_retouch.rs')
elif 'let pad = i32::try_from(eye.width() / 5).unwrap_or(i32::MAX);' in s:
    print('File da sua truoc do; khong can sua tiep.')
else:
    raise SystemExit('Ma nguon khong khop ban v0.7. Dung lai de tranh sua nham.')
PYFIX
cd "$SRC"
echo "Kiem tra va bien dich: $SRC"
if ! command -v cargo >/dev/null 2>&1; then
    echo "Chua co cargo. Cai Rust hoac su dung ban nguon da cai Cargo."
    read -r -p "Nhan Enter de dong..." _
    exit 1
fi
# Build-and-Install also builds/signs Vision and safely backs up existing app.
bash ./Build-and-Install-PhotoAI-Mac.command
printf '\nDA XONG. Kiem tra AI Beauty -> AI tu dong chinh tren ban sao anh.\n'
read -r -p 'Nhan Enter de dong cua so...' _
