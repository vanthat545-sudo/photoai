PHOTO AI v0.5 — BẢN NGUỒN THỬ NGHIỆM RETOUCH + PRESET MÀU

Bản nguồn kế thừa từ PhotoCraft; giữ nguyên giấy phép MIT/Apache-2.0 và ATTRIBUTION.

TÍNH NĂNG TÍCH HỢP TRONG PHOTO AI | RETOUCH
1. Bộ 7 preset: Natural, Warm, Cool, Film, Vivid, Portrait, Moody.
   Chọn tên, kéo Cường độ 0–100, nhấn "Áp dụng preset màu".
   Nếu không khoanh vùng: áp dụng trên toàn layer raster (giới hạn 12MP mỗi lần).
   Nếu khoanh vùng bằng Marquee/Lasso: chỉ chỉnh trong vùng chọn.
2. "Đổi màu son môi": 5 màu nhanh + nút tự chọn màu.
   DÙNG LASSO (phím L) vẽ vùng môi trước, chọn layer raster ở bảng Layers.
   Thuật toán thay sắc, giữ độ sáng pixel để duy trì chi tiết vân môi; KHÔNG tự dò môi.
3. "Đánh khối tối" / "Highlight vùng sáng": khoanh vùng trước,
   điều chỉnh độ mạnh bằng thanh chung. Không tạo lại hình dạng mặt.
4. "Chỉnh sáng ảnh/vùng chọn": tăng sáng có giới hạn, chọn vùng là tùy chọn.
5. "Ủi phẳng nếp nhăn quần áo": khoanh vùng áo/quần (phím L/M),
   giảm nếp nhỏ bằng làm mịn có giữ biên. Giới hạn 3MP mỗi lần và cần kiểm tra
   lại chất liệu sau xử lý; nếp gấp lớn không thể biến mất hoàn toàn.
6. Giữ Spot Healing thủ công và Auto Blemish thử nghiệm từ v0.4.
7. Sửa ảnh ngay trên layer pixel, có bước Undo (⌘Z) cho mỗi lượt Apply.
   KHÔNG cần server hay gửi ảnh lên cloud.

CÁCH CÀI TRÊN MACBOOK APPLE SILICON / MAC M1
- Máy đã có Cargo/Rust: giải nén file ZIP, nhấp đúp
  Build-and-Install-PhotoAI-Mac.command và cấp quyền nếu macOS hỏi.
- Script tự chạy `cargo build --release -p photocraft`, tạo ~/Applications/PhotoAI.app,
  sao lưu bản app trước thành ~/Applications/PhotoAI-previous.app, mở app.
- NẾU gặp lỗi bảo mật hoặc quyền chạy, xem hướng dẫn của macOS; không tắt Gatekeeper toàn hệ thống.
- Script cần Rust đã cài; đây KHÔNG phải .app biên dịch sẵn.

KIỂM CHỨNG
- Đã kiểm tra cấu trúc tệp, liên kết nút → lệnh engine, hạn mức vùng chọn,
  các bài unit test mới đã viết, và cú pháp Bash bằng `bash -n`.
- Chưa chạy `cargo build` / `cargo test` do phiên hiện tại không có công cụ Rust.
- Chưa chạy giao diện trên Mac, chưa khẳng định các nút hoạt động ổn định thực tế.
- Tính năng AI học máy tự xác định môi/mặt/vải và xóa toàn bộ mụn bằng model
  CHƯA có trong bản này. Các tính năng ở đây dùng xử lý pixel cục bộ.

LƯU Ý
- Trước khi chỉnh ảnh thật, nên nhân đôi layer và lưu bản sao ảnh gốc.
- Mac M1 8GB: thử với vùng chọn nhỏ, nhất là ủi nếp áo.
- Chỉnh preset nhiều lần làm dồn màu; hãy Undo nếu màu quá gắt.
