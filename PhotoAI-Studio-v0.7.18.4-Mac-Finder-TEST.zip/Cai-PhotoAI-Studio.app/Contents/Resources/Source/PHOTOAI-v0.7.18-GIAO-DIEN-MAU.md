# Photo AI Studio v0.7.18 – Giao diện hướng tới ảnh mẫu

## Đã chỉnh mã nguồn
- Thanh trái mở rộng: Mở ảnh, Lưu ảnh, Hoàn tác, Làm lại, Chỉnh sửa, Bộ lọc, Hiệu ứng, Vẽ, Văn bản, Cắt ảnh, Lớp, Chuyên sâu. Các mục hoạt động thông qua lệnh gốc.
- AI Router phải rộng hơn, icon hacker 3D 54px, tiêu đề rõ hơn, 5 tab dạng nút xanh cyan, nhóm Tự động hiển thị 8 thẻ chức năng có icon.
- Dải dưới thay bằng 4 bảng: Sáng tạo, Preset màu, Chuyên sâu, AI nâng cao (chưa hỗ trợ). Thẻ chỉ bấm được khi có xử lý thật; AI tạo sinh không mô hình sẽ vô hiệu.
- Bảng dưới chiếm toàn chiều ngang cửa sổ; các cột cuộn ngang khi màn hình hẹp.
- Giữ bộ xử lý v0.7.17 và các tính năng gốc; không sửa dữ liệu ảnh, thuật toán son môi hay xóa mụn trong lần này.

## Giới hạn và kết quả test
- Đây là bản mã nguồn Preview; chưa biên dịch Rust hoặc chạy native Mac M1 trong môi trường tạo gói.
- Ảnh mẫu là mockup giới thiệu nên không thể đối chiếu pixel-perfect trước khi thấy screenshot ứng dụng thực tế.
- Chế độ so sánh ảnh Trước/Sau chưa tích hợp như mockup, AI đổi quần áo / nền / xóa người / tạo ảnh chưa có mô hình.
- Bản cài phải vượt test và build trên Mac trước khi thay bản Preview; giữ nguyên dự án, preset, ảnh và app khác.
