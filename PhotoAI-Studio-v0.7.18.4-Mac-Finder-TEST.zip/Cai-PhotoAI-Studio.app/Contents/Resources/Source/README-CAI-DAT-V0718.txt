PHOTO AI STUDIO v0.7.18 – BẢN GIAO DIỆN THEO MẪU

CÀI: giải nén gói ZIP, nhấp đúp Cai-PhotoAI-Studio.app trong Finder.
Bộ cài chạy các bài kiểm thử trên Mac M1 rồi mới thay Photo AI Retouch Preview.app.
Mã nguồn không chứa binary macOS build sẵn, máy cần Rust/Cargo, Swift/Xcode CLT, Python3.

UI mới: thanh trái 12 chức năng, bảng AI Router 5 tab với icon 3D lớn, 8 nút tự động dưới dạng thẻ ảnh/icon, 4 nhóm công cụ ở dưới ảnh.
Hình mũ hacker vàng dùng chung cho icon ngoài Finder/Dock và trong Router.
Các tính năng tạo sinh AI chưa có mô hình sẽ bị vô hiệu rõ ràng.
Mục tiêu là gần bố cục mockup ở độ phân giải đủ rộng; chưa có ảnh chụp ứng dụng native để xác nhận giống mẫu.
Công cụ Trước/Sau kéo trực tiếp vẫn chưa triển khai.
Những chức năng xử lý ảnh thật cần kiểm chứng bằng ảnh của người dùng.
Nhật ký tại Desktop/PHOTOAI-V0718-INSTALL-LOG.txt và trong mã nguồn.
Không xóa ứng dụng khác/ảnh/preset/dự án.
