#!/usr/bin/env python3
"""Structural checks only; no claim of successful Rust compilation or image-quality validation."""
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
engine = (root/'crates/engine/src/retouch_cmds/photo_ai_effects.rs').read_text()
registry = (root/'crates/engine/src/retouch_cmds.rs').read_text()
ui = (root/'crates/ui-egui/src/panels.rs').read_text()
auto = (root/'crates/engine/src/retouch_cmds/auto_blemish.rs').read_text()
ai = (root/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
assert '"proGrade" | "proSharpen"' in engine
assert 'fn pro_grade(' in engine and 'fn pro_sharpen(' in engine
assert 'effect == "proGrade"' in engine and 'effect == "proSharpen"' in engine
assert 'proGrade|proSharpen' in registry
assert 'photo_ai_pro_grade_panel(app, ui, has_pixels, strength)' in ui
assert '"effect":"proGrade"' in ui and '"effect":"proSharpen"' in ui
for name in ['exposure','contrast','highlights','shadows','whites','blacks','temperature','tint','saturation','vibrance','redSaturation','greenSaturation','blueSaturation']:
    assert name in ui, ('UI missing', name)
    assert name in engine, ('engine missing', name)
assert 'fn pro_grade_undo_and_changed_pixels' in engine
assert 'fn pro_sharpen_lifts_local_detail_without_changing_flat_areas' in engine
assert '"count":healed' in auto and '"detected":spots.len()' in auto
assert 'maxSpots":1..120' in registry
assert 'app.run("paint.aiAutoRetouch"' in ui
assert 'apple_vision(&pixels' in ai
for icon in ['sliders-horizontal','sparkles','palette','sun']:
    assert (root/'assets/icons'/f'{icon}.svg').is_file()
subprocess.run(['bash', '-n', str(root/'Build-and-Install-PhotoAI-Mac.command')], check=True)
print('PASS: engine command, UI fields, effects, undo tests authored, status, icons and installer syntax')
print('NOT RUN: Rust compile, Rust tests, Apple Vision, Mac UI tests or actual image quality tests')
