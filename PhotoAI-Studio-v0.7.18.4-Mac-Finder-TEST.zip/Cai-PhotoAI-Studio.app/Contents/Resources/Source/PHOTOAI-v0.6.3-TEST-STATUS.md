# PhotoAI v0.6.3 — Retouch icons and tool visibility

- Added SVG vector icons for both Retouch tabs and section headings.
- Kept all 25 presets and existing executable commands without rewriting image engine.
- Disabled placeholders for requested features not implemented: automatic face/lip detection, flyaway hair, leg lengthening.
- No machine-learning model added; auto blemish remains classical localized redness detection.
- Static tests: source patch presence and ZIP CRC validation. Rust compile / Mac UI / actual effect tests NOT run.
