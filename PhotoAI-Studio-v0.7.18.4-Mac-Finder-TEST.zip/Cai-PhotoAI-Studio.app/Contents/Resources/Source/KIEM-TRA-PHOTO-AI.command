#!/bin/bash
# Diagnostic test only; does not install or replace a .app.
set -uo pipefail
cd "$(dirname "$0")" || exit 1
[[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-2}"
LOG="$HOME/Desktop/PHOTOAI-STUDIO-v0716-TEST.txt"
mkdir -p "$HOME/Desktop" target/debug/deps
: > "$LOG"
(
  python3 qa/check_integrated_release.py || exit $?
  python3 qa/check_router_studio_default.py || exit $?
  python3 qa/check_lipstick_wiring.py || exit $?
  echo '=== ENGINE ==='
  cargo test --locked -p photocraft-engine --lib || exit $?
  echo '=== UI ==='
  cargo test --locked -p photocraft-ui-egui --lib || exit $?
  echo '=== BASIC APP CHECK ==='
  cargo check --locked -p photocraft || exit $?
) > "$LOG" 2>&1
rc=$?
tail -n 35 "$LOG"
if [[ "$rc" -ne 0 ]]; then
  echo "CHƯA ĐẠT. File lỗi: $LOG"; exit "$rc"
fi
echo 'KIỂM THỬ ĐẠT. Bạn có thể chạy bash ./CAI-DAT-PHOTO-AI-STUDIO.command'
