# PhotoAI v0.6.4 — test status / minh bạch chất lượng

## Thay đổi mã nguồn (đã kiểm tra tĩnh)
- 5 hiệu ứng mới trong lệnh xử lý ảnh thật: `skinSmooth`, `flyawayHair`, `legLength`, `skinTone`, `blush`.
- UI Retouch có ô công cụ icon SVG cho từng lệnh; 2 tab AI Beauty và Pro Retouch, giữ bảng điều khiển cũ trong mục mở rộng.
- 25 preset cũ được giữ nguyên.
- Các lệnh yêu cầu chọn layer pixel và khoanh vùng; undo thông qua `run_stroke` / lịch sử chỉnh sửa hiện có.
- Trả số điểm ảnh thực sự thay đổi (changedPixels), thông báo khi không có pixel nào đổi.
- Script cài đặt bảo lưu bản `.app` cũ với tên sao lưu duy nhất, không đụng đến dữ liệu dự án.

## Đã kiểm thử
- PASS: kiểm tra tĩnh đường nối UI → tên hiệu ứng → registry → engine (`test_photoai_064.py`).
- PASS: tất cả icon dùng trong ô chức năng có trong bộ tài nguyên.
- PASS: kiểm tra tính hợp lệ định dạng ZIP bằng CRC, khi đóng gói.
- PASS: kiểm tra toán học với trường hợp thử tóc đen mảnh trên nền đều, dịch vị trí mẫu kéo chân (Python mô phỏng).

## Chưa kiểm thử — KHÔNG ĐƯỢC coi là PASS
- Rust `cargo check` / `cargo test` / `cargo build` không thực hiện được ở môi trường đóng gói (không có Cargo/Rust).
- Mac M1: chưa mở, nhấn nút, kiểm tra hậu kỳ trên ảnh thật; cần chạy thử với ảnh đủ chân và ảnh tóc/nền thích hợp.
- Chưa có model nhận diện khuôn mặt/mắt/môi/chân/tóc. Xoá mụn tự động vẫn là dò đỏ theo vùng khoanh; tác dụng không đảm bảo trên ảnh thật.
- Kéo dài chân là biến dạng vùng người dùng chọn, không có pose estimation và có thể làm cong nền.
- Xoá tóc con là phép phát hiện vệt tối mảnh trên nền đều, không có inpainting AI; tóc dày / nền phức tạp chưa xử lý tốt.
- Không có tái tạo khuôn mặt, tạo mí đôi có hiểu hình học, giải thuật xoá mọi mụn hoặc flyaway hair đa nền chất lượng cao.
- Chưa ghép vào app `Photo AI` icon máy ảnh tím xanh mà người dùng đã cài (cần đúng mã nguồn/app gốc để tích hợp không phá chức năng). Script cài bản `PhotoAI.app` theo dự án nguồn đã cung cấp, có sao lưu.

## Cách thử trên Mac
1. Chép tệp ZIP vào Mac, giải nén vào thư mục riêng. Không xoá Photo AI bản đang dùng.
2. Nếu đã có Rust, chạy `Build-and-Install-PhotoAI-Mac.command` trong Finder (có thể cần quyền mở script).
3. Mở ảnh, chọn một lớp raster trong Layers, chọn thumbnail PIXELS (không phải mask), dùng Lasso khoanh sát phần muốn sửa. Trên tab AI Beauty chọn công cụ và kiểm tra thay đổi. ⌘Z để hoàn tác.
4. Test với 3 ảnh thực: ảnh chân dung mụn, ảnh toàn thân rõ chân, ảnh có tóc con trên nền đồng đều; thử mức 20/60/100% và nhìn đường viền.
5. Nếu cargo báo `error`, gửi đầy đủ các dòng lỗi cùng dòng code; chưa nên xoá bản cũ.
