#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -f "$HOME/.cargo/env" ]]; then source "$HOME/.cargo/env"; fi
python3 CHECK-TESTS-v078.py
python3 qa/check_retouch_v0711.py
python3 qa/check_automation_source.py
cargo test --locked -p photocraft-engine
cargo test --locked -p photocraft-ui-egui
cargo clippy --locked -p photocraft-engine -p photocraft-ui-egui --all-targets -- -D warnings
echo 'Rust native tests passed. Image quality, UI interaction and Apple Vision still require hands-on checks.'
