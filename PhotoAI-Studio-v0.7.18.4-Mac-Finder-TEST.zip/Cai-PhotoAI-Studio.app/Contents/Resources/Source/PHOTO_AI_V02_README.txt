PHOTO AI RETOUCH v0.2 — MAC M1 SOURCE PATCH

Thay doi:
- Retouch nam ben trong right dock, khong con bang ngang chiem dien tich canvas.
- Bon cong cu co that: Spot Healing, Healing Brush, Clone Stamp, Blur.
- Chia nhom cong cu va hien ro cac tinh nang AI tu dong chua co.
- Tam loai xtask khoi workspace boi ZIP goc khong co xtask/src.

Cai tren Mac:
1. Giai nen vao mot thu muc moi, KHONG ghi de Photo AI Test.app cu.
2. Mo Terminal tai thu muc chua Cargo.toml.
3. cargo check -p photocraft
4. cargo build --release -p photocraft
5. Dong goi binary moi vao app thu nghiem theo cac buoc da dung truoc.

Tinh trang: da sua source; CHUA kiem thu cargo build tren Mac trong moi truong nay.
