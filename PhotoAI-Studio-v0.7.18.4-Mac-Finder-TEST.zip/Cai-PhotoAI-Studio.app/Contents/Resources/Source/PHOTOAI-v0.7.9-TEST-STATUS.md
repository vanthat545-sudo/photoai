# Photo AI 0.7.9 — Tự động một chạm, bản mã nguồn chờ kiểm thử

## Đã triển khai trong mã nguồn
- Bộ điều phối paint.photoAiAuto, gọi danh sách công cụ cố định được cho phép; không chạy mã hoặc lệnh tuỳ ý.
- AI tự chỉnh: tự phân tích/cân ánh sáng, màu; trên Mac thêm nhận diện mặt và retouch bảo vệ mắt/môi. Ngoài Mac chỉ chỉnh màu và báo đã bỏ qua chỉnh mặt.
- AI chân dung: tự chỉnh ánh sáng/màu rồi nhận diện và retouch mặt; thiếu Vision thì trả lỗi, không ghi kết quả bước màu vào ảnh gốc.
- AI xoá mụn: chỉ nhận diện và chữa điểm nghi mụn; không tự làm mịn hay đổi màu toàn ảnh.
- AI chỉnh da: nhận diện mặt, chữa điểm nghi mụn và làm mịn nhẹ; không đổi hình dạng mặt.
- Bốn nút tự cân sáng, trắng, tương phản và kết hợp màu dùng chung bộ điều phối.
- Chạy trên tài liệu tạm trong bộ nhớ, chỉ ghi kết quả vào tài liệu đang mở sau khi hoàn tất. Hoàn tác/redo qua một bước; không tự ghi đè file ảnh gốc.
- Kiểm tra thay đổi tài liệu thực tế; không chỉ tin bộ đếm changedPixels của công cụ. Không đổi ảnh thì không tạo bước hoàn tác mới.
- Thông báo lỗi bước nào; no-change không báo thành công giả. Có dryRun cho kênh lệnh để xem kế hoạch mà không chỉnh ảnh.
- Giữ thay đổi giao diện kéo bảng, icon nhỏ và biểu tượng mũ trùm từ bản trước.

## Bản chất tự động hoá
Lựa chọn công cụ theo mục tiêu nút bấm là quy tắc cục bộ. Phân tích sáng/màu dùng thuật toán thống kê đã có; nhận diện mặt dùng mô hình Apple Vision. Chưa có LLM lập kế hoạch hoặc AI phân loại toàn bộ nội dung ảnh. Không tự chọn trang điểm, thay nền hay sửa dáng.

## Kiểm thử
Đã chạy: kiểm tra tĩnh CHECK-TESTS-v078.py (cập nhật nhãn phiên bản); qa/check_automation_source.py; 4 bài qa/test_release_gate.py; bash -n cho script gate và bộ cài; kiểm tra ZIP CRC khi đóng gói.
Các bài Python về gate kiểm tra thứ tự/dừng khi lỗi bằng công cụ giả, không thực thi engine.

Đã viết 7 bài Rust, CHƯA CHẠY:
1. Các mục tiêu chỉ chọn công cụ được phép và luôn bảo vệ mắt/môi.
2. Tham số sai/dryRun không thay đổi ảnh.
3. Chỉnh màu tại 8/16/32-bit, giữ vùng ngoài chọn và alpha, undo/redo toàn bộ.
4. Công cụ thứ hai lỗi thì ảnh gốc và revision giữ nguyên.
5. Cường độ 0 không gọi công cụ và không tạo lịch sử mới.
6. Không có ảnh/lớp khóa thì từ chối chỉnh.
7. Công cụ báo số điểm ảnh giả nhưng tài liệu không đổi thì không báo thành công.

Gate thực tế bị chặn vì môi trường không có Cargo/Rust. Chưa compile, chạy engine, clippy, wasm, panic_hunt, benchmark, Apple Vision, UI hay xuất ảnh thật. Tài liệu kiến trúc mà AGENTS.md tham chiếu vẫn thiếu trong nguồn nhận được.

## Còn thiếu / hạn chế
- Chưa có xử lý nền, nút huỷ, hoặc tiến độ trực tiếp. Không hiển thị phần trăm giả; ảnh lớn có thể làm UI chờ.
- Chưa có ảnh chụp ứng dụng chạy thật và chưa có .app đã biên dịch.
- Giới hạn toàn ảnh 13 triệu pixel. Mac helper vẫn có giới hạn mỗi chiều 8000; cần thống nhất trong đợt sửa sau.
- Chưa xử lý các rủi ro Vision không timeout và điểm ảnh lân cận không hợp lệ được nêu trong báo cáo rà soát trước.
- Chưa đảm bảo giữ nốt ruồi, chất lượng da hay nhận diện đúng mọi khuôn mặt; cần kiểm tra ảnh chân dung thật.
- Không coi các nút mới là đã hoạt động ổn cho đến khi các bài test Rust và kiểm thử Mac đạt.

## Kiểm thử Mac bắt buộc
Chạy gate, build, thử cả tám nút trên ảnh sáng/tối, không có mặt, lớp khoá, vùng chọn, cường độ 0 và ảnh 4032×3024. Kiểm tra bản gốc khi lỗi Vision, undo/redo, lưu/mở lại, xuất; so sánh mắt/môi và vùng ngoài chọn ở 200%. Chụp màn hình dock và bảng nổi; chỉ phát hành bản app sau khi các mục này đạt.
