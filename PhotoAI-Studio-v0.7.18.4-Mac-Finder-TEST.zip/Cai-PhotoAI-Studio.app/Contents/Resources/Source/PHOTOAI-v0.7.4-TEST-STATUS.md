# PhotoAI v0.7.4 — Safety First (experimental source patch)

## Why this patch is needed
In v0.7.3, the generic Content-Aware healing tool sampled from unmasked source pixels in a large window. A destination-only lip guard did not guarantee lip colours couldn't enter a nearby cheek repair. Generic 7x7 skin smoothing could also use protected feature pixels as neighbours.

## Changed source
- `crates/engine/src/retouch_cmds/ai_auto_retouch.rs`: add guarded content-aware fill with a source mask limited to eligible skin (not lips/eyes); only the safe 7 px spot footprint can change. Preserve alpha.
- Add face-centre lower shield when lip landmark estimates drift on 3/4 portraits; defaults to protecting lips/eyes.
- Smoothing now excludes protected lip/eye samples from its local 7x7 kernel.
- The retouch command still remains undoable as one operation; writes only allowed pixels.
- A zero donor-area situation leaves the spot unchanged and increments `skippedUnsafeSource`.
- Existing manual `paint.spotHealing` / advanced `paint.autoBlemish` still have no Apple Vision landmark guard; avoid running those on lips/eyes.

## Confirmed checks in this environment
- Static source inspection of the guarded ROI and donor-source code — PASS.
- Independent **Python/OpenCV prototype** using previously supplied `Hình ảnh.jpeg` (500x678) — RAN:
  - 61 test candidate spots detected
  - 2576 RGB pixels changed, only inside explicitly allowed cheek/forehead ROI
  - 0 pixels changed in manually defined lip protection rectangle
  - 0 pixels changed in manually defined eye protection rectangles
  - Approximate mean red excess at inpaint mask: 0.3168 to 0.3129; visible blemish reduction was still small (NOT satisfactory for full acne removal)
- Before/after and protection overlay exported outside the source ZIP.

## NOT VERIFIED
- No rustc/cargo toolchain available in this test container — Rust tests and macOS build NOT RUN.
- No macOS Apple Vision available in this test container — actual face/mouth landmark masks NOT RUN.
- Exact Rust `content_aware::fill` patched result and export on user's Mac NOT RUN.
- Full automatic removal quality NOT PASSED: the offline prototype still leaves substantial acne, and source behaviour could differ.

## Safest rollout
- Keep installed v0.7.3 and photo/project backups.
- Build v0.7.4 on the Mac and test on a copy of the portrait; use Compare and Undo before any export.
- If lip pixels change on a real face, disable auto retouch and roll back. Do not increase strength until corrected.
