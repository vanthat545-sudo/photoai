# Photo AI Studio v0.7.16.1 — Apple Vision memory-safety patch

Bản này giữ nguyên chức năng từ v0.7.16, chỉ sửa 2 cảnh báo Swift tại PhotoAIVision.swift.

- Trong feature(...) dùng `points.normalizedPoints` trực tiếp.
- Trong contour(...) dùng `feature.normalizedPoints` trực tiếp.
- Bỏ UnsafeBufferPointer tạo từ Array tạm, tránh nguy cơ con trỏ treo.

Kết quả được xác nhận từ nhật ký v0.7.16 của người dùng: engine 1751 passed, UI 2957 passed, tổng 4708 passed. **Các kết quả này thuộc v0.7.16, không phải lần build mới v0.7.16.1.**

Kiểm tra tĩnh và shell trên môi trường đóng gói đã đạt; chưa thể chạy Swift compiler hoặc Rust tests trên Mac trong môi trường đóng gói. Cần chạy BUILD-PREVIEW-MAC.command trên máy macOS trước khi cài.

Chưa xác nhận xóa mụn/son môi bằng ảnh thật hay hoàn thiện mọi tính năng AI. Ứng dụng hiện tại phải được giữ lại cho tới khi build mới thành công.
