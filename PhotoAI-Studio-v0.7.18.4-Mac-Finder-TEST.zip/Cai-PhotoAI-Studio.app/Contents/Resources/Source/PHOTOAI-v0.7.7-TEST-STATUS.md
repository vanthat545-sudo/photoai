# PhotoAI v0.7.7 — Retouch source patch (2026-10-26)

## Changes in source
- Raise the consistent Rust/Swift image budget from 12,000,000 to 13,000,000 pixels. A 4032×3024 image contains 12,192,768 pixels and was previously rejected before detection. Larger images still need a resized copy.
- Use the healthy-skin color test for donor pixels only. Previously both candidate acceptance and the healing hole rejected strongly red blemish centers; this could change surrounding skin but leave the center untouched. Candidates still require the existing detector, opaque pixels and facial-feature clearance.
- Preserve selection boundaries and eye/lip masks. Do not add whole-face smoothing to the blemish-only action.
- Skip unnecessary full-face snapshots in blemish-only mode.
- Add Rust regression cases for the camera pixel budget and a strongly red synthetic spot at 8/16/32-bit depth, asserting center repair and no changes outside the dab.

## Verification completed here
- CHECK-TESTS-v077.py: static wiring/source-contract checks and installer shell syntax.
- ZIP CRC check.

## NOT verified / release blockers
- No cargo/rustc or macOS/Swift framework in this runner: Rust tests, compilation, clippy, workspace layers/wasm, panic_hunt, perf, native UI and real photo behavior have NOT run.
- Added Rust tests are pending execution; their presence is not a passing result.
- Existing test shifted_landmarks_do_not_allow_edits_in_central_lower_face appears inconsistent with the v0.7.6 policy that trusts supplied mouth landmarks. Not silently removed or marked passing. Needs native/full-suite review.
- The archive omits the architecture/development/roadmap documents referenced by AGENTS.md.
- Heuristic spot detection remains limited; large acne, texture and incorrect landmarks can still cause misses or artifacts. This is not a trained acne removal model.
- This archive contains SOURCE, not a standalone .app or one-click installer. The existing Mac build script needs a Rust/Xcode development environment. No claim that the user's installed app has been updated.

## Next verification on a Mac development environment
1. Run cargo test -p photocraft-engine and the workspace checks listed in AGENTS.md; fix any failures before release.
2. Build with the bundled script and confirm Retouch 0.7.7.
3. On duplicate portraits, test 4032×3024 import → blemish removal → before/after at 200% → one-step undo, with and without a selection.
4. Verify lips, eyes, alpha and unselected pixels remain unchanged. Test no-face/no-donor/oversize inputs and error reporting.
5. Build and test a standalone Mac app before distributing a ready-to-run release.
