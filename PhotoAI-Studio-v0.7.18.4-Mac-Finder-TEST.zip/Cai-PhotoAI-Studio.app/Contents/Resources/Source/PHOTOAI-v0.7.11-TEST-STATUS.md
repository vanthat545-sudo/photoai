# PhotoAI 0.7.11 — Router và bảng chỉnh ảnh

Trạng thái: bản mã nguồn đang hoàn thiện, CHƯA phải ứng dụng Mac đã kiểm chứng.

## Thay đổi đã viết
- Nút Mịn da trong lưới chuyển sang workflow nhận diện mặt, bảo vệ mắt/môi; không còn gọi làm mịn toàn khung khi thiếu vùng chọn. Workflow này gồm chữa mụn và làm mịn.
- Lịch sử tối đa 20 kết quả trong phiên làm việc, lọc theo từng tài liệu. Thông báo chung không ghi đè kết quả chỉnh ảnh. Lịch sử không lưu xuống cấu hình và sẽ mất khi thoát.
- Chi tiết từng bước màu/da: có thay đổi hoặc không thay đổi.
- Nút Hoàn tác và Làm lại ngay trong bảng; áp dụng cho thao tác tài liệu gần nhất, không riêng thao tác retouch.
- Cường độ mặc định 55%, chọn nhanh Nhẹ 30 / Tự nhiên 55 / Mạnh 80; giải thích cường độ 0 và phạm vi vùng chọn.
- Lưới công cụ 1–4 cột theo chiều rộng, nhãn xuống dòng, màu theo theme; thu gọn thiết lập nhận diện nâng cao.
- Router giữ cảnh báo từ công cụ con; từ chối dryRun sai kiểu thay vì âm thầm chạy chỉnh ảnh.
- Bộ cài dừng sớm nếu thiếu xtask/src/main.rs, không thay thế app đang có.

## Đã chạy đạt trong môi trường này
- CHECK-TESTS-v078.py: các kiểm tra liên kết mã nguồn hiện tại.
- qa/check_automation_source.py: kiểm tra tĩnh router.
- 4 bài Python qa/check_retouch_v0711.py: đường làm mịn, lịch sử, lưới và sự hiện diện kiểm thử hồi quy.
- 4 bài Python qa/test_release_gate.py: cơ chế dừng và thứ tự lệnh bằng công cụ giả.
- bash -n: cú pháp bộ cài.
- Kiểm tra toàn vẹn ZIP khi đóng gói.

Đây là kiểm tra cấu trúc và điều phối, không phải kiểm thử chạy engine hay chất lượng ảnh.
Chi tiết đầu ra: qa/TEST-OUTPUT-v0711.txt.

## Chưa chạy / chưa hoàn tất
- Cargo và rustc không có trong môi trường: release gate thực tế dừng với exit 2.
- Gói nguồn nhận từ v0.7.10 thiếu xtask/src/main.rs; xtask cũng không nằm trong workspace.members hiện tại dù .cargo/config.toml gọi cargo xtask. Cần khôi phục đúng bộ nguồn xtask cùng phiên bản, không bỏ qua gate hoặc thay bằng script báo đạt giả.
- 9 test Rust workflow và 7 test Rust feedback đang có trong nguồn chưa được thực thi. Cần compile, clippy, wasm và test engine/UI.
- Chưa chạy Apple Vision, UI thực, kiểm tra ảnh trước/sau hoặc cài trên macOS. Chưa có ảnh chụp giao diện thực tế của bản này.
- Chưa có xử lý nền/tiến độ/hủy; lệnh vẫn đồng bộ, ảnh lớn có thể làm giao diện chờ.
- Son, mắt, tóc, dáng và quần áo vẫn cần vùng chọn thủ công.
- Chưa bổ sung cơ chế bảo vệ mũi riêng; không hứa giữ khuôn mặt tuyệt đối.
- Đây là ZIP mã nguồn, không phải bộ cài độc lập một chạm. Không thay app hiện tại bằng bản này khi chưa build/test đạt.

## Các bước kiểm thử Mac còn bắt buộc
Khôi phục bộ nguồn build → chạy gate → build native → thử ảnh có/không có mặt, nhiều mặt, vùng chọn, lớp khóa, cường độ 0, thiếu helper, ảnh trên 13 MP → đối chiếu kết quả/lịch sử, undo/redo, đổi tài liệu → kiểm tra theme sáng/tối và bảng hẹp → đóng gói app.
