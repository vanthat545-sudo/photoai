
2026-10-26: v0.7.7 source fixes 12MP budget and red-center target mask. Static checks only; Rust/Mac runtime blocked by unavailable toolchain. See PHOTOAI-v0.7.7-TEST-STATUS.md.

2026-10-26 v0.7.8: four automatic tonal actions, neutral-only WB, histogram exposure/contrast; zero-strength, remaining effects image budget, implausible mouth fallback and installer identity fixes. Static checks pass; Rust/native/visual gates pending.

2026-10-26, v0.7.9 candidate: Added allowlisted atomic local automation and 8 automatic UI routes. Isolated COW document, commit once, strict input validation, actual-document no-change detection, explicit platform warnings. Added 7 Rust regressions (not run). Source contracts and 4 gate orchestration checks executed; engine/UI/Vision blocked by missing Cargo. No native app or screenshot claimed. See PHOTOAI-v0.7.9-TEST-STATUS.md.

2026-10-26 v0.7.10: centralized Retouch outcome feedback based on actual document changes; inline result panel; five new Rust tests not run. Static/gate checks pass; native gates blocked by missing Cargo.
