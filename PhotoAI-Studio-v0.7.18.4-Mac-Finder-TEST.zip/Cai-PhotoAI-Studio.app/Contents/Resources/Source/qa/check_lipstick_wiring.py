#!/usr/bin/env python3
"""Static integration gate; Rust + Apple Vision runtime still require macOS."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = (root/'crates/engine/src/retouch_cmds/ai_lipstick.rs').read_text()
bridge = (root/'crates/engine/src/retouch_cmds/photo_ai_effects.rs').read_text()
vision = (root/'native/macos/PhotoAIVision.swift').read_text()
ui = (root/'crates/ui-egui/src/panels.rs').read_text()
mod = (root/'crates/engine/src/retouch_cmds.rs').read_text()
checks = {
    'Rust module registered': 'mod ai_lipstick;' in mod,
    'Lipstick blending helper is defined in module': 'fn mix(a: f32, b: f32, weight: f32) -> f32' in src,
    'No-Lasso branch routes to Apple Vision lips': 'return super::ai_lipstick::run(s, p, lip, strength);' in bridge,
    'Apple Vision provides precise lip polygons': 'outerLipsPoints' in vision and 'innerLipsPoints' in vision,
    'Inner lip/teeth protected': 'in_polygon(&lip.inner, x, y)' in src,
    'Real image pixels are written': 'surf.write_region(area, &out);' in src,
    'One undoable stroke used': 'run_stroke(s, "AI Lipstick (Apple Vision contours)"' in src,
    'Mac studio has actual apply control': 'Áp dụng màu son đã chọn' in ui,
    'Legacy UI apply no longer requires Lasso': 'ui.add_enabled(has_pixels, egui::Button::new("💄 Đổi màu son môi"))' in ui,
    'Rust synthetic pixel regression present': 'fn lipstick_command_changes_only_lips_and_can_undo()' in src,
    'Clear warning for unrecognized lips': 'Apple Vision chưa nhận diện được viền môi' in src,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + name)
assert all(checks.values()), 'Lipstick wiring regression'
