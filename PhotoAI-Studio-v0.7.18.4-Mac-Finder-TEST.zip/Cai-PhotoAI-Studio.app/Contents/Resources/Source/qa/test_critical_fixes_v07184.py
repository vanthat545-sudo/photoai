#!/usr/bin/env python3
"""Static contracts for PhotoAI 0.7.18.4; Rust/macOS runtime tests still required."""
import unittest
from pathlib import Path
R = Path(__file__).resolve().parents[1]
class CriticalFixTests(unittest.TestCase):
    def test_vision_preflight_and_cleanup(self):
        s=(R/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
        swift=(R/'native/macos/PhotoAIVision.swift').read_text()
        self.assertIn('const MAX_VISION_DIM: usize = 8000;',s)
        self.assertIn('width <= 8000, height <= 8000',swift)
        self.assertIn('if !valid_vision_image(width, height, pixels.len())',s)
        self.assertIn('child.try_wait()',s)
        self.assertIn('let _ = child.kill();',s)
        self.assertIn('swift_helper_limits_match_rust_preflight',s)
    def test_blemish_heal_uses_original_donors(self):
        s=(R/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
        self.assertIn('let donors = Region::read(original, window);',s)
        self.assertIn('w,h,donors.ch,&donors.data,&hole,&source',s)
        self.assertIn('let original = pre.layer(layer_id).and_then(|layer| layer.surface())',s)
        self.assertIn('guarded_heal_spot(surf, original, zone',s)
    def test_no_op_brush_reports_no_change(self):
        s=(R/'crates/ui-egui/src/retouch_ui.rs').read_text()
        self.assertIn('if stroke_has_damage(&result)',s)
        self.assertIn('KHÔNG THAY ĐỔI — cọ xóa mụn',s)
        self.assertIn('no_op_is_not_reported_as_a_successful_heal',s)
        self.assertIn('coords[2] > 0 && coords[3] > 0',s)
    def test_gate_is_part_of_installer(self):
        s=(R/'BUILD-PREVIEW-MAC.command').read_text()
        self.assertLess(s.index('python3 qa/test_critical_fixes_v07184.py'),s.index('cargo test --locked -p photocraft-engine --lib'))
if __name__=='__main__': unittest.main(verbosity=2)
