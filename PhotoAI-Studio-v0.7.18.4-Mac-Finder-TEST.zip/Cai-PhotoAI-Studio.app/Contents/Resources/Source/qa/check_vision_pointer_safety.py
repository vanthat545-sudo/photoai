#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"native/macos/PhotoAIVision.swift"
s=p.read_text()
assert "UnsafeBufferPointer(start:" not in s, "Dangerous Swift buffer pointer remains"
assert "let coords = points.normalizedPoints" in s
assert "let coords = feature.normalizedPoints" in s
assert "outerLipsPoints" in s and "innerLipsPoints" in s
print("PASS Vision helper reads owned normalizedPoints arrays; contours preserved")
