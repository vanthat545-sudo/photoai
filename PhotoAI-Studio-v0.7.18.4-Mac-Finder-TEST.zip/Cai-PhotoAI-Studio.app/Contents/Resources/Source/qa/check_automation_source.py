"""Source contracts only: no Rust execution, no image-quality claim."""
from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
engine=(r/'crates/engine/src/retouch_cmds/auto_workflow.rs').read_text()
registry=(r/'crates/engine/src/retouch_cmds.rs').read_text()
ui=(r/'crates/ui-egui/src/panels.rs').read_text()
assert 'mod auto_workflow;' in registry
assert 'id: "paint.photoAiAuto"' in registry and 'run: auto_workflow::run' in registry
assert 'crate::photo_ai_feedback::run(app, "paint.photoAiAuto"' in ui
for label,goal in [('AI tự chỉnh','auto'),('AI chân dung','portrait'),('AI xoá mụn','blemish'),('AI chỉnh da','skin')]:
    assert f'("{label}", "{goal}")' in ui
for goal in ['tone','exposure','whiteBalance','contrast']:
    assert f'Some("{goal}")' in ui
assert engine.split('#[cfg(test)]')[0].count('s.edit(')==1
assert engine.index('dispatch(&mut work') < engine.index('s.edit(')
assert '"protectEyes":true,"protectLips":true' in engine
assert 'let changed = **after != *prior;' in engine
assert len(re.findall(r'#\[test\]',engine))==9
print('PASS source contracts: registration, 8 UI routes, isolated dispatch/one commit, guards, document-based change check')
print('PRESENT NOT RUN: 9 Rust tests. NOT VERIFIED: compilation, actual UI or image quality.')
