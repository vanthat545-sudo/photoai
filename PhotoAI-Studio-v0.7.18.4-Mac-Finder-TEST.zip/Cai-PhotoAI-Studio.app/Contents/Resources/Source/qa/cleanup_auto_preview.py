#!/usr/bin/env python3
"""Cleanup after a verified successful Preview launch. Never touch user data.

Only the own, identified Preview backups in ~/Applications and the current
source tree's *local* target directory qualify for deletion.
"""
import argparse
import plistlib
import re
import shutil
from pathlib import Path

BUNDLE_ID = "local.photoai.retouch.preview"
BACKUP_NAME = re.compile(r"^PhotoAI Retouch Preview-backup-\d{8}-\d{6}-\d+\.app$")
APP_NAME = "PhotoAI Retouch Preview.app"


def bundle_id(app: Path) -> str | None:
    try:
        with (app / "Contents/Info.plist").open("rb") as f:
            return plistlib.load(f).get("CFBundleIdentifier")
    except (OSError, ValueError, TypeError, plistlib.InvalidFileException):
        return None


def cleanup(app_dir: Path, installed_app: Path, build_root: Path) -> list[str]:
    """Returns activity messages. Safe to call repeatedly (idempotent)."""
    messages = []
    # Do not permit any symlink at these boundaries or wrong bundle to trigger deletion.
    if app_dir.is_symlink() or installed_app.is_symlink() or not app_dir.is_dir():
        raise ValueError("Invalid application directory or symlink")
    if installed_app.parent != app_dir or installed_app.name != APP_NAME:
        raise ValueError("Installed app is not the expected Preview path")
    if bundle_id(installed_app) != BUNDLE_ID or not (installed_app / "Contents/MacOS/photocraft").is_file():
        raise ValueError("Installed Preview identity/binary verification failed")
    for app in sorted(app_dir.iterdir()):
        if not BACKUP_NAME.fullmatch(app.name):
            continue
        if app.is_symlink() or not app.is_dir():
            messages.append(f"BỎ QUA liên kết/lỗi kiểu: {app.name}")
            continue
        if bundle_id(app) != BUNDLE_ID:
            messages.append(f"BỎ QUA app không cùng bundle ID: {app.name}")
            continue
        try:
            shutil.rmtree(app)
            messages.append(f"ĐÃ XÓA Preview dự phòng cũ: {app.name}")
        except OSError as e:
            messages.append(f"KHÔNG XÓA ĐƯỢC {app.name}: {e}")
    # Only delete this source tree's non-symlink local Cargo target.
    # Never delete CARGO_TARGET_DIR (user-customized shared build directory).
    import os
    target = build_root / "target"
    if os.environ.get("CARGO_TARGET_DIR"):
        messages.append("GIỮ target: CARGO_TARGET_DIR tùy chỉnh")
    elif build_root.is_symlink() or target.is_symlink():
        messages.append("GIỮ target: nguồn hoặc target là symlink")
    elif target.is_dir() and build_root.joinpath("Cargo.toml").is_file():
        try:
            shutil.rmtree(target)
            messages.append("ĐÃ XÓA cache biên dịch của bản đang cài: target/")
        except OSError as e:
            messages.append(f"KHÔNG XÓA ĐƯỢC target/: {e}")
    else:
        messages.append("Không có cache target/ cần dọn")
    return messages


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--app-dir", type=Path, required=True)
    parser.add_argument("--installed-app", type=Path, required=True)
    parser.add_argument("--build-root", type=Path, required=True)
    args = parser.parse_args()
    try:
        for msg in cleanup(args.app_dir, args.installed_app, args.build_root):
            print(msg)
    except (ValueError, OSError) as e:
        print(f"TỪ CHỐI dọn: {e}")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
