#!/usr/bin/env python3
"""Static gate for v0.7.16 source bundle. This is not a native Rust/macOS test."""
from pathlib import Path
import struct
root = Path(__file__).resolve().parents[1]
ui = (root/'crates/ui-egui/src/panels.rs').read_text()
lib = (root/'crates/ui-egui/src/lib.rs').read_text()
build = (root/'BUILD-PREVIEW-MAC.command').read_text()
engine = (root/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
icon = root/'assets/app-icon/PhotoAI-Pro.icns'
svg = (root/'assets/icons/retouch-hood.svg').read_text()
def check(ok: bool, message: str):
    assert ok, message
    print('PASS', message)
check('unwrap_or(!cfg!(test))' in ui, 'Studio launch default + native test isolation')
check('"Chuyên sâu ↗"' in ui and '"Gắn lại"' in ui, 'Advanced workspace + detachable Router')
check(all(x in ui for x in ('"Tự động"','"Chân dung"','"Làm đẹp"','"Màu sắc"','"Hiệu ứng"')), 'All five Studio categories visible')
check('photo_ai_studio_looks_strip(self, ui);' in lib, 'Preset strip wired into main UI')
check('Mở khóa lớp ảnh để chỉnh sửa' in ui and 'simple_lock_toggle(' in ui, 'Explicit Background layer unlock')
check('"Độ nhạy"' in ui and '"sensitivity":sensitivity' in ui, 'Blemish sensitivity connected to engine command')
check('let sensitivity = num(p, "sensitivity", 92.0)' in engine and 'auto_blemish::detect_dense' in engine, 'Blemish sensitivity read by engine')
check('"💄 Áp dụng màu son đã chọn"' in ui and '"lipColor":color' in ui, 'Chosen lip colour wired into pixel effect')
check('photo_ai_studio_active(ctx)' in lib and 'ThemeKind::Studio' in lib, 'Studio palette set in app runtime')
check('fill="none"' in svg and '<path' in svg and 'fill="currentColor"' in svg, 'Vector hacker-hat icon, not blurred raster')
check(icon.is_file() and icon.read_bytes()[:4]==b'icns', 'Packaged app icon is .icns')
check('PhotoAI-Pro.icns' in build and 'CFBundleIconFile' in build, 'Matching Finder/Dock icon linked in bundle')
check('cargo test --locked -p photocraft-engine --lib' in build and 'cargo test --locked -p photocraft-ui-egui --lib' in build, 'Rust engine and UI test gates')
check('codesign --verify --strict --deep' in build and 'mv "$DEST" "$BACKUP"' in build, 'Codesign verification and backup before installation')
check('qa/check_integrated_release.py' in build and 'qa/check_lipstick_wiring.py' in build, 'Integrated and lipstick QA pre-install')
check('CHƯA CÓ' in (root/'PHOTOAI-v0.7.16-CHUC-NANG-VA-KIEM-THU.md').read_text(), 'Unimplemented AI features documented honestly')
print('PASS static v0.7.16 source QA. Rust/macOS tests NOT executed here.')
