"""Static preview safety checks. Does not imply native Rust/macOS tests passed."""
import struct
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class PreviewGateSafety(unittest.TestCase):
    def test_router_preset_header_closes_horizontal_scope(self):
        """Regression: panels.rs missing `});` broke 1746-pass Rust build."""
        source=(ROOT/'crates/ui-egui/src/panels.rs').read_text()
        header='ui.strong("BỘ MÀU TIẾNG VIỆT · 10 NHÓM × 12 MÀU");'
        explanation='ui.small("120 lựa chọn đánh số theo nhóm'
        self.assertEqual(source.count(header), 1)
        start=source.index(header)+len(header)
        end=source.index(explanation, start)
        self.assertEqual(source[start:end].strip(), '});',
                         'Thiếu đóng ui.horizontal ngay sau tiêu đề bộ màu')

    def test_regression_lip_x45_excluded(self):
        code=(ROOT/'crates/engine/src/retouch_cmds/ai_auto_retouch.rs').read_text()
        self.assertIn('let mx = ((r.width() as f32) * 0.35).ceil().max(16.0)',code)
        self.assertIn('smoothing_never_reads_pink_lip_pixel_through_a_skin_boundary',code)
        self.assertIn('small_mouth_lip_guard_excludes_all_padding_boundary_donors',code)
        # Simulate exact geometry and edge condition of the reported regression.
        x=45; bbox_left=58; padx=max(16, round(12*.35+0.49))
        self.assertTrue(x >= bbox_left-padx)
        self.assertIn('if !eligible_skin_guarded(zone, px, py, guards) || !skin_tone(q)',code)
        self.assertIn('source[i] = eligible && !at_spot && skin_tone(px);',code)

    def test_tests_run_before_swift_build_and_before_install(self):
        x=(ROOT/'BUILD-PREVIEW-MAC.command').read_text()
        sequence=[ 'cargo test --locked -p photocraft-engine --lib',
                   'cargo test --locked -p photocraft-ui-egui --lib',
                   'swiftc -framework Vision', 'cargo build --locked -p photocraft',
                   'cp "$BIN"', 'mv "$NEW" "$DEST"' ]
        # 'cp "$BIN"' precedes the final move; all actions must be gated by cargo test.
        pos=[x.index(k) for k in sequence]
        self.assertEqual(pos,sorted(pos))
        self.assertIn('set -euo pipefail',x)
        self.assertIn('local.photoai.retouch.preview',x)
        self.assertNotIn('rm -rf "$DEST"',x)

    def test_approved_icon_integrated(self):
        icon=ROOT/'assets/app-icon/PhotoAI-Pro.png'
        png = icon.read_bytes()
        self.assertEqual(png[:8],b'\x89PNG\r\n\x1a\n')
        self.assertEqual(struct.unpack('>II',png[16:24]),(1024,1024))
        b=(ROOT/'assets/app-icon/PhotoAI-Pro.icns').read_bytes()
        self.assertEqual(b[:4],b'icns')
        self.assertEqual(int.from_bytes(b[4:8],'big'),len(b))
        found=set(); at=8
        while at < len(b):
            tag=b[at:at+4].decode('ascii'); size=int.from_bytes(b[at+4:at+8],'big')
            self.assertGreater(size,8)
            self.assertLessEqual(at+size,len(b))
            if tag != 'TOC ':
                self.assertEqual(b[at+8:at+16],b'\x89PNG\r\n\x1a\n')
                found.add(tag)
            at+=size
        self.assertEqual(at,len(b))
        self.assertTrue({'ic07','ic08','ic09','ic10'}.issubset(found))
        preview=(ROOT/'BUILD-PREVIEW-MAC.command').read_text()
        self.assertIn('PhotoAI-Pro.icns',preview)
        # Legacy installer name must now forward to the gated independent Preview.
        # Do not permit replacing a previously installed PhotoAI.app by accident.
        alias=(ROOT/'Build-and-Install-PhotoAI-Mac.command').read_text()
        self.assertIn('exec bash ./BUILD-PREVIEW-MAC.command',alias)
        self.assertNotIn('DEST="$HOME/Applications/PhotoAI.app"',alias)
        runtime=(ROOT/'apps/photocraft/src/app_icon.rs').read_text()
        self.assertIn('include_bytes!("../../../assets/app-icon/PhotoAI-Pro.png")',runtime)

if __name__=='__main__': unittest.main(verbosity=2)
