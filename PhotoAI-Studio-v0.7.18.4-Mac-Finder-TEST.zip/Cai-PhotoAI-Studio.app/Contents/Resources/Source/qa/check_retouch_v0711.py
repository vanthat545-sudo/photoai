"""Source contracts only; does not compile Rust or validate image output."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class RetouchContracts(unittest.TestCase):
    def test_smoothing_uses_guarded_workflow(self):
        text=(ROOT/'crates/ui-egui/src/panels.rs').read_text()
        branch=text.split('} else if *effect == "skinSmooth" {',1)[1].split('} else if',1)[0]
        self.assertIn('photo_ai_apply_automation(app, "skin", strength)',branch)
        self.assertNotIn('photo_ai_apply_effect',branch)
    def test_history_is_separate_scoped_and_bounded(self):
        text=(ROOT/'crates/ui-egui/src/photo_ai_feedback.rs').read_text()
        self.assertIn('entry.doc == doc',text)
        self.assertIn('saturating_sub(20)',text)
        self.assertIn('remember(app, details)',text)
        state=(ROOT/'crates/ui-egui/src/state.rs').read_text()
        self.assertIn('#[serde(skip)]\n    pub retouch_results:',state)
    def test_tiles_wrap_and_use_theme(self):
        text=(ROOT/'crates/ui-egui/src/panels.rs').read_text()
        body=text.split('fn photo_ai_tile(',1)[1].split('fn photo_ai_tile_group',1)[0]
        self.assertIn('Tokens::get',body)
        self.assertIn('ui.painter().layout(',body)
        self.assertIn('with_clip_rect(rect)',body)
        self.assertNotIn('Color32::from_rgb',body)
    def test_nested_warning_and_dry_run_regressions_present(self):
        text=(ROOT/'crates/engine/src/retouch_cmds/auto_workflow.rs').read_text()
        self.assertIn('warnings.push(warning.to_owned())',text)
        self.assertIn('dryRun must be a boolean',text)
        self.assertIn('fn workflow_keeps_nested_warnings()',text)
        self.assertIn('fn malformed_dry_run_never_dispatches_or_changes_document()',text)
if __name__=='__main__': unittest.main(verbosity=2)
