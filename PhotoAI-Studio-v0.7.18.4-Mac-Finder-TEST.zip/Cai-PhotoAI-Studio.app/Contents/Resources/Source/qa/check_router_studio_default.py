#!/usr/bin/env python3
"""Check default Photo AI Studio does not destructively overwrite the native dock.

These are static invariants, not proof of successful Rust compilation or UI rendering.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=(root/'crates/ui-egui/src/panels.rs').read_text()
lib=(root/'crates/ui-egui/src/lib.rs').read_text()
assert 'fn photo_ai_studio_active(ctx: &egui::Context)' in p
assert '.unwrap_or(!cfg!(test))' in p, 'production must default to Photo AI Studio, native tests remain separate'
assert 'if photo_ai_studio_active(ui.ctx()) {\n        photo_ai_studio_dock(app, ui);\n        return;' in p
assert 'photo_ai_studio_looks_strip(self, ui);' in lib
assert '"Chuyên sâu ↗"' in p
assert '"Tách bảng"' in p and '"Gắn lại"' in p
assert 'fn photo_ai_studio_toolbar(' in p
assert '.resizable(true).movable(true)' in p
assert '"Văn bản"' in p and '"Cắt ảnh"' in p
assert '"photo-ai-studio-mode"), false' in p
assert '"photo-ai-studio-mode"), true' in p
for name in ['Tự động','Chân dung','Làm đẹp','Màu sắc','Hiệu ứng']:
    assert name in p, f'missing Router category: {name}'
assert len(p.split('const PHOTO_AI_STUDIO_GROUPS:')[1].split('];',1)[0].split('("'))>=10
for effect in ['autoBlemish','spotBrush','skinSmooth','lipstick','faceSlim','proSharpen','proHsl']:
    assert f'"{effect}"' in p, f'UI action not wired: {effect}'
for feature in ['rainOverlay','snowOverlay','Đổi nền AI · chưa hỗ trợ']:
    assert feature in p, f'missing supported/disabled feature: {feature}'
start=p.index('fn dock_panels(')
stop=p.index('/// One dock group',start)
assert 'photo_ai_portrait_panel(' not in p[start:stop]
assert 'crate::dock::show(app, ui, &shown, dock_body)' in p[start:stop]
print('PASS: production Studio UI with 5 categories, preset strip; original dock/test mode retained')
