#!/usr/bin/env python3
"""Static source contract; DOES NOT replace compilation or real photo QA."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
ui=(root/'crates/ui-egui/src/panels.rs').read_text()
engine=(root/'crates/engine/src/retouch_cmds/photo_ai_effects.rs').read_text()
icons=(root/'crates/ui-egui/src/icon_data.rs').read_text()
features=["rainOverlay","snowOverlay","bokehOverlay","glowOverlay"]
for effect in features:
    assert re.search(r'"'+effect+r'"',ui), 'UI missing '+effect
    assert re.search(r'"'+effect+r'"',engine), 'Engine missing '+effect
    print('PASS UI -> engine',effect)
for icon in ["tool-spot","tool-smooth","tool-undereye","tool-bright","tool-face",
             "tool-contour","tool-eyelid","tool-eye-color","tool-blush","tool-skin-tone",
             "tool-hair","tool-fabric","tool-legs","weather-rain","weather-snow",
             "weather-bokeh","weather-glow"]:
    assert f'"{icon}"' in icons and (root/'assets/icons'/f'{icon}.svg').exists(), icon
print('PASS 17 distinct new icons')
assert 'variantIndex' in ui and 'variantIndex' in engine and 'preset_variant(' in engine
assert 'all_120_colour_variants_are_bounded_and_reproducible' in engine
assert 'artistic_overlays_modify_only_target_channels_and_are_repeatable' in engine
assert (root/'assets/icons/ai-router-hacker-3d.png').stat().st_size > 10_000
assert 'Photo AI.app' not in (root/'BUILD-PREVIEW-MAC.command').read_text().split('DEST=')[1].splitlines()[0]
print('PASS 120 independent variant parameters and deterministic overlay unit tests are present')
print('Static gate passed; Rust/macOS test and image quality still unverified')
