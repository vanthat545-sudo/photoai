#!/usr/bin/env python3
"""Static regression guard: AI Router must not steal space from native dock."""
from pathlib import Path
src=Path(__file__).resolve().parents[1]/'crates/ui-egui/src/panels.rs'
s=src.read_text()
start=s.index('fn dock_panels(')
stop=s.index('/// One dock group',start)
dock=s[start:stop]
assert 'photo_ai_portrait_panel(' not in dock, 'Router must never take height away from the native dock'
assert 'photo_ai_detach(' not in dock
assert 'crate::dock::show(app, ui, &shown, dock_body);' in dock
assert '"retouch-hood", rb' in s and 'Mở / đóng AI Router' in s
assert 'if !photo_ai_is_floating(ctx) { return; }' in s
assert '.open(&mut open)' in s
assert '.default_size(vec2(318.0, 470.0))' in s
assert 'photo_ai_portrait_panel(app, ui)' in s
print('PASS: original dock retained, optional 318px floating Router still accessible in advanced mode')
