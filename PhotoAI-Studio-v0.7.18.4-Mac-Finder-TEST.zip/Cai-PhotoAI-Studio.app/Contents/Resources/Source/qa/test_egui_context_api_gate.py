#!/usr/bin/env python3
"""Fast regression guard for the egui Context API; runs BEFORE expensive Rust tests.
This does not replace cargo test or running the app on macOS.
"""
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class ContextApiRegression(unittest.TestCase):
    def test_dashboard_uses_egui_036_context_rect(self):
        panels=(ROOT/'crates/ui-egui/src/panels.rs').read_text(encoding='utf-8')
        self.assertIn('ui.ctx().content_rect().width()', panels)
        self.assertNotIn('ui.ctx().available_rect()', panels, 'egui 0.36 has no Context.available_rect; E0599')
    def test_existing_context_api_used_elsewhere(self):
        source=(ROOT/'crates/ui-egui/src/titlebar.rs').read_text(encoding='utf-8')
        self.assertIn('ui.ctx().content_rect()', source)
    def test_gate_precedes_compilation(self):
        installer=(ROOT/'BUILD-PREVIEW-MAC.command').read_text(encoding='utf-8')
        self.assertLess(installer.index('python3 qa/test_egui_context_api_gate.py'),
                        installer.index('cargo test --locked -p photocraft-engine --lib'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
