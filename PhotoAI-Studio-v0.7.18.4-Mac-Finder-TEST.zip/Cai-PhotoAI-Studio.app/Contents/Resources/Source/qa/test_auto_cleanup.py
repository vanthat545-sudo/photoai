"""Cleanup safety: do not delete other apps, symlinks, projects, backups."""
import importlib.util
import os
import plistlib
import tempfile
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("photoai_cleanup", Path(__file__).with_name("cleanup_auto_preview.py"))
cleanup_mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cleanup_mod)


def make_app(parent, name, ident):
    app = parent / name
    (app / "Contents/MacOS").mkdir(parents=True)
    (app / "Contents/MacOS/photocraft").write_bytes(b"test")
    with (app / "Contents/Info.plist").open("wb") as f:
        plistlib.dump({"CFBundleIdentifier": ident}, f)
    return app


class AutoCleanupTests(unittest.TestCase):
    def setUp(self):
        self.ctx = tempfile.TemporaryDirectory()
        self.addCleanup(self.ctx.cleanup)
        self.root = Path(self.ctx.name)
        self.apps = self.root / "Applications"
        self.apps.mkdir()
        self.installed = make_app(self.apps, cleanup_mod.APP_NAME, cleanup_mod.BUNDLE_ID)
        self.source = self.root / "PhotoAI-Source"
        self.source.mkdir()
        (self.source / "Cargo.toml").touch()
        (self.source / "target/debug").mkdir(parents=True)
        (self.source / "target/debug/temp").touch()

    def test_removes_only_owned_backups_and_local_cache(self):
        old = make_app(self.apps, "PhotoAI Retouch Preview-backup-20261027-175901-1357.app", cleanup_mod.BUNDLE_ID)
        other = make_app(self.apps, "PhotoAI Retouch Preview-backup-20261027-175902-1358.app", "another.bundle.id")
        original = make_app(self.apps, "Photo AI.app", "other.photo.ai")
        project = self.root / "my-photo-project.phai"
        project.write_text("important data")
        messages = cleanup_mod.cleanup(self.apps, self.installed, self.source)
        self.assertFalse(old.exists())
        self.assertTrue(other.exists())
        self.assertTrue(original.exists())
        self.assertTrue(self.installed.exists())
        self.assertTrue(project.exists())
        self.assertFalse((self.source / "target").exists())
        self.assertTrue((self.source / "Cargo.toml").exists())
        self.assertTrue(any("ĐÃ XÓA" in line for line in messages))

    def test_refuses_wrong_install_identity(self):
        with (self.installed / "Contents/Info.plist").open("wb") as f:
            plistlib.dump({"CFBundleIdentifier": "evil.app"}, f)
        with self.assertRaises(ValueError):
            cleanup_mod.cleanup(self.apps, self.installed, self.source)
        self.assertTrue((self.source / "target").exists())

    def test_symlink_backup_is_not_followed(self):
        external = self.root / "external"
        external.mkdir()
        (external / "preserve.txt").write_text("keep")
        link = self.apps / "PhotoAI Retouch Preview-backup-20261027-175901-1357.app"
        link.symlink_to(external, target_is_directory=True)
        cleanup_mod.cleanup(self.apps, self.installed, self.source)
        self.assertTrue(link.is_symlink())
        self.assertTrue((external / "preserve.txt").exists())

    def test_custom_target_not_removed(self):
        old = os.environ.get("CARGO_TARGET_DIR")
        os.environ["CARGO_TARGET_DIR"] = str(self.root / "custom")
        try:
            cleanup_mod.cleanup(self.apps, self.installed, self.source)
            self.assertTrue((self.source / "target").exists())
        finally:
            if old is None:
                os.environ.pop("CARGO_TARGET_DIR", None)
            else:
                os.environ["CARGO_TARGET_DIR"] = old

    def test_multiple_runs_safe(self):
        cleanup_mod.cleanup(self.apps, self.installed, self.source)
        cleanup_mod.cleanup(self.apps, self.installed, self.source)
        self.assertTrue(self.installed.exists())


if __name__ == "__main__":
    unittest.main()
