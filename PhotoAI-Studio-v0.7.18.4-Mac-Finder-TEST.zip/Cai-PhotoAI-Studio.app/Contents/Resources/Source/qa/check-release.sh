#!/bin/bash
# Automated source gate. Passing does not replace native Mac visual acceptance.
set -euo pipefail
cd "$(dirname "$0")/.."
for tool in cargo rustc python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "BLOCKED: missing $tool; release tests have NOT passed." >&2
        exit 2
    fi
done
python3 qa/test_preview_gate.py
python3 qa/check_automation_source.py
python3 qa/check_retouch_v0711.py
python3 qa/test_egui_context_api_gate.py
python3 qa/test_critical_fixes_v07184.py
cargo test --locked -p photocraft-engine
cargo test --locked -p photocraft-ui-egui
cargo clippy --locked -p photocraft-engine -p photocraft-ui-egui --all-targets -- -D warnings
cargo xtask layers
cargo xtask wasm
cargo test --locked -p photocraft-engine --test panic_hunt -- --ignored
echo 'AUTOMATED GATE PASSED. Mac UI, Vision, image quality and installer acceptance are still required.'
