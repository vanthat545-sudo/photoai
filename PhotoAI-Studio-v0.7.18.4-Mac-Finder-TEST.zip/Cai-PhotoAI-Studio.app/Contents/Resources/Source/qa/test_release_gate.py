"""Test gate orchestration with fake tools; these do NOT test the Rust engine."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ReleaseGateTests(unittest.TestCase):
    def run_gate(self, failure='', missing=False):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            log = base / 'calls'
            for name in ['dirname', 'cargo', 'rustc', 'python3']:
                if missing and name == 'cargo':
                    continue
                body = '#!/bin/bash\n'
                if name == 'dirname':
                    body += '/usr/bin/dirname "$@"\n'
                else:
                    body += 'printf "%s\\n" "' + name + ' $*" >> "$GATE_TEST_LOG"\n'
                    body += 'if [[ "' + name + ' $*" == "$GATE_TEST_FAIL" ]]; then exit 42; fi\n'
                file = base / name
                file.write_text(body)
                file.chmod(0o755)
            env = dict(os.environ, PATH=tmp, GATE_TEST_LOG=str(log), GATE_TEST_FAIL=failure)
            p = subprocess.run(['/bin/bash', str(ROOT/'qa/check-release.sh')], env=env, text=True, capture_output=True)
            calls = log.read_text().splitlines() if log.exists() else []
            return p, calls

    def test_missing_tool_blocks_without_running_checks(self):
        p, calls = self.run_gate(missing=True)
        self.assertEqual(p.returncode, 2)
        self.assertIn('missing cargo', p.stderr)
        self.assertEqual(calls, [])

    def test_failed_engine_test_stops_later_checks(self):
        p, calls = self.run_gate('cargo test --locked -p photocraft-engine')
        self.assertEqual(p.returncode, 42)
        self.assertEqual(len(calls), 6)
        self.assertNotIn('AUTOMATED GATE PASSED', p.stdout)

    def test_all_commands_execute_in_order(self):
        p, calls = self.run_gate()
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(calls, [
            'python3 qa/test_preview_gate.py',
            'python3 qa/check_automation_source.py',
            'python3 qa/check_retouch_v0711.py',
            'python3 qa/test_egui_context_api_gate.py',
            'python3 qa/test_critical_fixes_v07184.py',
            'cargo test --locked -p photocraft-engine',
            'cargo test --locked -p photocraft-ui-egui',
            'cargo clippy --locked -p photocraft-engine -p photocraft-ui-egui --all-targets -- -D warnings',
            'cargo xtask layers', 'cargo xtask wasm',
            'cargo test --locked -p photocraft-engine --test panic_hunt -- --ignored'])

    def test_installer_gate_precedes_build_and_install(self):
        alias = (ROOT/'Build-and-Install-PhotoAI-Mac.command').read_text()
        self.assertIn('exec bash ./BUILD-PREVIEW-MAC.command', alias)
        text = (ROOT/'BUILD-PREVIEW-MAC.command').read_text()
        sequence = ['python3 qa/test_release_gate.py',
                    'cargo test --locked -p photocraft-engine --lib',
                    'cargo test --locked -p photocraft-ui-egui --lib',
                    'swiftc -framework Vision', 'cargo build --locked -p photocraft',
                    'mv "$NEW" "$DEST"']
        pos = [text.index(piece) for piece in sequence]
        self.assertEqual(pos, sorted(pos), 'all tests must precede building/installing Preview')

if __name__ == '__main__':
    unittest.main(verbosity=2)
