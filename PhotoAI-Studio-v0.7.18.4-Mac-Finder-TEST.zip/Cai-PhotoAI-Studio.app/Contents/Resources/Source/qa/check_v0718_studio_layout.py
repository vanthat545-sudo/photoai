#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=(root/'crates/ui-egui/src/panels.rs').read_text()
l=(root/'crates/ui-egui/src/lib.rs').read_text()
def check(value,label):
    assert value,label
    print('PASS',label)
check('fn studio_rail_button(' in p and '"Mở ảnh"' in p and '"Lưu ảnh"' in p, 'Functional left toolbar')
check('"SÁNG TẠO"' in p and '"PRESET MÀU"' in p and '"CHUYÊN SÂU"' in p and '"AI NÂNG CAO · CHƯA HỖ TRỢ"' in p, 'Four-section bottom dashboard')
check('"photo-ai-studio-feature-dashboard"' in p and '.exact_size(223.0)' in p,'Full-width lower dashboard')
check(l.index('panels::photo_ai_studio_looks_strip(self, ui);') < l.index('panels::toolbar(self, ui);'), 'Dashboard reserves full-width before side docks')
check('"photo-ai-auto-feature-grid"' in p and '"tool-spot"' in p, 'Icon-card automatic editing workspace')
check('"unsupported" => ' not in p or 'else if *effect=="unsupported" {false}' in p,'Generative AI tiles remain disabled')
check('"bytes://photo-ai-router-hacker-3d.png"' in p and 'vec2(54.0, 54.0)' in p, 'Clearer large 3D Router icon')
check('"Chuyên sâu ↗"' in p and '"photo-ai-studio-mode"' in p,'Retains native advanced workspace')
check('every_studio_tab_and_dashboard_renders_without_an_open_document' in p,'Native Studio render smoke regression test added')
print('STATIC UI CONTRACT ONLY – native Mac tests still required')
