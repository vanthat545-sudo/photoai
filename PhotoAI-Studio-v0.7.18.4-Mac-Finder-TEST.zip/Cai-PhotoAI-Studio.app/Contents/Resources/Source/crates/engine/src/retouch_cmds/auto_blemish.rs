//! Experimental *classical image processing* blemish detector for Photo AI.
//!
//! NOT a trained AI model. Detects small red spots in the raster layer.
//! If the user provides a selection it is respected; otherwise the command scans
//! the entire raster canvas under a conservative skin-color prior. AUTO without
//! segmentation is less reliable than selecting a face. Preserves one undo step.
//! One command / one undo step. No network calls or external model dependencies.

use super::*;

const CMD: &str = "paint.autoBlemish";
// Full-image scans may use more memory, so cap the region on an 8GB Mac.
const MAX_REGION_PIXELS: usize = 13_000_000;

#[derive(Debug, Clone, Copy, PartialEq)]
pub(super) struct Spot {
    pub(super) x: i32,
    pub(super) y: i32,
    pub(super) score: f32,
}

/// Find local red-excess peaks relative to a ring of surrounding skin.
/// `rgba` stores straight RGBA; `rect` corresponds to row-major pixels.
pub(super) fn detect(
    rgba: &[[f32; 4]],
    rect: Rect,
    selection: Option<&Surface>,
    size: f32,
    sensitivity: f32,
    limit: usize,
) -> Vec<Spot> {
    let w = rect.width() as usize;
    let h = rect.height() as usize;
    if w == 0 || h == 0 || rgba.len() != w * h {
        return vec![];
    }
    let ring = (size * 0.78).round().clamp(5.0, 24.0) as i32;
    let min_extent = (ring * 2 + 4) as usize; // ring is clamped to 5..=24.
    if w <= min_extent || h <= min_extent {
        return vec![];
    }
    let off = [
        (-ring, 0), (ring, 0), (0, -ring), (0, ring),
        (-ring, -ring), (ring, ring), (ring, -ring), (-ring, ring),
    ];
    let sample = |x: i32, y: i32| -> [f32; 4] {
        rgba[(y - rect.y0) as usize * w + (x - rect.x0) as usize]
    };
    let redness = |c: [f32; 4]| c[0] - (c[1] + c[2]) * 0.5;
    let light = |c: [f32; 4]| c[0] * 0.299 + c[1] * 0.587 + c[2] * 0.114;
    let mut found = Vec::new();
    let threshold = (0.094 - 0.00064 * sensitivity).clamp(0.025, 0.085);
    // Large full-frame scans sample more sparsely, while small photos keep 2px detail.
    let stride = if w.saturating_mul(h) > 3_000_000 { 4 } else { 2 };
    for y in ((rect.y0 + ring + 2)..(rect.y1 - ring - 2)).step_by(stride) {
        for x in ((rect.x0 + ring + 2)..(rect.x1 - ring - 2)).step_by(stride) {
            if selection.is_some_and(|sel| sel.sample_channel(x, y, 0) < 0.98) {
                continue;
            }
            // Average 3x3 to reject single hot pixels/compression artifacts.
            let mut center = [0.0f32; 4];
            for dy in -1..=1 {
                for dx in -1..=1 {
                    let px = sample(x + dx, y + dy);
                    for k in 0..4 { center[k] += px[k] / 9.0; }
                }
            }
            if center[3] < 0.9 { continue; }
            let mut surround = [0.0f32; 4];
            let mut var = 0.0f32;
            for (dx, dy) in off {
                let c = sample(x + dx, y + dy);
                for k in 0..4 { surround[k] += c[k] / 8.0; }
            }
            if surround[3] < 0.92 { continue; }
            // Broad skin-color prior; relative comparison works on diverse skin tones.
            if surround[0] < 0.11 || surround[1] < 0.075 || surround[0] < surround[2] * 0.91 {
                continue;
            }
            for (dx, dy) in off {
                let c = sample(x + dx, y + dy);
                var += (light(c) - light(surround)).abs() / 8.0;
            }
            // Facial features, hair and strong boundaries are too variable for automatic retouch.
            if var > 0.065 { continue; }
            let contrast = redness(center) - redness(surround);
            let dark = (light(surround) - light(center)).max(0.0);
            if contrast < threshold || dark > 0.23 { continue; }
            let score = contrast + 0.13 * dark - var * 0.30;
            found.push(Spot { x, y, score });
        }
    }
    found.sort_by(|a, b| b.score.total_cmp(&a.score));
    let sep2 = (size * 0.88).powi(2);
    let mut spots: Vec<Spot> = Vec::new();
    for c in found {
        if spots.iter().all(|p| ((p.x - c.x) as f32).powi(2) + ((p.y - c.y) as f32).powi(2) >= sep2) {
            spots.push(c);
            if spots.len() >= limit { break; }
        }
    }
    spots
}

/// Two-scale *candidate* finder for diffuse and scar-like blemishes. Unlike
/// the legacy red-only peak detector, it accepts local excess redness OR a
/// locally darker small mark; Apple Vision + protected masks are still mandatory.
/// This is a heuristic, not a trained acne classifier.
pub(super) fn detect_dense(
    rgba: &[[f32;4]], rect: Rect, selection: Option<&Surface>,
    sensitivity: f32, limit: usize,
) -> Vec<Spot> {
    let w=rect.width() as usize;
    let h=rect.height() as usize;
    if w<32 || h<32 || rgba.len()!=w*h || limit==0 {return vec![];}
    let lum = |c: [f32;4]| c[0]*0.299+c[1]*0.587+c[2]*0.114;
    let redness = |c: [f32;4]| c[0]-(c[1]+c[2])*0.5;
    let mut proposals:Vec<Spot>=Vec::new();
    let threshold=(0.043 - 0.00027*sensitivity).clamp(0.013,0.043);
    for ring in [5i32, 11i32] {
        let offsets=[(-ring,0),(ring,0),(0,-ring),(0,ring),(-ring,-ring),(ring,ring),(ring,-ring),(-ring,ring)];
        let stride=if w.saturating_mul(h)>1_500_000 { 4usize } else { 3usize };
        for yy in (ring as usize+2..h-ring as usize-2).step_by(stride) {
            for xx in (ring as usize+2..w-ring as usize-2).step_by(stride) {
                let x=rect.x0+xx as i32; let y=rect.y0+yy as i32;
                if selection.is_some_and(|sel|sel.sample_channel(x,y,0)<0.98) {continue;}
                let center=rgba[yy*w+xx];
                if center[3]<0.93 {continue;}
                let mut surround=[0.0f32;4];
                let mut brightness_span=0.0f32;
                for (dx,dy) in offsets {
                    let sample=rgba[(yy as i32+dy) as usize*w+(xx as i32+dx) as usize];
                    for k in 0..4 {surround[k]+=sample[k]/8.0;}
                }
                if surround[3]<0.90 || surround[0]<0.13 || surround[1]<0.08 || surround[0]<surround[2]*0.90 {continue;}
                for (dx,dy) in offsets {
                    let sample=rgba[(yy as i32+dy) as usize*w+(xx as i32+dx) as usize];
                    brightness_span+=(lum(sample)-lum(surround)).abs()/8.0;
                }
                // Exclude strong facial edges / stray hair, but allow textured acne.
                if brightness_span>0.13 {continue;}
                let red=(redness(center)-redness(surround)).max(0.0);
                let darker=(lum(surround)-lum(center)).max(0.0);
                if darker>0.19 {continue;}
                let score=(red + 0.55*darker) - brightness_span*0.22;
                if score>=threshold {proposals.push(Spot {x,y,score});}
            }
        }
    }
    // Keep original detector's strongest peaks, plus the new diffuse ones.
    proposals.extend(detect(rgba,rect,selection,11.0,sensitivity,limit));
    proposals.sort_by(|a,b|b.score.total_cmp(&a.score));
    let mut selected:Vec<Spot>=Vec::new();
    for s in proposals {
        let sep=8i64;
        if selected.iter().all(|p| {
            let dx=i64::from(p.x)-i64::from(s.x);
            let dy=i64::from(p.y)-i64::from(s.y);
            dx*dx+dy*dy>=sep*sep
        }) {selected.push(s);if selected.len()>=limit {break;}}
    }
    selected
}

pub(super) fn run(s: &mut Session, p: &Value) -> Result<Value> {
    let size = num(p, "size", 16.0);
    let sensitivity = num(p, "sensitivity", 65.0);
    let limit = p.get("maxSpots").and_then(Value::as_u64).unwrap_or(40);
    if !size.is_finite() || !(8.0..=48.0).contains(&size) || !sensitivity.is_finite() || !(0.0..=100.0).contains(&sensitivity) || !(1..=120).contains(&limit) {
        return Err(bad(CMD, "size must be 8..48 px; sensitivity 0..100; maxSpots 1..120"));
    }
    // Explicit pixel target prevents accidental edits to masks or alpha channels.
    if !targets_pixels(p) { return Err(bad(CMD, "select the image pixels, not a mask/channel")); }

    let (id, spots) = {
        let st = s.active().ok_or(EngineError::NoDocument)?;
        let id = st.active_layer.ok_or_else(|| bad(CMD, "select a pixel layer"))?;
        let layer = st.doc.layer(id).ok_or_else(|| bad(CMD, "active layer not found"))?;
        if !matches!(layer.content, LayerContent::Raster(_)) {
            return Err(bad(CMD, "select an actual raster/pixel layer"));
        }
        if layer.locks.pixels {
            return Err(bad(CMD, "active layer is pixel-locked"));
        }
        let surf = layer.surface().ok_or_else(|| bad(CMD, "no pixels on the selected layer"))?;
        // No selection is required for full-image mode. A selected area always wins.
        let selection = st.doc.selection.as_ref();
        let rect = selection.map(photocraft_compose::bounds::content_bounds)
            .unwrap_or_else(|| st.doc.bounds()).intersect(&st.doc.bounds());
        if rect.is_empty() { return Err(bad(CMD, "the selection is empty")); }
        let n = (rect.width() as usize).checked_mul(rect.height() as usize).unwrap_or(usize::MAX);
        if n > MAX_REGION_PIXELS {
            return Err(bad(CMD, "photo exceeds 13 million pixels; select the face or cheek, then retry"));
        }
        let img = Region::read(surf, rect);
        let fmt = surf.format();
        let pixels: Vec<[f32; 4]> = img.data.chunks_exact(img.ch).map(|px| to_rgba(&fmt, px)).collect();
        (id, detect(&pixels, rect, selection, size, sensitivity, limit as usize))
    };

    if spots.is_empty() { return Ok(json!({"count":0,"detected":0,"damage":[0,0,0,0]})); }
    let brush = BrushSettings {
        size, hardness: 0.85, opacity: 1.0, flow: 1.0,
        pressure_size: false, pressure_opacity: false,
        ..BrushSettings::default()
    };
    let mut healed = 0usize;
    let dmg = run_stroke(s, "Auto blemish (experimental)", Some(id), p, |pre, surf, selection, lock| {
        let mut changed = Rect::EMPTY;
        for spot in &spots {
            let stroke = Stroke {
                brush: brush.clone(),
                points: vec![StrokePoint::new(spot.x as f64 + 0.5, spot.y as f64 + 0.5, 1.0)],
            };
            let rect = spot_heal_surface(surf, pre, &stroke, SpotType::ContentAware, false, selection, lock);
            if !rect.is_empty() { healed += 1; }
            changed = changed.union(&rect);
        }
        Ok(changed)
    })?;
    Ok(json!({"count":healed,"detected":spots.len(),"damage":damage_json(dmg)}))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dense_detector_finds_small_red_and_dark_marks() {
        let w=130usize;let h=120usize;
        let mut pixels=vec![[0.70,0.52,0.44,1.0];w*h];
        for y in 0..h {for x in 0..w {
            let dx=x as i32-35;let dy=y as i32-48;
            if dx*dx+dy*dy<16 {pixels[y*w+x]=[0.82,0.39,0.38,1.0];}
            let dx=x as i32-92;let dy=y as i32-67;
            if dx*dx+dy*dy<16 {pixels[y*w+x]=[0.56,0.43,0.39,1.0];}
        }}
        let found=detect_dense(&pixels,Rect::new(0,0,w as i32,h as i32),None,90.0,100);
        assert!(found.iter().any(|s| (s.x-35).abs()<8&&(s.y-48).abs()<8),"red mark missing");
        assert!(found.iter().any(|s| (s.x-92).abs()<8&&(s.y-67).abs()<8),"darker mark missing");
    }
    #[test]
    fn rejects_unbounded_spot_budget() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":60,"depth":8,"mode":"rgb"})).unwrap();
        assert!(s.execute(CMD, json!({"maxSpots":121})).is_err());
    }

    #[test]
    fn detects_red_spot_only_inside_selection() {
        let w = 120; let h = 100;
        let mut s = Session::new();
        s.execute("file.new", json!({"width":w,"height":h,"depth":8,"mode":"rgb"})).unwrap();
        s.edit("test image", |doc, active| {
            let bounds = doc.bounds();
            let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
            let fmt = surf.format();
            let mut img = Vec::new();
            for y in 0..h {
                for x in 0..w {
                    let mut px = [0.63, 0.47, 0.38, 1.0];
                    if (x as i32 - 55).pow(2) + (y as i32 - 48).pow(2) <= 9 { px = [0.78, 0.35, 0.33, 1.0]; }
                    img.extend(photocraft_raster::from_rgba(&fmt, px));
                }
            }
            surf.write_region(bounds, &img);
            Ok(())
        }).unwrap();
        s.execute("select.rect", json!({"x":27,"y":25,"width":70,"height":55})).unwrap();
        let before = s.active().unwrap().doc.clone();
        let result = s.execute(CMD, json!({"size":14,"sensitivity":65})).unwrap();
        assert!(result["count"].as_u64().unwrap() >= 1, "red blemish detected: {result}");
        // The same action must be reversible in ONE undo, without affecting the selection.
        assert!(s.undo());
        assert_eq!(s.active().unwrap().doc, before, "auto retouch must be one undo step");
    }

    #[test]
    fn can_run_without_user_selection() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":100,"height":100,"depth":8,"mode":"rgb"})).unwrap();
        let result = s.execute(CMD, json!({"target":"pixels"})).unwrap();
        assert_eq!(result["count"], 0);
    }

    #[test]
    fn detects_without_selection_and_undoes() {
        let w = 120; let h = 100;
        let mut s = Session::new();
        s.execute("file.new", json!({"width":w,"height":h,"depth":8,"mode":"rgb"})).unwrap();
        s.edit("test source", |doc, active| {
            let bounds = doc.bounds();
            let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
            let fmt = surf.format();
            let mut img = Vec::new();
            for y in 0..h { for x in 0..w {
                let mut px = [0.63, 0.47, 0.38, 1.0];
                if (x as i32 - 55).pow(2) + (y as i32 - 48).pow(2) <= 9 {
                    px = [0.78, 0.35, 0.33, 1.0];
                }
                img.extend(photocraft_raster::from_rgba(&fmt, px));
            }}
            surf.write_region(bounds, &img);
            Ok(())
        }).unwrap();
        let before = s.active().unwrap().doc.clone();
        let result = s.execute(CMD, json!({"size":14,"sensitivity":85,"target":"pixels"})).unwrap();
        assert!(result["count"].as_u64().unwrap() > 0, "{result}");
        assert!(s.undo());
        assert_eq!(s.active().unwrap().doc, before);
    }
}
