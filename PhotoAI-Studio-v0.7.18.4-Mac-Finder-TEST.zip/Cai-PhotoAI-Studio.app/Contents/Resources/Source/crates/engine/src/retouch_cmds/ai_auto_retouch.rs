//! PhotoAI v0.7: first end-to-end *model-guided* offline automatic retouch.
//!
//! Apple Vision ML recognizes faces + landmarks on-device. That detection is an AI
//! model; spot discovery, inpainting and skin smoothing remain classical tools.
//! No invented generative face reconstruction. All changes are in one undo step.
//! If Apple Vision is unavailable, fail clearly; NEVER silently smooth the whole image.
use super::*;
#[cfg(target_os = "macos")]
use std::io::Write;
#[cfg(target_os = "macos")]
use std::process::{Command, Stdio};
#[cfg(target_os = "macos")]
use std::time::{Duration, Instant};

const CMD: &str = "paint.aiAutoRetouch";
// Includes 4032 x 3024 camera images (12,192,768 pixels). Keep Swift in sync.
const MAX_PIXELS: usize = 13_000_000;
// Match native/macos/PhotoAIVision.swift to fail before allocating a huge pipe buffer.
#[cfg(any(target_os = "macos", test))]
const MAX_VISION_DIM: usize = 8000;
#[cfg(target_os = "macos")]
const VISION_TIMEOUT_SECONDS: u64 = 90;

#[cfg(any(target_os = "macos", test))]
fn valid_vision_image(width: usize, height: usize, len: usize) -> bool {
    width > 0 && height > 0 && width <= MAX_VISION_DIM && height <= MAX_VISION_DIM
        && width.checked_mul(height).is_some_and(|n| n <= MAX_PIXELS && n == len)
}

#[derive(Clone, Debug)]
struct Zone {
    rect: Rect,
    left_eye: Option<Rect>,
    right_eye: Option<Rect>,
    lips: Option<Rect>,
}

fn rect_from_vision(v: Option<&Value>, canvas: Rect) -> Option<Rect> {
    let a = v?.as_array()?;
    if a.len() != 4 { return None; }
    let nums: Option<Vec<f64>> = a.iter().map(Value::as_f64).collect();
    let n = nums?;
    if n.iter().any(|x| !x.is_finite() || !(0.0..=1.0).contains(x)) || n[2] <= n[0] || n[3] <= n[1] {
        return None;
    }
    let w = canvas.width() as f64;
    let h = canvas.height() as f64;
    let x0 = canvas.x0 + (n[0] * w).floor() as i32;
    let y0 = canvas.y0 + (n[1] * h).floor() as i32;
    let x1 = canvas.x0 + (n[2] * w).ceil() as i32;
    let y1 = canvas.y0 + (n[3] * h).ceil() as i32;
    let area = Rect::new(x0, y0, x1, y1).intersect(&canvas);
    (!area.is_empty()).then_some(area)
}

fn faces_from_response(response: &Value, bounds: Rect) -> Vec<Zone> {
    response["faces"].as_array().map_or_else(Vec::new, |list| {
        list.iter().take(8).filter_map(|entry| {
            let rect = rect_from_vision(entry.get("box"), bounds)?;
            if rect.width() < 65 || rect.height() < 65 { return None; }
            Some(Zone {
                rect,
                left_eye: rect_from_vision(entry.get("leftEye"), bounds),
                right_eye: rect_from_vision(entry.get("rightEye"), bounds),
                lips: rect_from_vision(entry.get("mouth"), bounds),
            })
        }).collect()
    })
}

/// Transform pixels to an RGBA8 stream consumed by an independently signed,
/// bundled Swift helper using macOS's built-in Vision model.
#[cfg(target_os = "macos")]
pub(super) fn apple_vision(pixels: &[[f32; 4]], width: usize, height: usize) -> Result<Value> {
    if !valid_vision_image(width, height, pixels.len()) {
        return Err(bad(CMD, "Apple Vision: ảnh vượt 13 MP, cạnh vượt 8000 px hoặc dữ liệu không hợp lệ"));
    }
    let binary = std::env::current_exe()
        .map_err(|e| bad(CMD, format!("cannot locate application executable: {e}")))?
        .with_file_name("PhotoAIVision");
    if !binary.is_file() {
        return Err(bad(CMD, "Apple Vision helper missing. Rebuild/install PhotoAI v0.7 with the bundled installer."));
    }
    let mut child = Command::new(&binary)
        .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped())
        .spawn().map_err(|e| bad(CMD, format!("could not start Apple Vision: {e}")))?;
    let mut input = child.stdin.take().ok_or_else(|| bad(CMD, "cannot feed pixels to Apple Vision"))?;
    // Write binary image in one bounded stream; never create a photo file on disk.
    let send = (|| -> std::io::Result<()> {
        input.write_all(&(width as u32).to_le_bytes())?;
        input.write_all(&(height as u32).to_le_bytes())?;
        let mut row = Vec::with_capacity(width * 4);
        for line in pixels.chunks_exact(width) {
            row.clear();
            for px in line {
                for &c in px {
                    row.push((c.clamp(0.0, 1.0) * 255.0).round() as u8);
                }
            }
            input.write_all(&row)?;
        }
        Ok(())
    })();
    drop(input);
    if let Err(e) = send {
        // A failed pipe must not leave an orphan Vision process using RAM/CPU.
        let _ = child.kill();
        let _ = child.wait();
        return Err(bad(CMD, format!("cannot send image to Apple Vision: {e}")));
    }
    // Vision can hang on malformed input or OS-level ML problems; do not freeze the
    // editor indefinitely. The caller receives an error and the original stays safe.
    let started = Instant::now();
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) if started.elapsed() < Duration::from_secs(VISION_TIMEOUT_SECONDS) => {
                std::thread::sleep(Duration::from_millis(100));
            }
            Ok(None) => {
                let _ = child.kill();
                let _ = child.wait();
                return Err(bad(CMD, "Apple Vision quá thời gian 90 giây; ảnh gốc chưa bị chỉnh sửa"));
            }
            Err(e) => {
                let _ = child.kill();
                let _ = child.wait();
                return Err(bad(CMD, format!("Vision process status failed: {e}")));
            }
        }
    }
    let output = child.wait_with_output().map_err(|e| bad(CMD, format!("Vision process failed: {e}")))?;
    let json: Value = serde_json::from_slice(&output.stdout)
        .map_err(|e| bad(CMD, format!("Vision returned invalid JSON: {e}")))?;
    if !output.status.success() {
        return Err(bad(CMD, format!("Vision error: {}", json["error"].as_str().unwrap_or("unknown error"))));
    }
    Ok(json)
}

#[cfg(not(target_os = "macos"))]
pub(super) fn apple_vision(_pixels: &[[f32; 4]], _width: usize, _height: usize) -> Result<Value> {
    Err(bad(CMD, "automatic face recognition v0.7 currently requires macOS Apple Vision"))
}

fn inside(r: Rect, x: i32, y: i32, scale: f32) -> bool {
    let cx = (r.x0 + r.x1) as f32 * 0.5;
    let cy = (r.y0 + r.y1) as f32 * 0.5;
    let rx = r.width() as f32 * 0.5 * scale;
    let ry = r.height() as f32 * 0.5 * scale;
    if rx <= 0.0 || ry <= 0.0 { return false; }
    ((x as f32 - cx) / rx).powi(2) + ((y as f32 - cy) / ry).powi(2) < 1.0
}

fn eye_protection(r: Rect, x: i32, y: i32) -> bool {
    // Include brows, lashes and eye itself to prevent blurred facial features.
    let mx = (r.width() as f32 * 0.55).max(5.0);
    let above = (r.height() as f32 * 1.30).max(7.0);
    let below = (r.height() as f32 * 0.18).max(2.0);
    (x as f32) >= r.x0 as f32 - mx && (x as f32) <= r.x1 as f32 + mx
        && (y as f32) >= r.y0 as f32 - above && (y as f32) <= r.y1 as f32 + below
}

/// The default must never retouch lips or eyes. Opt-out is an advanced, explicit user action.
#[derive(Clone, Copy, Debug)]
struct FeatureGuards { lips: bool, eyes: bool }
impl Default for FeatureGuards {
    fn default() -> Self { Self { lips: true, eyes: true } }
}

/// Use a padded **rectangle**, not an ellipse: an ellipse excludes the lip corners,
/// allowing a brush footprint to blur the vermilion border even when its centre is on skin.
fn lip_guard(r: Rect, x: i32, y: i32) -> bool {
    // A 12 px minimum leaves x=45 unprotected when Vision reports mouth [58,70].
    // Include at least 16 px on every side so a smoothing 7x7 kernel cannot
    // treat a near-lip donor as ordinary cheek skin (regression #lip-sampling).
    let mx = ((r.width() as f32) * 0.35).ceil().max(16.0) as i32;
    let my = ((r.height() as f32) * 0.85).ceil().max(12.0) as i32;
    x >= r.x0.saturating_sub(mx) && x < r.x1.saturating_add(mx)
        && y >= r.y0.saturating_sub(my) && y < r.y1.saturating_add(my)
}

fn eligible_skin_guarded(zone: &Zone, x: i32, y: i32, guards: FeatureGuards) -> bool {
    if !inside(zone.rect, x, y, 0.94) { return false; }
    let local_y = (i64::from(y) - i64::from(zone.rect.y0)) as f32 / zone.rect.height().max(1) as f32;
    if guards.eyes {
        if zone.left_eye.is_some_and(|r| eye_protection(r, x, y)) || zone.right_eye.is_some_and(|r| eye_protection(r, x, y)) { return false; }
        // When landmark detection is incomplete, conservatively exclude the eye/brow band.
        if (zone.left_eye.is_none() || zone.right_eye.is_none()) && (0.15..=0.57).contains(&local_y) { return false; }
    }
    if guards.lips {
        // Trust an actual face-relative mouth landmark with an enlarged rectangular
        // shield; do NOT blanket-block the entire lower cheek on 3/4 portraits.
        if let Some(mouth) = zone.lips {
            if lip_guard(mouth, x, y) { return false; }
            // Reject implausible mouth placement; retain the conservative fallback.
            let cx=((mouth.x0 as f64+mouth.x1 as f64)*0.5-zone.rect.x0 as f64)/zone.rect.width().max(1) as f64;
            let cy=((mouth.y0 as f64+mouth.y1 as f64)*0.5-zone.rect.y0 as f64)/zone.rect.height().max(1) as f64;
            if (!(0.15..=0.85).contains(&cx) || !(0.50..=0.95).contains(&cy))
                && lower_face_guard(zone,x,y) { return false; }
        } else if lower_face_guard(zone, x, y) {
            // If Vision did not return lips, fail closed near the expected mouth,
            // but preserve outer cheek skin rather than disabling acne removal.
            return false;
        }
    }
    true
}

// Retained for existing internal tests and conservative default tools.
#[cfg(test)]
fn eligible_skin(zone: &Zone, x: i32, y: i32) -> bool {
    eligible_skin_guarded(zone, x, y, FeatureGuards::default())
}

/// A conservative shield in the central lower face. The Vision mouth bbox can
/// drift on three-quarter views: never trust landmarks alone when protecting lips.
fn lower_face_guard(zone: &Zone, x: i32, y: i32) -> bool {
    let w = zone.rect.width().max(1) as f32;
    let h = zone.rect.height().max(1) as f32;
    let nx = (x as f32 - zone.rect.x0 as f32) / w;
    let ny = (y as f32 - zone.rect.y0 as f32) / h;
    (0.38..=0.83).contains(&nx) && (0.67..=0.91).contains(&ny)
}

/// Larger rectangle around a Vision feature, including its corners and typical
/// prediction error. Used to exclude the ENTIRE inpainting sampling window.
fn protected_bounds(r: Rect, x_scale: f32, y_scale: f32) -> Rect {
    let px = ((r.width() as f32) * x_scale).ceil().max(16.0) as i32;
    let py = ((r.height() as f32) * y_scale).ceil().max(16.0) as i32;
    Rect::new(r.x0.saturating_sub(px), r.y0.saturating_sub(py),
              r.x1.saturating_add(px), r.y1.saturating_add(py))
}

/// Heal one small target spot using ONLY safe skin pixels as source.
/// Content-aware source masks remove ALL lip/eye pixels from the donor pool,
/// unlike the legacy healing brush which samples any pixel inside its window.
fn guarded_heal_spot(surf: &mut Surface, original: &Surface, zone: &Zone, spot: auto_blemish::Spot,
                     guards: FeatureGuards, selection: Option<&Surface>, strength: f32) -> Rect {
    const RADIUS: i32 = 7;
    let canvas = zone.rect;
    // A compact local donor window avoids distant sampled skin/hair and bounds CPU
    // on the M1 8GB. Do not substitute Photoshop's ~200px search window here.
    let window = Rect::new(spot.x.saturating_sub(38), spot.y.saturating_sub(38),
                           spot.x.saturating_add(39), spot.y.saturating_add(39)).intersect(&canvas);
    if window.is_empty() { return Rect::EMPTY; }
    let fmt = surf.format();
    let region = Region::read(surf, window);
    // Always sample donors from the untouched pre-stroke image. Reusing pixels
    // healed by earlier detections creates blurry/plastic skin and colour bleed.
    let donors = Region::read(original, window);
    let w = region.width();
    let h = region.height();
    let mut source = vec![false; w*h];
    let mut hole = vec![false; w*h];
    let mut donor_count = 0usize;
    for y in 0..h {
        for x in 0..w {
            let gx = window.x0 + x as i32;
            let gy = window.y0 + y as i32;
            let i = y*w + x;
            let px = to_rgba(&fmt, &donors.data[i*donors.ch..(i+1)*donors.ch]);
            let eligible = eligible_skin_guarded(zone, gx, gy, guards);
            let dx = gx - spot.x;
            let dy = gy - spot.y;
            let at_spot = dx*dx + dy*dy <= RADIUS*RADIUS;
            let chosen = selection.is_none_or(|sel| sel.sample_channel(gx,gy,0) >= 0.98);
            // A blemish may be too red/dark to pass the healthy-skin prior.
            // Apply that prior only to donor pixels, never to the repair target.
            hole[i] = eligible && at_spot && chosen && opaque_pixel(px);
            source[i] = eligible && !at_spot && skin_tone(px);
            donor_count += usize::from(source[i]);
        }
    }
    // Never manufacture pixels when no safe skin texture can be sampled.
    if donor_count < 50 || !hole.iter().any(|v| *v) { return Rect::EMPTY; }
    let filled = photocraft_algo::content_aware::fill(
        w,h,donors.ch,&donors.data,&hole,&source,
        &photocraft_algo::content_aware::FillOptions::default());
    let mut output = region.data.clone();
    let ai = alpha_index(&fmt);
    let mut changed = Rect::EMPTY;
    for y in 0..h {
        for x in 0..w {
            let i = y*w+x;
            if !hole[i] {continue;}
            let gx = window.x0 + x as i32;
            let gy = window.y0 + y as i32;
            let dx = (gx - spot.x) as f32;
            let dy = (gy - spot.y) as f32;
            let falloff = (1.0 - (dx*dx + dy*dy)/(RADIUS*RADIUS) as f32).clamp(0.0,1.0);
            let opacity = falloff.sqrt() * strength.clamp(0.0, 1.0) * 0.88;
            let mut modified = false;
            for ch in 0..region.ch {
                if Some(ch) != ai {
                    let k = i*region.ch+ch;
                    output[k] = region.data[k] + (filled[k]-region.data[k]) * opacity;
                    modified |= (output[k] - region.data[k]).abs() >= 0.001;
                }
            }
            if modified { changed = changed.union(&Rect::new(gx,gy,gx+1,gy+1)); }
        }
    }
    if !changed.is_empty() { surf.write_region(window, &output); }
    changed
}

/// Edge-aware smoothing that NEVER reads colour from a protected feature.
/// The old skin_pixel() sampled all 49 neighbours, including lips/eyes.
fn skin_pixel_guarded(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize,
                      zone: &Zone, guards: FeatureGuards) -> [f32; 3] {
    let c = src[y * w + x];
    let mut sum = [0.0f32; 3];
    let mut weight_sum = 0.0f32;
    for dy in -3i32..=3 {
        let yy = (y as i32 + dy).clamp(0, h as i32 - 1) as usize;
        for dx in -3i32..=3 {
            let xx = (x as i32 + dx).clamp(0, w as i32 - 1) as usize;
            let px = zone.rect.x0 + xx as i32;
            let py = zone.rect.y0 + yy as i32;
            let q = src[yy*w + xx];
            if !eligible_skin_guarded(zone, px, py, guards) || !skin_tone(q) { continue; }
            let delta = (0..3).map(|k| (c[k] - q[k]).powi(2)).sum::<f32>();
            let spatial = 1.0 / (1.0 + (dx*dx + dy*dy) as f32 * 0.18);
            let edge = 1.0 / (1.0 + delta * 42.0);
            let weight = spatial * edge;
            for k in 0..3 { sum[k] += q[k] * weight; }
            weight_sum += weight;
        }
    }
    if weight_sum <= 0.0 { [c[0], c[1], c[2]] }
    else { sum.map(|value| (value / weight_sum).clamp(0.0, 1.0)) }
}

/// Reject an entire healing dab if even its edge could overlap a protected feature.
/// A 14 px brush has roughly a 7 px radius; 12 px leaves extra space for feathering.
fn safe_healing_dab(zone: &Zone, x: i32, y: i32, guards: FeatureGuards) -> bool {
    const R: i32 = 8;
    [(0,0),(-R,0),(R,0),(0,-R),(0,R),(-R,-R),(-R,R),(R,-R),(R,R)]
        .iter().all(|&(dx,dy)| eligible_skin_guarded(zone, x.saturating_add(dx), y.saturating_add(dy), guards))
}

fn opaque_pixel(px: [f32; 4]) -> bool {
    px.iter().all(|v| v.is_finite()) && px[3] >= 0.95
}

fn skin_tone(px: [f32; 4]) -> bool {
    let [r, g, b, a] = px;
    if a < 0.95 || r < 0.12 || g < 0.08 { return false; }
    // Broad chroma prior, never infer identity or ethnicity from it.
    let cb = 0.5 - 0.168_736*r - 0.331_264*g + 0.5*b;
    let cr = 0.5 + 0.5*r - 0.418_688*g - 0.081_312*b;
    (0.29..=0.64).contains(&cb) && (0.39..=0.73).contains(&cr)
}

fn under_eye(zone: &Zone, x: i32, y: i32) -> bool {
    [zone.left_eye, zone.right_eye].iter().flatten().any(|eye| {
        // Rect coordinates are i32, but Rect::width() returns u32.
        // Checked conversion and saturating arithmetic prevent E0308/E0277 and overflow.
        let pad = i32::try_from(eye.width() / 5).unwrap_or(i32::MAX);
        let left = eye.x0.saturating_sub(pad);
        let right = eye.x1.saturating_add(pad);
        let below = (eye.height() as f32 * 0.45).max(3.0) as i32;
        let bottom = (eye.height() as f32 * 1.3).max(8.0) as i32;
        let top = eye.y1.saturating_add(below);
        let end = eye.y1.saturating_add(bottom);
        x >= left && x <= right && y >= top && y <= end
    })
}

pub(super) fn run(s: &mut Session, p: &Value) -> Result<Value> {
    let mode = string(p, "mode", "natural");
    if !matches!(mode, "natural" | "portrait" | "skinOnly") {
        return Err(bad(CMD, "mode must be natural, portrait or skinOnly"));
    }
    let strength = num(p, "strength", 55.0);
    if !strength.is_finite() || !(0.0..=100.0).contains(&strength) { return Err(bad(CMD, "strength must be in 0..100")); }
    if !targets_pixels(p) { return Err(bad(CMD, "select image pixels, not mask or channel")); }
    let power = strength / 100.0;
    let blemish_only = p.get("blemishOnly").and_then(Value::as_bool).unwrap_or(false);
    let sensitivity = num(p, "sensitivity", 92.0);
    if !sensitivity.is_finite() || !(0.0..=100.0).contains(&sensitivity) {
        return Err(bad(CMD, "sensitivity must be in 0..100"));
    }
    let guards = FeatureGuards {
        lips: blemish_only || p.get("protectLips").and_then(Value::as_bool).unwrap_or(true),
        eyes: blemish_only || p.get("protectEyes").and_then(Value::as_bool).unwrap_or(true),
    };
    let mut skipped_sensitive = 0usize;
    let mut skipped_source = 0usize;

    let (layer_id, _bounds, zones, spots) = {
        let st = s.active().ok_or(EngineError::NoDocument)?;
        let layer_id = st.active_layer.ok_or_else(|| bad(CMD, "select an image pixel layer"))?;
        let layer = st.doc.layer(layer_id).ok_or_else(|| bad(CMD, "pixel layer not found"))?;
        if !matches!(layer.content, LayerContent::Raster(_)) || layer.locks.all || layer.locks.pixels {
            return Err(bad(CMD, "select an unlocked raster pixel layer"));
        }
        let surf = layer.surface().ok_or_else(|| bad(CMD, "pixel layer has no surface"))?;
        if power == 0.0 {
            return Ok(json!({"faces":0,"spots":0,"smoothedPixels":0,"underEyePixels":0,"noChange":true,"damage":[0,0,0,0]}));
        }
        let bounds = st.doc.bounds();
        let w = bounds.width() as usize;
        let h = bounds.height() as usize;
        if w == 0 || h == 0 || w.checked_mul(h).unwrap_or(usize::MAX) > MAX_PIXELS {
            return Err(bad(CMD, "Ảnh vượt 13 triệu pixel: thu nhỏ một bản sao hoặc cắt vùng mặt trước"));
        }
        let region = Region::read(surf, bounds);
        let fmt = surf.format();
        let pixels: Vec<[f32; 4]> = region.data.chunks_exact(region.ch).map(|v| to_rgba(&fmt, v)).collect();
        let response = apple_vision(&pixels, w, h)?;
        let zones = faces_from_response(&response, bounds);
        if zones.is_empty() {
            return Ok(json!({"model":"Apple Vision","faces":0,"spots":0,"smoothedPixels":0,"underEyePixels":0,"noChange":true,"damage":[0,0,0,0],"message":"No face detected. Photo was left unchanged."}));
        }
        let mut candidates = Vec::new();
        if power > 0.0 {
            for zone in &zones {
                // Only inspect detected faces, not the full photo or hair/background.
                let z = zone.rect;
                let zw = z.width() as usize;
                let mut face_pixels = Vec::with_capacity(zw * z.height() as usize);
                for yy in z.y0..z.y1 {
                    let row_start = (yy - bounds.y0) as usize * w + (z.x0 - bounds.x0) as usize;
                    face_pixels.extend_from_slice(&pixels[row_start..row_start + zw]);
                }
                let spots = auto_blemish::detect_dense(&face_pixels, z, st.doc.selection.as_ref(), sensitivity, 240);
                for spot in spots {
                    let idx = (spot.y - bounds.y0) as usize * w + (spot.x - bounds.x0) as usize;
                    // Centre-only tests are unsafe: the healing brush can still paint the lips.
                    if !safe_healing_dab(zone, spot.x, spot.y, guards) {
                        skipped_sensitive += 1;
                    } else if opaque_pixel(pixels[idx]) {
                        candidates.push(spot);
                    }
                }
            }
        }
        candidates.sort_by(|a, b| b.score.total_cmp(&a.score));
        let cap = if mode == "portrait" || blemish_only { 150 } else { 100 };
        candidates.truncate(cap);
        (layer_id, bounds, zones, candidates)
    };
    if power <= 0.0 { return Ok(json!({"faces":zones.len(),"spots":0,"noChange":true,"smoothedPixels":0,"underEyePixels":0,"damage":[0,0,0,0]})); }
    if blemish_only && spots.is_empty() {
        return Ok(json!({"faces":zones.len(), "candidates":0, "spots":0, "blemishOnly":true,
            "noChange":true,"protectedLips":true,"protectedEyes":true,
            "skippedNearFeatures":skipped_sensitive,"skippedUnsafeSource":0,
            "smoothedPixels":0,"underEyePixels":0,"damage":[0,0,0,0],
            "message":"Không tìm thấy nốt mụn phù hợp trong vùng da an toàn; ảnh giữ nguyên."}));
    }
    let mut healed_count = 0usize;
    let mut smoothed = 0usize;
    let mut brightened = 0usize;
    let damage = run_stroke(s, "AI Auto Retouch (Apple Vision)", Some(layer_id), p, |pre, surf, selection, lock| {
        let original = pre.layer(layer_id).and_then(|layer| layer.surface())
            .ok_or_else(|| bad(CMD, "cannot read original pixel layer for retouch"))?;
        let mut result = Rect::EMPTY;
        for spot in &spots {
            let Some(zone) = zones.iter().find(|zone| zone.rect.contains(spot.x,spot.y)) else { continue };
            let changed = guarded_heal_spot(surf, original, zone, *spot, guards, selection, power);
            if !changed.is_empty() { healed_count += 1; }
            else { skipped_source += 1; }
            result = result.union(&changed);
        }
        let fmt = surf.format();
        // Read only face regions; no unbounded 49-neighbour work on a full-size image.
        for zone in &zones {
            if blemish_only { continue; }
            let region = Region::read(surf, zone.rect);
            // The pre-stroke snapshot is the immutable ground truth for eyes/lips.
            // Restore any feature pixel touched by the inpainting dab before saving.
            let pristine = pre.layer(layer_id)
                .and_then(|layer| layer.surface())
                .map(|source| Region::read(source, zone.rect))
                .ok_or_else(|| bad(CMD, "original image pixels unavailable for safety restoration"))?;
            // Xoá mụn must NEVER silently apply smoothing to lips, cheek or eyes.
            // This was the original source of "nhấn xoá mụn làm lem" complaints.
            let w = zone.rect.width() as usize;
            let h = zone.rect.height() as usize;
            let rgba: Vec<[f32;4]> = region.data.chunks_exact(region.ch).map(|v| to_rgba(&fmt, v)).collect();
            let mut output = region.data.clone();
            let mut native = [0.0f32; 8];
            let mut changed = false;
            for y in 0..h {
                for x in 0..w {
                    let gx = zone.rect.x0 + x as i32;
                    let gy = zone.rect.y0 + y as i32;
                    let index = y * w + x;
                    if !eligible_skin_guarded(zone, gx, gy, guards) {
                        let start = index * region.ch;
                        let end = start + region.ch;
                        if output[start..end] != pristine.data[start..end] {
                            output[start..end].copy_from_slice(&pristine.data[start..end]);
                            changed = true;
                        }
                        continue;
                    }
                    if selection.is_some_and(|sel| sel.sample_channel(gx, gy, 0) < 0.98) { continue; }
                    let original = rgba[index];
                    if !skin_tone(original) { continue; }
                    let mut alpha = if mode == "portrait" { 0.45 } else { 0.26 };
                    if mode == "skinOnly" { alpha = 0.35; }
                    alpha *= power;
                    let smooth = skin_pixel_guarded(&rgba, x, y, w, h, zone, guards);
                    let mut rgb = std::array::from_fn(|k| original[k] + (smooth[k] - original[k]) * alpha);
                    if mode != "skinOnly" && under_eye(zone, gx, gy) {
                        // Lighten *below* the lower lid, never the eye itself.
                        let luma = 0.2126*rgb[0] + 0.7152*rgb[1] + 0.0722*rgb[2];
                        let amount = (0.65 - luma).clamp(0.0, 0.30) * 0.28 * power;
                        rgb = [ (rgb[0]+amount*1.02).min(1.0), (rgb[1]+amount).min(1.0), (rgb[2]+amount*0.90).min(1.0) ];
                        if amount > 0.002 { brightened += 1; }
                    }
                    if (0..3).all(|k| (rgb[k] - original[k]).abs() < 0.001) { continue; }
                    smoothed += 1;
                    changed = true;
                    from_rgba_into(&fmt, [rgb[0],rgb[1],rgb[2],original[3]], &mut native);
                    let start = index * region.ch;
                    let ai = alpha_index(&fmt);
                    for ch in 0..region.ch {
                        if Some(ch) != ai { output[start + ch] = native[ch]; }
                    }
                }
            }
            if changed {
                surf.write_region(zone.rect, &output);
                result = result.union(&zone.rect);
            }
        }
        Ok(result)
    })?;
    let actions = if blemish_only {
        vec!["face-detection", "spot-healing"]
    } else if mode == "skinOnly" {
        vec!["face-detection", "spot-healing", "skin-smoothing"]
    } else {
        vec!["face-detection", "spot-healing", "skin-smoothing", "under-eye-lighting"]
    };
    Ok(json!({"model":"Apple Vision (face/eye/lip landmarks)", "faces":zones.len(), "spots":healed_count,
        "candidates":spots.len(), "blemishOnly":blemish_only,
        "noChange":damage.is_empty(),
        "skippedNearFeatures":skipped_sensitive,
        "skippedUnsafeSource":skipped_source,
        "protectedLips":guards.lips,"protectedEyes":guards.eyes,
        "smoothedPixels":smoothed,"underEyePixels":brightened,
        "actions":actions,
        "message": if damage.is_empty() { "Không có pixel nào được sửa: thử tăng độ nhạy hoặc chọn vùng má; không báo xoá mụn thành công." } else { "Có thay đổi điểm ảnh. So sánh trước/sau để xác nhận." },
        "damage":damage_json(damage), "note":"Face detection uses ML; spot removal/retouch uses local image algorithms."}))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn zero_strength_does_not_require_vision() {
        let mut s=Session::new();
        s.execute("file.new",json!({"width":80,"height":80})).unwrap();
        let before=s.active().unwrap().doc.clone();
        let result=s.execute(CMD,json!({"strength":0})).unwrap();
        assert_eq!(result["noChange"],true);
        assert_eq!(s.active().unwrap().doc,before);
    }
    #[test]
    fn swift_helper_limits_match_rust_preflight() {
        assert!(valid_vision_image(4032, 3024, 4032*3024));
        assert!(!valid_vision_image(8001, 100, 8001*100));
        assert!(!valid_vision_image(3000, 5000, 3000*5000));
        assert!(!valid_vision_image(640, 480, 32));
        assert!(!valid_vision_image(0, 480, 0));
    }
    #[test]
    fn camera_12mp_dimensions_fit_the_processing_budget() {
        assert!(4032usize * 3024 <= MAX_PIXELS);
        assert!(8064usize * 6048 > MAX_PIXELS);
    }

    #[test]
    fn red_blemish_outside_skin_prior_is_healed_without_touching_surroundings() {
        for depth in [8, 16, 32] {
            let mut s = Session::new();
            s.execute("file.new", json!({"width":200,"height":240,"depth":depth,"mode":"rgb"})).unwrap();
            s.edit("synthetic acne fixture", |doc, active| {
                let bounds = doc.bounds();
                let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
                let fmt = surf.format();
                let mut image = Vec::new();
                for y in 0i32..240 { for x in 0i32..200 {
                    let px = if (x-60).pow(2)+(y-155).pow(2) <= 4 {
                        [1.0,0.20,0.20,1.0]
                    } else { [0.70,0.52,0.44,1.0] };
                    image.extend(photocraft_raster::from_rgba(&fmt, px));
                }}
                surf.write_region(bounds, &image);
                Ok(())
            }).unwrap();
            let z = Zone {rect:Rect::new(0,0,200,240),
                left_eye:Some(Rect::new(40,70,65,82)),
                right_eye:Some(Rect::new(130,70,155,82)),
                lips:Some(Rect::new(85,190,115,205))};
            assert!(!skin_tone([1.0,0.20,0.20,1.0]));
            assert!(safe_healing_dab(&z,60,155,FeatureGuards::default()));
            let st = s.active().unwrap();
            let original = st.doc.layer(st.active_layer.unwrap()).unwrap().surface().unwrap();
            let mut surf = original.clone();
            let before = Region::read(&surf,z.rect);
            let damage = guarded_heal_spot(&mut surf,original,&z,
                auto_blemish::Spot{x:60,y:155,score:1.0},FeatureGuards::default(),None,1.0);
            assert!(!damage.is_empty(),"red acne must be repairable at depth {depth}");
            let after = Region::read(&surf,z.rect);
            let k = (155*200+60)*before.ch;
            let fmt = surf.format();
            let a = to_rgba(&fmt,&before.data[k..k+before.ch]);
            let b = to_rgba(&fmt,&after.data[k..k+after.ch]);
            assert!(b[0] < a[0]-0.02,"center must change, not only the skin around it");
            for y in 0i32..240 { for x in 0i32..200 {
                if (x-60).pow(2)+(y-155).pow(2) > 49 {
                    let i = (y as usize*200+x as usize)*before.ch;
                    assert_eq!(&before.data[i..i+before.ch],&after.data[i..i+before.ch]);
                }
            }}
        }
    }

    #[test]
    fn lip_eye_guards_cannot_be_disabled_in_blemish_only_mode() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":80,"depth":8,"mode":"rgb"})).unwrap();
        // On unsupported OS, Vision must fail; never silently change an entire raster.
        #[cfg(not(target_os = "macos"))]
        assert!(s.execute(CMD, json!({"blemishOnly":true,"protectLips":false,"protectEyes":false})).is_err());
    }
    #[test]
    fn accepts_only_valid_normalized_rectangles() {
        let canvas = Rect::new(0,0,200,300);
        assert_eq!(rect_from_vision(Some(&json!([0.25,0.10,0.75,0.90])), canvas), Some(Rect::new(50,30,150,270)));
        assert!(rect_from_vision(Some(&json!([-1.0,0.0,1.0,1.0])),canvas).is_none());
        assert!(rect_from_vision(Some(&json!([0.4,0.4,0.2,0.9])),canvas).is_none());
    }
    #[test]
    fn automatic_face_mask_protects_eye_and_lips() {
        let zone = Zone {rect:Rect::new(20,20,180,230),left_eye:Some(Rect::new(55,90,88,102)),right_eye:Some(Rect::new(112,90,145,102)),lips:Some(Rect::new(85,175,117,187))};
        assert!(eligible_skin(&zone,60,145));
        assert!(!eligible_skin(&zone,65,97));
        assert!(!eligible_skin(&zone,100,180));
        assert!(!eligible_skin(&zone,21,22));
    }
    #[test]
    fn under_eye_horizontal_padding_is_signed_and_bounded() {
        let zone = Zone {
            rect: Rect::new(0, 0, 160, 160),
            left_eye: Some(Rect::new(40, 40, 65, 50)),
            right_eye: None,
            lips: None,
        };
        // Eye width=25 -> pad=5; under-eye y range 54..=63.
        assert!(under_eye(&zone, 35, 55));
        assert!(under_eye(&zone, 70, 63));
        assert!(!under_eye(&zone, 34, 55));
        assert!(!under_eye(&zone, 71, 55));
        assert!(!under_eye(&zone, 45, 51));
        assert!(!under_eye(&zone, 45, 64));
    }
    #[test]
    fn under_eye_offsets_saturate_at_integer_boundaries() {
        let zone = Zone {
            rect: Rect::new(-100, -100, 100, 100),
            left_eye: Some(Rect::new(i32::MIN, i32::MAX - 20, i32::MIN + 100, i32::MAX - 10)),
            right_eye: None,
            lips: None,
        };
        // Saturating math must not panic even near the signed integer limits.
        assert!(!under_eye(&zone, 0, 0));
    }
    #[test]
    fn lip_corners_and_safety_margin_are_never_editable() {
        let z = Zone { rect: Rect::new(0, 0, 300, 300), left_eye: None, right_eye: None,
            lips: Some(Rect::new(113, 207, 187, 231)) };
        let defaults = FeatureGuards::default();
        assert!(!eligible_skin_guarded(&z, 113, 207, defaults));
        assert!(!eligible_skin_guarded(&z, 100, 195, defaults));
        assert!(!eligible_skin_guarded(&z, 199, 241, defaults));
        assert!(!safe_healing_dab(&z, 95, 218, defaults), "brush may touch mouth guard");
        assert!(eligible_skin_guarded(&z, 75, 175, defaults));
    }
    #[test]
    fn missing_lip_landmark_fails_closed_around_lower_face() {
        let z = Zone { rect: Rect::new(0, 0, 200, 240), left_eye: None,
            right_eye: None, lips: None };
        assert!(!eligible_skin_guarded(&z, 100, 180, FeatureGuards::default()));
        assert!(!safe_healing_dab(&z, 100, 160, FeatureGuards::default()));
    }
    #[test]
    fn full_dab_clearance_respects_eye_boundaries() {
        let z = Zone { rect: Rect::new(0, 0, 250, 250),
            left_eye: Some(Rect::new(55, 90, 90, 105)),
            right_eye: Some(Rect::new(155, 90, 190, 105)),
            lips: Some(Rect::new(100, 190, 150, 202)) };
        assert!(!safe_healing_dab(&z, 105, 104, FeatureGuards::default()));
        assert!(safe_healing_dab(&z, 60, 159, FeatureGuards::default()));
    }
    #[test]
    fn safe_lip_guard_covers_mouth_and_central_lower_face() {
        let z = Zone {rect:Rect::new(0,0,450,450), left_eye:None,
            right_eye:None, lips:Some(Rect::new(215,315,290,340))};
        let g = FeatureGuards::default();
        assert!(!eligible_skin_guarded(&z,230,330,g));
        assert!(!eligible_skin_guarded(&z,230,300,g));
        assert!(eligible_skin_guarded(&z,70,300,g));
    }
    #[test]
    fn smoothing_never_reads_pink_lip_pixel_through_a_skin_boundary() {
        let z = Zone {rect:Rect::new(0,0,120,140),left_eye:None,right_eye:None,
            lips:Some(Rect::new(58,101,70,109))};
        let g = FeatureGuards::default();
        let w=120usize; let h=140usize;
        let uniform = [0.62,0.45,0.39,1.0];
        let mut image = vec![uniform; w*h];
        let x=45usize; let y=96usize;
        image[y*w + x] = [0.95,0.15,0.30,1.0]; // neighbour that is protected
        assert!(!eligible_skin_guarded(&z,x as i32,y as i32,g));
        let result = skin_pixel_guarded(&image, 44, 95, w, h, &z, g);
        assert!((result[0]-uniform[0]).abs() < 0.0001);
    }
    #[test]
    fn small_mouth_lip_guard_excludes_all_padding_boundary_donors() {
        let z = Zone { rect: Rect::new(0, 0, 120, 140), left_eye: None,
            right_eye: None, lips: Some(Rect::new(58, 101, 70, 109)) };
        let g = FeatureGuards::default();
        // Previous 12-pixel left margin admitted x=45, a pink lip pixel.
        for x in 42..=45 {
            assert!(!eligible_skin_guarded(&z, x, 96, g),
                    "left lip safety boundary must remain protected at x={x}");
        }
        for x in 70..=85 {
            assert!(!eligible_skin_guarded(&z, x, 103, g),
                    "right lip safety boundary must remain protected at x={x}");
        }
        assert!(!safe_healing_dab(&z, 40, 96, g),
                "dabs near mouth may sample lip pixels");
    }
    #[test]
    fn shifted_landmarks_do_not_allow_edits_in_central_lower_face() {
        let z = Zone {rect:Rect::new(0,0,200,240), left_eye:None,right_eye:None,
            lips:Some(Rect::new(170,225,190,236))}; // deliberately incorrect mouth detection
        assert!(!eligible_skin_guarded(&z,100,175,FeatureGuards::default()));
    }
    #[test]
    fn lip_guard_allows_acne_on_outer_lower_cheek() {
        let z = Zone {rect:Rect::new(0,0,350,500),
            left_eye:Some(Rect::new(80,130,135,165)),
            right_eye:Some(Rect::new(205,130,260,165)),
            lips:Some(Rect::new(154,365,241,402))};
        let g=FeatureGuards::default();
        // Lower cheeks must not be erased by an overbroad static mouth shield.
        assert!(eligible_skin_guarded(&z,74,335,g));
        assert!(!eligible_skin_guarded(&z,180,385,g));
        assert!(!safe_healing_dab(&z,168,360,g));
    }
    #[test]
    fn no_paint_on_lips_even_if_spot_is_near_mouth() {
        let z=Zone {rect:Rect::new(0,0,300,420),left_eye:None,right_eye:None,
             lips:Some(Rect::new(130,285,202,322))};
        assert!(!safe_healing_dab(&z,150,278,FeatureGuards::default()));
    }
    #[test]
    fn model_failure_is_not_passed_off_as_success() {
        let mut s = Session::new();
        s.execute("file.new",json!({"width":90,"height":90,"depth":8,"mode":"rgb"})).unwrap();
        assert!(s.execute(CMD,json!({"strength":200,"target":"pixels"})).is_err());
        assert!(s.execute(CMD,json!({"mode":"invalid","target":"pixels"})).is_err());
    }
}
