//! Photo AI v0.5: selection-scoped beauty, colour grading and garment wrinkle softening.
//!
//! These are deterministic CPU effects, NOT trained AI. Lipstick, contour and fabric tools
//! require an explicit hand-drawn selection to protect identity, body shape and background.
//! Works offline and journals one undoable command. Max pixel budget limits memory on 8GB Macs.
use super::*;

const CMD: &str = "paint.photoAiEffects";
const MAX_PIXELS: usize = 13_000_000;
const MAX_FABRIC_PIXELS: usize = 3_000_000;

fn parse_color(p: &Value) -> Result<[f32; 3]> {
    let raw = string(p, "lipColor", "#B43B59");
    let hex = raw.strip_prefix('#').ok_or_else(|| bad(CMD, "lipColor must be #RRGGBB"))?;
    if hex.len() != 6 || !hex.is_ascii() {
        return Err(bad(CMD, "lipColor must be #RRGGBB"));
    }
    let parts: Option<Vec<_>> = (0..6).step_by(2).map(|i| u8::from_str_radix(&hex[i..i + 2], 16).ok()).collect();
    let parts = parts.ok_or_else(|| bad(CMD, "lipColor must contain six hex digits"))?;
    Ok([parts[0] as f32 / 255.0, parts[1] as f32 / 255.0, parts[2] as f32 / 255.0])
}

fn luminance(rgb: [f32; 3]) -> f32 { 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2] }
fn mix(a: f32, b: f32, k: f32) -> f32 { a + (b - a) * k }
fn clip(x: f32) -> f32 { x.clamp(0.0, 1.0) }

/// Lightroom-style looks, designed to preserve original detail at moderate strength.
fn preset(rgb: [f32; 3], look: &str) -> [f32; 3] {
    // Exposure, contrast, saturation, red-blue temperature, green/magenta, faded blacks.
    let (ev, ct, sat, temp, tint, fade) = match look {
        "natural" => (0.055, 1.05, 1.06, 0.0, 0.0, 0.0),
        "warm" => (0.065, 1.10, 1.14, 0.092, 0.012, 0.0),
        "cool" => (0.055, 1.10, 1.12, -0.096, 0.0, 0.0),
        "film" => (-0.005, 0.92, 0.87, 0.035, -0.005, 0.035),
        "vivid" => (0.015, 1.12, 1.20, 0.010, 0.0, 0.0),
        "portrait" => (0.085, 0.98, 0.96, 0.042, 0.009, 0.008),
        "moody" => (-0.045, 1.16, 0.84, -0.028, 0.005, 0.010),
        "soft_skin" => (0.065, 0.955, 0.88, 0.030, 0.006, 0.012),
        "japan_clear" => (0.095, 1.035, 0.95, -0.010, 0.006, 0.006),
        "korean_glow" => (0.105, 0.94, 0.86, 0.030, 0.012, 0.016),
        "golden_hour" => (0.035, 1.085, 1.12, 0.095, 0.010, 0.006),
        "sunset" => (0.005, 1.14, 1.17, 0.12, 0.020, 0.008),
        "teal_orange" => (-0.004, 1.12, 1.17, 0.018, 0.022, 0.012),
        "cinematic" => (-0.04, 1.18, 0.90, -0.033, 0.006, 0.018),
        "matte" => (0.005, 0.89, 0.88, 0.015, 0.0, 0.09),
        "vintage" => (-0.007, 0.90, 0.77, 0.078, -0.007, 0.07),
        "black_white" => (0.025, 1.13, 0.0, 0.0, 0.0, 0.0),
        "noir" => (-0.022, 1.29, 0.0, 0.0, 0.0, 0.02),
        "food" => (0.035, 1.10, 1.28, 0.054, 0.006, 0.0),
        "nature" => (0.035, 1.11, 1.26, -0.02, -0.015, 0.0),
        "travel" => (0.055, 1.14, 1.22, -0.012, 0.009, 0.0),
        "night" => (-0.045, 1.24, 1.13, -0.09, 0.006, 0.013),
        "pastel" => (0.095, 0.83, 0.77, 0.034, 0.005, 0.038),
        "rose" => (0.05, 1.03, 1.06, 0.05, 0.04, 0.013),
        "clean_white" => (0.14, 1.04, 0.83, -0.018, 0.004, 0.0),
        _ => return rgb,
    };
    let mut c = rgb.map(|v| clip((v - 0.5) * ct + 0.5 + ev));
    c[0] = clip(c[0] + temp + tint * 0.4);
    c[1] = clip(c[1] - tint);
    c[2] = clip(c[2] - temp + tint * 0.4);
    let y = luminance(c);
    for channel in &mut c { *channel = clip(mix(y, *channel, sat) * (1.0 - fade) + fade * 0.08); }
    c
}

/// 120 reproducible colour *variations* built on 25 calibrated base looks.
/// These are parameter-based styles, not individually authored 3D LUT files.
fn preset_variant(rgb: [f32; 3], code: usize) -> [f32; 3] {
    let group = (code / 12).min(9) as f32;
    let slot = (code % 12) as f32;
    let temp = (slot - 5.5) * 0.014;
    let magenta = (group - 4.5) * 0.009;
    let exposure = ((slot as i32 % 3) as f32 - 1.0) * 0.018;
    let contrast = 0.95 + ((group as usize % 5) as f32) * 0.025;
    let saturation = 0.95 + ((slot as usize % 4) as f32) * 0.035;
    let mut c = rgb.map(|v| clip((v - 0.5) * contrast + 0.5 + exposure));
    c[0] = clip(c[0] + temp + magenta * 0.25);
    c[1] = clip(c[1] - magenta);
    c[2] = clip(c[2] - temp + magenta * 0.25);
    let y = luminance(c);
    c.map(|v| clip(y + (v - y) * saturation))
}

/// Repeatable particles rendered directly on pixels without downloading models.
/// They are artistic overlays, NOT weather simulation or generative AI.
fn decorative_hash(x: i32, y: i32) -> u32 {
    let mut h = (x as u32).wrapping_mul(0x9E3779B1)
        ^ (y as u32).wrapping_mul(0x85EBCA77)
        ^ 0xA32FD4B9;
    h ^= h >> 16;
    h = h.wrapping_mul(0x7FEB352D);
    h ^= h >> 15;
    h = h.wrapping_mul(0x846CA68B);
    h ^ (h >> 16)
}
fn decorative_overlay(rgb: [f32; 3], effect: &str, x: usize, y: usize, w: usize, h: usize) -> [f32; 3] {
    let (x, y) = (x as i32, y as i32);
    let (intensity, tone) = match effect {
        "rainOverlay" => {
            let skew = x + y / 3;
            let cell_x = skew.div_euclid(27);
            let cell_y = y.div_euclid(80);
            let seed = decorative_hash(cell_x, cell_y);
            let lane = skew.rem_euclid(27);
            let at = ((seed >> 10) % 25) as i32;
            let local_y = y.rem_euclid(80);
            let start_y = ((seed >> 16) % 55) as i32;
            let intensity = if seed % 5 == 0 && (lane - at).abs() <= 1 &&
                local_y >= start_y && local_y < start_y + 20 { 0.58 } else { 0.0 };
            (intensity, [0.68, 0.81, 0.95])
        }
        "snowOverlay" => {
            let (tx, ty) = (x.div_euclid(36), y.div_euclid(36));
            let seed = decorative_hash(tx, ty);
            let sx = (seed % 28 + 4) as f32;
            let sy = ((seed >> 8) % 28 + 4) as f32;
            let dx = x.rem_euclid(36) as f32 - sx;
            let dy = y.rem_euclid(36) as f32 - sy;
            let radius = (seed >> 16) % 3 + 1;
            let d = (dx * dx + dy * dy).sqrt();
            let intensity = if seed % 3 == 0 { (radius as f32 + 0.8 - d).clamp(0.0, 1.0) * 0.9 } else { 0.0 };
            (intensity, [0.96, 0.98, 1.0])
        }
        "bokehOverlay" => {
            let (tx, ty) = (x.div_euclid(96), y.div_euclid(96));
            let seed = decorative_hash(tx, ty);
            let dx = x.rem_euclid(96) as f32 - ((seed % 64) + 16) as f32;
            let dy = y.rem_euclid(96) as f32 - (((seed >> 9) % 64) + 16) as f32;
            let radius = ((seed >> 17) % 17 + 9) as f32;
            let d = (dx * dx + dy * dy).sqrt();
            let intensity = if seed % 3 == 0 {
                ((2.5 - (d - radius).abs()) / 2.5).clamp(0.0, 1.0) * 0.44 +
                (1.0 - d / radius).clamp(0.0, 1.0) * 0.15
            } else { 0.0 };
            let tone = if seed & 1 == 0 { [1.0, 0.71, 0.43] } else { [0.40, 0.86, 1.0] };
            (intensity, tone)
        }
        "glowOverlay" => {
            let nx = x as f32 / (w.max(2)-1) as f32;
            let ny = y as f32 / (h.max(2)-1) as f32;
            let d2 = ((nx - 0.77) / 0.36).powi(2) + ((ny - 0.18) / 0.48).powi(2);
            (0.5 / (1.0 + d2 * 8.0), [1.0, 0.82, 0.55])
        }
        _ => (0.0, [0.0, 0.0, 0.0]),
    };
    std::array::from_fn(|i| clip(mix(rgb[i], tone[i], intensity)))
}

pub(super) fn recolor_lip(rgb: [f32; 3], lip: [f32; 3]) -> [f32; 3] {
    // Keep the source pixel's shading and brightness. Change hue/saturation only.
    let y = luminance(rgb);
    let lip_y = luminance(lip).max(0.06);
    let factor = (y / lip_y).clamp(0.42, 1.8);
    [clip(lip[0] * factor), clip(lip[1] * factor), clip(lip[2] * factor)]
}

fn adjust(rgb: [f32; 3], effect: &str, p: &Value, lip: [f32; 3], _strength: f32) -> [f32; 3] {
    match effect {
        "preset" => preset(rgb, string(p, "preset", "natural")),
        "lipstick" => recolor_lip(rgb, lip),
        "brighten" => rgb.map(|c| clip(c + 0.23 * (1.0 - c))),
        "underEye" => {
            // Gently brighten and warm dark regions; preserve local detail.
            let y = luminance(rgb);
            let correction = (0.76 - y).clamp(0.0, 0.5) * 0.34;
            [clip(rgb[0] + correction * 1.08), clip(rgb[1] + correction), clip(rgb[2] + correction * 0.85)]
        },
        "eyelid" => {
            // Subtle eye-crease contrast; this does not synthesize an anatomically new eyelid.
            rgb.map(|c| clip((c - 0.5) * (1.0 + 0.13) + 0.5 + 0.013))
        },
        "eyeColor" => recolor_lip(rgb, lip),
        "blush" => rgb.map(|c| c), // handled below: colour blended with source luminosity
        "skinTone" => {
            let tinted = recolor_lip(rgb, lip);
            std::array::from_fn(|k| mix(rgb[k], tinted[k], 0.18))
        },
        "contour" => {
            // Paint-like dodge/burn inside selection; leaves facial geometry unchanged.
            let shade = string(p, "direction", "shade") == "shade";
            rgb.map(|c| if shade { clip(c * (1.0 - 0.36)) } else { clip(c + 0.30 * (1.0 - c)) })
        },
        _ => rgb,
    }
}

/// Professional RGB adjustment controls. These are local, deterministic image
/// operations: no model is involved and no external network service is used.
/// All parameters are independently adjustable, then mixed once by strength.
fn pro_param(p: &Value, name: &str, lo: f32, hi: f32) -> f32 {
    p.get(name).and_then(Value::as_f64).unwrap_or(0.0).clamp(lo as f64, hi as f64) as f32
}

fn pro_values(p: &Value) -> [f32; 13] {
    let keys = ["exposure", "contrast", "highlights", "shadows", "whites", "blacks", "temperature", "tint", "saturation", "vibrance", "redSaturation", "greenSaturation", "blueSaturation"];
    std::array::from_fn(|i| {
        if i == 0 { 2.0f32.powf(pro_param(p, "exposure", -2.0, 2.0)) }
        else { pro_param(p, keys[i], -100.0, 100.0) }
    })
}

fn pro_grade(rgb: [f32; 3], v: &[f32; 13]) -> [f32; 3] {
    // Exposure was converted from EV into a multiplier once when the command began.
    let exposure_factor = v[0];
    let contrast = v[1] / 100.0;
    let highlights = v[2] / 100.0;
    let shadows = v[3] / 100.0;
    let whites = v[4] / 100.0;
    let blacks = v[5] / 100.0;
    let temperature = v[6] / 100.0;
    let tint = v[7] / 100.0;
    let saturation = v[8] / 100.0;
    let vibrance = v[9] / 100.0;
    let red_sat = v[10] / 100.0;
    let green_sat = v[11] / 100.0;
    let blue_sat = v[12] / 100.0;
    // Exposure uses photographic stops (EV), and the remaining tonal controls
    // use bounded smooth transitions to avoid hard per-channel cutoffs.
    let mut c = rgb.map(|v| clip(v * exposure_factor));
    let lum = luminance(c);
    let shadows_weight = (1.0 - lum).powi(2);
    let highlights_weight = lum.powi(2);
    for v in &mut c {
        *v = clip(*v + shadows * 0.30 * shadows_weight + highlights * 0.30 * highlights_weight);
        *v = clip(*v + whites * 0.14 * (*v * *v) + blacks * 0.14 * (1.0 - *v).powi(2));
        *v = clip((*v - 0.5) * (1.0 + contrast * 0.75) + 0.5);
    }
    c[0] = clip(c[0] + 0.095 * temperature + 0.036 * tint);
    c[1] = clip(c[1] - 0.065 * tint);
    c[2] = clip(c[2] - 0.095 * temperature + 0.036 * tint);
    let y = luminance(c);
    let chroma = c.iter().copied().fold(0.0f32, f32::max)
        - c.iter().copied().fold(1.0f32, f32::min);
    let vibrance_factor = 1.0 + vibrance * 0.55 * (1.0 - chroma).max(0.0);
    c = c.map(|v| clip(y + (v - y) * (1.0 + saturation) * vibrance_factor));
    // Three selective RGB colour ranges, weighted by their relative dominance.
    // This is intentionally labelled RGB selective saturation, not full HSL curves.
    let primary = c;
    let m = primary.iter().copied().fold(0.0f32, f32::max);
    let n = primary.iter().copied().fold(1.0f32, f32::min);
    let range = (m - n).max(0.0001);
    let amounts = [red_sat, green_sat, blue_sat];
    let mut chosen = 0.0f32;
    for k in 0..3 {
        let others = primary[(k + 1) % 3].max(primary[(k + 2) % 3]);
        let band = ((primary[k] - others) / range).clamp(0.0, 1.0);
        chosen += amounts[k] * band;
    }
    let yy = luminance(c);
    c.map(|v| clip(yy + (v - yy) * (1.0 + chosen)))
}

/// Six color-range HSL adjustment (red, yellow, green, cyan, blue, magenta).
/// Adjacent hue bands overlap smoothly, so no hard seam appears in gradients.
fn pro_hsl(rgb: [f32;3], params: &Value) -> [f32;3] {
    let hi=rgb.iter().copied().fold(0.0f32,f32::max);
    let lo=rgb.iter().copied().fold(1.0f32,f32::min);
    let d=hi-lo;
    if d<0.00001 {return rgb;}
    let hue=if hi==rgb[0] {60.0*((rgb[1]-rgb[2])/d).rem_euclid(6.0)}
        else if hi==rgb[1] {60.0*((rgb[2]-rgb[0])/d+2.0)}
        else {60.0*((rgb[0]-rgb[1])/d+4.0)};
    let sat=if hi<=0.00001 {0.0} else {d/hi};
    let names=["red","yellow","green","cyan","blue","magenta"];
    let mut change_h=0.0f32;
    let mut change_s=0.0f32;
    let mut change_l=0.0f32;
    for (i,name) in names.iter().enumerate() {
        let center=i as f32*60.0;
        let distance=(hue-center).abs();
        let distance=distance.min(360.0-distance);
        let weight=(1.0-distance/60.0).max(0.0);
        if weight<=0.0 {continue;}
        change_h+=pro_param(params,&format!("hue_{name}"),-45.0,45.0)*weight;
        change_s+=pro_param(params,&format!("sat_{name}"),-100.0,100.0)*weight;
        change_l+=pro_param(params,&format!("lum_{name}"),-100.0,100.0)*weight;
    }
    let hue=(hue+change_h).rem_euclid(360.0);
    let sat=(sat*(1.0+change_s/100.0)).clamp(0.0,1.0);
    let value=(hi+change_l/100.0*0.30).clamp(0.0,1.0);
    let chroma=value*sat;
    let h=hue/60.0;
    let x=chroma*(1.0-(h.rem_euclid(2.0)-1.0).abs());
    let (r,g,b)=if h<1.0 {(chroma,x,0.0)} else if h<2.0 {(x,chroma,0.0)}
        else if h<3.0 {(0.0,chroma,x)} else if h<4.0 {(0.0,x,chroma)}
        else if h<5.0 {(x,0.0,chroma)} else {(chroma,0.0,x)};
    let m=value-chroma;
    [clip(r+m),clip(g+m),clip(b+m)]
}

/// Sharpen the luminance detail locally using a small 3x3 low-pass reference.
/// The generated colour respects image edges and the current selection mask.
fn pro_sharpen(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize, amount: f32) -> [f32; 3] {
    let base = src[y * w + x];
    let mut sum = [0.0f32; 3];
    for dy in -1i32..=1 {
        let yy = (y as i32 + dy).clamp(0, h as i32 - 1) as usize;
        for dx in -1i32..=1 {
            let xx = (x as i32 + dx).clamp(0, w as i32 - 1) as usize;
            let c = src[yy * w + xx];
            for k in 0..3 { sum[k] += c[k] / 9.0; }
        }
    }
    std::array::from_fn(|k| clip(base[k] + (base[k] - sum[k]) * (amount / 100.0) * 1.6))
}

// Selected-skin smoothing uses a bilateral weight: preserves high-contrast eyes,
// eyelashes, hair edges better than a plain Gaussian. Not a generative restoration.
pub(super) fn skin_pixel(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize) -> [f32; 3] {
    let c = src[y * w + x];
    let mut sum = [0.0; 3];
    let mut total = 0.0;
    for dy in -3i32..=3 {
        let yy = (y as i32 + dy).clamp(0, h as i32 - 1) as usize;
        for dx in -3i32..=3 {
            let xx = (x as i32 + dx).clamp(0, w as i32 - 1) as usize;
            let q = src[yy*w + xx];
            let delta = (c[0] - q[0]).powi(2) + (c[1] - q[1]).powi(2) + (c[2] - q[2]).powi(2);
            let spatial = 1.0 / (1.0 + (dx*dx + dy*dy) as f32 * 0.18);
            let edge = 1.0 / (1.0 + delta * 42.0);
            let weight = spatial * edge;
            for k in 0..3 { sum[k] += q[k] * weight; }
            total += weight;
        }
    }
    sum.map(|v| clip(v / total))
}

// Recover short dark hair wisps drawn against relatively uniform backgrounds.
// Two opposing samples have to agree; this deliberately avoids hallucinating
// surrounding image detail and does not remove clumps or hair on textured areas.
fn hair_pixel(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize) -> [f32; 3] {
    let center = src[y*w+x];
    let base = [center[0], center[1], center[2]];
    let mut best: Option<([f32; 3], f32)> = None;
    for r in [3i32, 5, 8] {
        for (dx,dy) in [(1,0),(0,1),(1,1),(1,-1)] {
            let sample = |sign: i32| -> [f32;3] {
                let xx = (x as i32 + sign*dx*r).clamp(0, w as i32-1) as usize;
                let yy = (y as i32 + sign*dy*r).clamp(0, h as i32-1) as usize;
                let q = src[yy*w+xx]; [q[0], q[1], q[2]]
            };
            let a = sample(-1);
            let b = sample(1);
            let difference = (0..3).map(|k| (a[k]-b[k]).abs()).sum::<f32>() / 3.0;
            let bg: [f32; 3] = std::array::from_fn(|k| 0.5*(a[k]+b[k]));
            let darkness = luminance(bg) - luminance(base);
            if difference < 0.085 && darkness > 0.07 && (0.04..0.99).contains(&luminance(bg)) {
                let score = darkness - 0.6*difference;
                if best.as_ref().is_none_or(|(_,prev)| score > *prev) { best=Some((bg,score)); }
            }
        }
    }
    best.map_or(base, |(c,_)| c)
}

// Geometric stretch of a manually selected lower-body area. The bounding-box
// edge stays fixed, so no canvas resize or unintended changes outside the mask.
fn leg_pixel(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize) -> [f32; 3] {
    let cy = (h as f32 - 1.0)*0.5;
    let ny = (y as f32 - cy) / cy.max(1.0);
    let cx = (w as f32 - 1.0)*0.5;
    let nx = (x as f32 - cx) / cx.max(1.0);
    // Fade to zero at the selection bounds; keep the user selection/mask intact.
    let fade_y = (1.0 - ny*ny).max(0.0);
    let fade_x = (1.0 - nx*nx).max(0.0);
    let source_y = (y as f32 - (y as f32 - cy)*0.48*fade_y*fade_x).clamp(0.0,(h-1) as f32);
    let lo = source_y.floor() as usize;
    let hi = (lo+1).min(h-1);
    let t = source_y-lo as f32;
    let a = src[lo*w+x]; let b=src[hi*w+x];
    [mix(a[0],b[0],t),mix(a[1],b[1],t),mix(a[2],b[2],t)]
}

fn fabric_pixel(src: &[[f32; 4]], x: usize, y: usize, w: usize, h: usize) -> [f32; 3] {
    // Edge-aware 5×5 weighted blur: reduces small folds while keeping cloth seams/edges.
    let c = src[y * w + x];
    let mut sum = [0.0f32; 3];
    let mut weight = 0.0f32;
    for dy in -2i32..=2 {
        let yy = (y as i32 + dy).clamp(0, h as i32 - 1) as usize;
        for dx in -2i32..=2 {
            let xx = (x as i32 + dx).clamp(0, w as i32 - 1) as usize;
            let q = src[yy * w + xx];
            let spatial = 1.0 / (1.0 + (dx * dx + dy * dy) as f32 * 0.35);
            let difference = (luminance([c[0], c[1], c[2]]) - luminance([q[0], q[1], q[2]])).abs();
            let edge = 1.0 / (1.0 + 75.0 * difference * difference);
            let a = spatial * edge;
            for k in 0..3 { sum[k] += q[k] * a; }
            weight += a;
        }
    }
    [sum[0] / weight, sum[1] / weight, sum[2] / weight]
}

pub(super) fn run(s: &mut Session, p: &Value) -> Result<Value> {
    let effect = string(p, "effect", "preset");
    if !matches!(effect, "autoTone" | "autoExposure" | "autoWhiteBalance" | "autoContrast" | "proHsl" | "proGrade" | "proSharpen" | "preset" | "lipstick" | "brighten" | "contour" | "fabricSmooth" | "underEye" | "eyelid" | "eyeColor" | "faceSlim" | "skinSmooth" | "flyawayHair" | "legLength" | "skinTone" | "blush" | "rainOverlay" | "snowOverlay" | "bokehOverlay" | "glowOverlay") {
        return Err(bad(CMD, "unknown effect"));
    }
    let raw_strength = num(p, "strength", 55.0);
    if !raw_strength.is_finite() || !(0.0..=100.0).contains(&raw_strength) {
        return Err(bad(CMD, "strength must be 0..100"));
    }
    if !targets_pixels(p) { return Err(bad(CMD, "image pixels must be targeted")); }
    if effect == "preset" && !matches!(string(p, "preset", "natural"), "natural" | "warm" | "cool" | "film" | "vivid" | "portrait" | "moody" | "soft_skin" | "japan_clear" | "korean_glow" | "golden_hour" | "sunset" | "teal_orange" | "cinematic" | "matte" | "vintage" | "black_white" | "noir" | "food" | "nature" | "travel" | "night" | "pastel" | "rose" | "clean_white") {
        return Err(bad(CMD, "unknown color preset"));
    }
    if effect == "contour" && !matches!(string(p, "direction", "shade"), "shade" | "highlight") {
        return Err(bad(CMD, "unknown contour direction"));
    }
    let strength = raw_strength / 100.0;
    // Parse once per command, not once per pixel (important for 8GB Mac M1).
    let pro_settings = pro_values(p);
    let sharpen_amount = pro_param(p, "amount", 0.0, 100.0);
    let preset_variant_index = p.get("variantIndex").and_then(Value::as_u64)
        .and_then(|n| usize::try_from(n).ok()).filter(|&n| n < 120);
    let lip = if matches!(effect, "lipstick" | "eyeColor" | "skinTone" | "blush") { parse_color(p)? } else { [0.70, 0.20, 0.35] };
    // Automatic lipstick uses real Apple Vision lip contours if the user did not
    // draw a selection. A manual Lasso selection still takes precedence.
    if effect == "lipstick" && s.active().is_some_and(|st| st.doc.selection.is_none()) {
        return super::ai_lipstick::run(s, p, lip, strength);
    }
    let (id, area) = {
        let st = s.active().ok_or(EngineError::NoDocument)?;
        let id = st.active_layer.ok_or_else(|| bad(CMD, "select a raster layer"))?;
        let layer = st.doc.layer(id).ok_or_else(|| bad(CMD, "active layer missing"))?;
        if !matches!(layer.content, LayerContent::Raster(_)) || layer.locks.all || layer.locks.pixels {
            return Err(bad(CMD, "choose an unlocked raster pixel layer"));
        }
        // The region must be explicitly selected for body/face-localized tools.
        let required = matches!(effect, "lipstick" | "contour" | "fabricSmooth" | "underEye" | "eyelid" | "eyeColor" | "faceSlim" | "flyawayHair" | "legLength" | "skinTone" | "blush");
        if required && st.doc.selection.is_none() {
            return Err(bad(CMD, "select ONLY the intended lips/face/clothing region with Marquee/Lasso first"));
        }
        let area = st.doc.selection.as_ref()
            .map_or_else(|| st.doc.bounds(), |selection| photocraft_compose::bounds::content_bounds(selection).intersect(&st.doc.bounds()));
        let n = (area.width() as usize).checked_mul(area.height() as usize).unwrap_or(usize::MAX);
        let max = if matches!(effect, "fabricSmooth" | "skinSmooth" | "flyawayHair" | "legLength") { MAX_FABRIC_PIXELS } else { MAX_PIXELS };
        if n == 0 || n > max { return Err(bad(CMD, format!("area is empty or too large (max {max} pixels); select a smaller area"))); }
        (id, area)
    };
    if strength == 0.0 { return Ok(json!({"effect":effect,"damage":[0,0,0,0],"changedPixels":0,"noChange":true})); }
    let label = format!("Photo AI: {effect}");
    let mut changed_pixels = 0usize;
    let changed = run_stroke(s, &label, Some(id), p, |_pre, surf, selection, _alpha_lock| {
        let fmt = surf.format();
        let original = Region::read(surf, area);
        let w = area.width() as usize;
        let h = area.height() as usize;
        let rgba: Vec<[f32; 4]> = original.data.chunks_exact(original.ch).map(|px| to_rgba(&fmt, px)).collect();
        let automatic = matches!(effect,"autoTone"|"autoExposure"|"autoWhiteBalance"|"autoContrast");
        let correction = if automatic {
            auto_adjust::analyze(rgba.iter().enumerate().map(|(i,px)| {
                let x=area.x0+(i%w) as i32; let y=area.y0+(i/w) as i32;
                (*px,selection.map_or(1.0,|sel|sel.sample_channel(x,y,0)))
            }),effect)
        } else { auto_adjust::Correction::default() };
        let mut output = original.data.clone();
        let mut native = [0.0f32; 8];
        for y in 0..h {
            for x in 0..w {
                let idx = y * w + x;
                let src = rgba[idx];
                if src.iter().any(|v| !v.is_finite()) || src[3] <= 0.001 { continue; }
                let m = selection.map_or(1.0, |sel| sel.sample_channel(area.x0 + x as i32, area.y0 + y as i32, 0).clamp(0.0, 1.0));
                if !m.is_finite() || m <= 0.00001 { continue; }
                // In one-click smoothing mode, avoid blindly blurring every pixel of the photo.
                // This RGB-only skin prior is conservative and is NOT semantic segmentation.
                if effect == "skinSmooth" && selection.is_none() {
                    let [r, g, b, _] = src;
                    let cb = 0.5 - 0.168736*r - 0.331264*g + 0.5*b;
                    let cr = 0.5 + 0.5*r - 0.418688*g - 0.081312*b;
                    if !(0.29..=0.62).contains(&cb) || !(0.43..=0.71).contains(&cr)
                        || r < 0.14 || g < 0.09 || r < g * 1.035 || r < b * 1.05 {
                        continue;
                    }
                }
                let old = [src[0], src[1], src[2]];
                let next = if automatic { auto_adjust::apply(old, correction) }
                    else if effect == "proGrade" { pro_grade(old, &pro_settings) }
                    else if effect == "proHsl" { pro_hsl(old, p) }
                    else if effect == "preset" && preset_variant_index.is_some() {
                        preset_variant(preset(old, string(p, "preset", "natural")), preset_variant_index.unwrap_or(0))
                    }
                    else if matches!(effect, "rainOverlay" | "snowOverlay" | "bokehOverlay" | "glowOverlay") {
                        decorative_overlay(old, effect, x, y, w, h)
                    }
                    else if effect == "proSharpen" { pro_sharpen(&rgba, x, y, w, h, sharpen_amount) }
                    else if effect == "fabricSmooth" { fabric_pixel(&rgba, x, y, w, h) }
                    else if effect == "skinSmooth" { skin_pixel(&rgba, x, y, w, h) }
                    else if effect == "flyawayHair" { hair_pixel(&rgba, x, y, w, h) }
                    else if effect == "legLength" { leg_pixel(&rgba, x, y, w, h) }
                    else if effect == "blush" { // faint colour overlay retaining shadows
                        let tint = recolor_lip(old, lip);
                        std::array::from_fn(|k| mix(old[k],tint[k],0.42))
                    }
                    else if effect == "faceSlim" {
                        // Local horizontal warp within selection; edges fixed, no face detection.
                        let cx = (w as f32 - 1.0) * 0.5;
                        let cy = (h as f32 - 1.0) * 0.5;
                        let nx = (x as f32 - cx) / cx.max(1.0);
                        let ny = (y as f32 - cy) / cy.max(1.0);
                        let vertical = (1.0 - ny * ny).max(0.0);
                        let sample_x = (x as f32 + nx * (1.0 - nx * nx).max(0.0) * cx * 0.22 * vertical).clamp(0.0, (w - 1) as f32);
                        let lo = sample_x.floor() as usize;
                        let hi = (lo + 1).min(w - 1);
                        let frac = sample_x - lo as f32;
                        let a = rgba[y * w + lo];
                        let b = rgba[y * w + hi];
                        [mix(a[0], b[0], frac), mix(a[1], b[1], frac), mix(a[2], b[2], frac)]
                    } else { adjust(old, effect, p, lip, strength) };
                // Contour/brighten strength already applied inside adjust. All others scale here.
                // Every effect is blended exactly once at the requested user strength.
                let power = strength * m;
                let recolored = [mix(old[0], next[0], power), mix(old[1], next[1], power), mix(old[2], next[2], power), src[3]];
                if (0..3).any(|k| (recolored[k] - old[k]).abs() > 0.0005) { changed_pixels += 1; }
                from_rgba_into(&fmt, recolored, &mut native);
                // Preserve the native alpha channel/extra channels from original surface.
                let start = idx * original.ch;
                let ai = alpha_index(&fmt);
                for ch in 0..original.ch {
                    if Some(ch) != ai { output[start + ch] = native[ch]; }
                }
            }
        }
        if changed_pixels == 0 { return Ok(Rect::EMPTY); }
        surf.write_region(area, &output);
        Ok(area)
    })?;
    Ok(json!({"effect":effect,"damage":damage_json(changed),"changedPixels":changed_pixels,"noChange":changed.is_empty()}))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn automatic_effect_respects_selection_alpha_and_one_step_undo() {
        for effect in ["autoTone","autoExposure","autoWhiteBalance","autoContrast"] {
            for depth in [8,16,32] {
                let mut s=Session::new();
                s.execute("file.new",json!({"width":64,"height":64,"depth":depth,"mode":"rgb"})).unwrap();
                s.edit("fixture",|doc,active| {
                    let bounds=doc.bounds();
                    let surf=doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
                    let fmt=surf.format(); let mut pixels=Vec::new();
                    for y in 0..64 {for x in 0..64 {
                        let base=0.17+(x+y) as f32/128.0*0.28;
                        pixels.extend(photocraft_raster::from_rgba(&fmt,[base+0.04,base,base-0.03,1.0]));
                    }}
                    surf.write_region(bounds,&pixels);Ok(())
                }).unwrap();
                s.execute("select.rect",json!({"x":16,"y":16,"width":32,"height":32})).unwrap();
                let before=s.active().unwrap().doc.clone();
                let id=s.active().unwrap().active_layer.unwrap();
                let result=s.execute(CMD,json!({"effect":effect,"strength":100,"target":"pixels"})).unwrap();
                assert!(result["changedPixels"].as_u64().unwrap_or(0)>0,"{effect} depth {depth}");
                let old=Region::read(before.layer(id).unwrap().surface().unwrap(),before.bounds());
                let st=s.active().unwrap();let surf=st.doc.layer(id).unwrap().surface().unwrap();
                let new=Region::read(surf,before.bounds());
                for y in 0..64 {for x in 0..64 {
                    let i=(y*64+x)*old.ch;
                    if !(16..48).contains(&x) || !(16..48).contains(&y) {
                        assert_eq!(&old.data[i..i+old.ch],&new.data[i..i+new.ch]);
                    }
                    if let Some(ai)=alpha_index(&surf.format()) {assert_eq!(old.data[i+ai],new.data[i+ai]);}
                }}
                assert!(s.undo());assert_eq!(s.active().unwrap().doc,before);
            }
        }
    }

    #[test]
    fn zero_strength_auto_reports_no_change() {
        let mut s=Session::new();
        s.execute("file.new",json!({"width":64,"height":64})).unwrap();
        let before=s.active().unwrap().doc.clone();
        let result=s.execute(CMD,json!({"effect":"autoTone","strength":0})).unwrap();
        assert_eq!(result["changedPixels"],0);assert_eq!(result["noChange"],true);
        assert_eq!(s.active().unwrap().doc,before);
    }

    #[test]
    fn hsl_controls_change_colors_and_keep_other_hues() {
        let red=[0.9,0.2,0.1];
        let green=[0.1,0.8,0.2];
        assert!(pro_hsl(red,&json!({})).iter().zip(red).all(|(a,b)|(a-b).abs()<0.00001));
        let changed=pro_hsl(red,&json!({"sat_red":-80}));
        assert!((changed[0]-changed[1]).abs() < (red[0]-red[1]).abs());
        let unchanged=pro_hsl(green,&json!({"sat_red":-80}));
        assert!(unchanged.iter().zip(green).all(|(a,b)|(a-b).abs()<0.00001));
    }
    #[test]
    fn pro_grade_zero_is_identity_and_tone_changes_are_bounded() {
        let input = [0.48, 0.27, 0.63];
        let same = pro_grade(input, &pro_values(&json!({})));
        for k in 0..3 { assert!((same[k]-input[k]).abs() < 0.00001); }
        let bright = pro_grade(input, &pro_values(&json!({"exposure":1.0})));
        assert!(luminance(bright) > luminance(input));
        let mono = pro_grade(input, &pro_values(&json!({"saturation":-100})));
        assert!((mono[0]-mono[1]).abs() < 0.0001);
        assert!((mono[1]-mono[2]).abs() < 0.0001);
        let intense = pro_grade(input, &pro_values(&json!({"exposure":2.0,"highlights":100,"temperature":-80,"redSaturation":90})));
        assert!(intense.iter().all(|v| v.is_finite() && (0.0..=1.0).contains(v)));
    }

    #[test]
    fn pro_sharpen_lifts_local_detail_without_changing_flat_areas() {
        let mut image = vec![[0.5, 0.5, 0.5, 1.0]; 25];
        assert!((pro_sharpen(&image,2,2,5,5,80.0)[0]-0.5).abs() < 0.00001);
        image[12] = [0.7,0.7,0.7,1.0];
        assert!(pro_sharpen(&image,2,2,5,5,80.0)[0] > 0.7);
    }

    #[test]
    fn pro_grade_undo_and_changed_pixels() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":64,"height":50,"depth":8,"mode":"rgb"})).unwrap();
        s.edit("opaque sample", |doc, active| {
            let bounds = doc.bounds();
            let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
            let fmt = surf.format();
            let swatch = photocraft_raster::from_rgba(&fmt, [0.34,0.28,0.22,1.0]);
            let pixels = swatch.repeat(64 * 50);
            surf.write_region(bounds, &pixels);
            Ok(())
        }).unwrap();
        let before = s.active().unwrap().doc.clone();
        let result = s.execute(CMD, json!({"effect":"proGrade", "exposure":1.0,"strength":100,"target":"pixels"})).unwrap();
        assert!(result["changedPixels"].as_u64().unwrap_or(0) > 0);
        assert!(s.undo());
        assert_eq!(s.active().unwrap().doc, before);
    }

    #[test]
    fn localized_adjustment_strength_applies_once() {
        let input = [0.20, 0.25, 0.30];
        let params = json!({"direction":"highlight"});
        for effect in ["brighten", "contour", "underEye", "eyelid"] {
            let full = adjust(input, effect, &params, [0.7, 0.2, 0.35], 1.0);
            let half_strength_output: [f32;3] = std::array::from_fn(|i| mix(input[i], full[i], 0.5));
            for c in 0..3 { assert!((half_strength_output[c] - (input[c] + full[c])*0.5).abs() < 0.000001); }
        }
    }
    #[test]
    fn lipstick_and_looks_are_visibly_distinct() {
        let input = [0.55, 0.38, 0.30];
        let red = recolor_lip(input, [0.85,0.12,0.18]);
        assert!((red[0]-input[0]).abs() > 0.05);
        let bw = preset(input, "black_white");
        assert!((bw[0]-bw[1]).abs() < 0.000001 && (bw[1]-bw[2]).abs() < 0.000001);
    }
    #[test]
    fn image_transform_math_is_bounded() {
        for look in ["natural", "warm", "cool", "film", "vivid", "portrait", "moody"] {
            for v in [0.0, 0.18, 0.5, 0.84, 1.0] {
                assert!(preset([v,v,v], look).iter().all(|a| a.is_finite() && (0.0..=1.0).contains(a)));
            }
        }
    }
    #[test]
    fn localized_tools_require_selection() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":60,"depth":8,"mode":"rgb"})).unwrap();
        for effect in ["lipstick", "contour", "fabricSmooth", "flyawayHair", "legLength", "skinTone", "blush"] {
            assert!(s.execute(CMD, json!({"effect":effect})).is_err());
        }
    }
    #[test]
    fn smoothing_without_selection_is_allowed_for_pixel_layer() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":60,"depth":8,"mode":"rgb"})).unwrap();
        let result = s.execute(CMD, json!({"effect":"skinSmooth", "strength":60,"target":"pixels"})).unwrap();
        assert_eq!(result["effect"], "skinSmooth");
    }

    #[test]
    fn color_preset_undo_and_selection_mask() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":60,"depth":8,"mode":"rgb"})).unwrap();
        s.execute("select.rect", json!({"x":4,"y":5,"width":25,"height":20})).unwrap();
        let before = s.active().unwrap().doc.clone();
        let result = s.execute(CMD, json!({"effect":"preset","preset":"warm","strength":70})).unwrap();
        assert_eq!(result["effect"], "preset");
        assert!(s.undo());
        assert_eq!(s.active().unwrap().doc, before);
    }
    #[test]
    fn lip_hex_rejects_bad_input() {
        assert!(parse_color(&json!({"lipColor":"#FF0155"})).is_ok());
        assert!(parse_color(&json!({"lipColor":"none"})).is_err());
    }
    #[test]
    fn new_tools_are_real_pixel_transformations() {
        let w = 70usize;
        let h = 90usize;
        let mut px = vec![[0.75,0.73,0.68,1.0]; w*h];
        for y in 0..h { px[y*w+30] = [0.08,0.08,0.09,1.0]; }
        let cleaned = hair_pixel(&px,30,45,w,h);
        assert!(luminance(cleaned) > 0.5, "thin hair removed against consistent background");
        px[40*w+30]=[0.05,0.05,0.05,1.0];
        assert!(luminance(skin_pixel(&px,30,40,w,h)) > 0.05);
        let stretched = leg_pixel(&px,30,30,w,h);
        assert!(stretched.iter().all(|c| (0.0..=1.0).contains(c)));
    }

    #[test]
    fn all_120_colour_variants_are_bounded_and_reproducible() {
        let base = [0.45, 0.57, 0.70];
        let mut unique = std::collections::HashSet::new();
        for i in 0..120 {
            let out = preset_variant(base, i);
            assert_eq!(out, preset_variant(base, i));
            assert!(out.iter().all(|v| v.is_finite() && (0.0..=1.0).contains(v)));
            unique.insert(out.map(|v| v.to_bits()));
        }
        assert_eq!(unique.len(), 120, "Each variant should be visually distinct in floating point");
    }
    #[test]
    fn artistic_overlays_modify_only_target_channels_and_are_repeatable() {
        let base = [0.15, 0.20, 0.30];
        for effect in ["rainOverlay", "snowOverlay", "bokehOverlay", "glowOverlay"] {
            let mut modified = 0;
            for y in 0..240 {
                for x in 0..240 {
                    let out = decorative_overlay(base, effect, x, y, 240, 240);
                    assert_eq!(out, decorative_overlay(base, effect, x, y, 240, 240));
                    assert!(out.iter().all(|v| v.is_finite() && (0.0..=1.0).contains(v)));
                    if out != base { modified += 1; }
                }
            }
            assert!(modified > 0, "{effect} should visibly change some pixels");
        }
    }
    #[test]
    fn effects_keep_undo_and_require_selection() {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":80,"height":100,"depth":8,"mode":"rgb"})).unwrap();
        assert!(s.execute(CMD, json!({"effect":"legLength","strength":75})).is_err());
        assert!(s.execute(CMD, json!({"effect":"flyawayHair","strength":75})).is_err());
        s.execute("select.rect",json!({"x":8,"y":10,"width":50,"height":70})).unwrap();
        let before=s.active().unwrap().doc.clone();
        let result=s.execute(CMD,json!({"effect":"skinSmooth","strength":80})).unwrap();
        assert_eq!(result["effect"],"skinSmooth");
        assert!(s.undo());
        assert_eq!(s.active().unwrap().doc,before);
    }

}
