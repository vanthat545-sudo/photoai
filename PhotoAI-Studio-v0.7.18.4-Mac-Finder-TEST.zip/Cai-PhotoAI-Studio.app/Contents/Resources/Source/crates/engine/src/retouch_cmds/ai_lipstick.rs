//! Automatic lipstick: Apple Vision identifies the outer lip contour and the
//! inner (mouth/teeth) opening. The mask is feathered inside the actual polygon,
//! not the face/mouth bounding box. The user-selected colour changes real pixels.
//! Offline, one undoable document edit. Explicit Lasso selections continue to
//! use the existing manual lipstick algorithm in photo_ai_effects.rs.
use super::*;

const CMD: &str = "paint.photoAiEffects";
const MAX_PIXELS: usize = 13_000_000;

// Local colour blend. The identically named helper in photo_ai_effects
// is private to its sibling module, so ai_lipstick cannot call it.
#[inline]
fn mix(a: f32, b: f32, weight: f32) -> f32 {
    a + (b - a) * weight
}

#[derive(Clone, Debug)]
struct LipContour {
    outer: Vec<(f32, f32)>,
    inner: Vec<(f32, f32)>,
    rect: Rect,
}

fn parse_points(value: Option<&Value>, canvas: Rect) -> Option<Vec<(f32, f32)>> {
    let pts = value?.as_array()?;
    if !(6..=128).contains(&pts.len()) { return None; }
    let mut points = Vec::with_capacity(pts.len());
    for item in pts {
        let a = item.as_array()?;
        if a.len() != 2 { return None; }
        let x = a[0].as_f64()?;
        let y = a[1].as_f64()?;
        if !x.is_finite() || !y.is_finite() || !(0.0..=1.0).contains(&x) || !(0.0..=1.0).contains(&y) { return None; }
        points.push((canvas.x0 as f32 + x as f32 * canvas.width() as f32,
                     canvas.y0 as f32 + y as f32 * canvas.height() as f32));
    }
    Some(points)
}

fn bounding_rect(poly: &[(f32, f32)], canvas: Rect) -> Option<Rect> {
    let (mut min_x, mut min_y, mut max_x, mut max_y) =
        (f32::INFINITY, f32::INFINITY, f32::NEG_INFINITY, f32::NEG_INFINITY);
    for &(x, y) in poly {
        min_x = min_x.min(x); min_y = min_y.min(y);
        max_x = max_x.max(x); max_y = max_y.max(y);
    }
    if max_x - min_x < 3.0 || max_y - min_y < 2.0 { return None; }
    let area = Rect::new(min_x.floor() as i32 - 2, min_y.floor() as i32 - 2,
                         max_x.ceil() as i32 + 2, max_y.ceil() as i32 + 2)
               .intersect(&canvas);
    (!area.is_empty()).then_some(area)
}

fn contour_from_vision(face: &Value, canvas: Rect) -> Option<LipContour> {
    let outer = parse_points(face.get("outerLipsPoints"), canvas)?;
    let rect = bounding_rect(&outer, canvas)?;
    // Do not colour a huge face-shaped polygon if Vision gave malformed contour.
    let face_box = face.get("box")?.as_array()?;
    if face_box.len() != 4 { return None; }
    let fw = (face_box[2].as_f64()? - face_box[0].as_f64()?) * canvas.width() as f64;
    let fh = (face_box[3].as_f64()? - face_box[1].as_f64()?) * canvas.height() as f64;
    if fw <= 0.0 || fh <= 0.0 || rect.width() as f64 > fw * 0.85 || rect.height() as f64 > fh * 0.42 {
        return None;
    }
    let inner = parse_points(face.get("innerLipsPoints"), canvas).unwrap_or_default();
    Some(LipContour { outer, inner, rect })
}

fn in_polygon(poly: &[(f32, f32)], x: f32, y: f32) -> bool {
    if poly.len() < 3 { return false; }
    let mut inside = false;
    for i in 0..poly.len() {
        let (ax, ay) = poly[i];
        let (bx, by) = poly[(i + 1) % poly.len()];
        if (ay > y) != (by > y) && x < (bx - ax) * ((y - ay) / (by - ay)) + ax {
            inside = !inside;
        }
    }
    inside
}

fn edge_distance(poly: &[(f32, f32)], x: f32, y: f32) -> f32 {
    let mut d2 = f32::INFINITY;
    for i in 0..poly.len() {
        let (ax, ay) = poly[i];
        let (bx, by) = poly[(i + 1) % poly.len()];
        let dx = bx - ax;
        let dy = by - ay;
        let t = (((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy).max(0.00001)).clamp(0.0, 1.0);
        let ex = x - (ax + t * dx);
        let ey = y - (ay + t * dy);
        d2 = d2.min(ex * ex + ey * ey);
    }
    d2.sqrt()
}

/// Anti-aliased weight: preserve skin outside lip edge and teeth inside inner lip contour.
fn lip_coverage(lip: &LipContour, x: f32, y: f32) -> f32 {
    if !in_polygon(&lip.outer, x, y) { return 0.0; }
    if lip.inner.len() >= 3 && in_polygon(&lip.inner, x, y) { return 0.0; }
    let outer = (edge_distance(&lip.outer, x, y) / 1.5).clamp(0.0, 1.0);
    let inner = if lip.inner.len() >= 3 {
        (edge_distance(&lip.inner, x, y) / 1.25).clamp(0.0, 1.0)
    } else { 1.0 };
    outer.min(inner)
}

pub(super) fn run(s: &mut Session, p: &Value, colour: [f32; 3], strength: f32) -> Result<Value> {
    let (id, bounds, all_pixels) = {
        let st = s.active().ok_or(EngineError::NoDocument)?;
        let id = st.active_layer.ok_or_else(|| bad(CMD, "Chọn lớp ảnh pixel trước khi tô son"))?;
        let layer = st.doc.layer(id).ok_or_else(|| bad(CMD, "Không tìm thấy lớp ảnh"))?;
        if !matches!(layer.content, LayerContent::Raster(_)) || layer.locks.all || layer.locks.pixels {
            return Err(bad(CMD, "Chọn lớp ảnh pixel không khóa (không phải mask)"));
        }
        let bounds = st.doc.bounds();
        let w = bounds.width() as usize;
        let h = bounds.height() as usize;
        if w == 0 || h == 0 || w.checked_mul(h).unwrap_or(usize::MAX) > MAX_PIXELS {
            return Err(bad(CMD, "Ảnh vượt giới hạn 13 triệu pixel; hãy chỉnh bản sao nhỏ hơn hoặc chọn môi bằng Lasso"));
        }
        if strength <= 0.0 {
            return Ok(json!({"effect":"lipstick", "changedPixels":0, "noChange":true,
                "damage":[0,0,0,0], "message":"Tăng cường độ son lớn hơn 0"}));
        }
        let surf = layer.surface().ok_or_else(|| bad(CMD, "Lớp ảnh không chứa pixel"))?;
        let region = Region::read(surf, bounds);
        let fmt = surf.format();
        let all_pixels: Vec<[f32; 4]> = region.data.chunks_exact(region.ch).map(|px| to_rgba(&fmt, px)).collect();
        (id, bounds, all_pixels)
    };
    let response = super::ai_auto_retouch::apple_vision(&all_pixels, bounds.width() as usize, bounds.height() as usize)?;
    paint_with_landmarks(s, p, colour, strength, bounds, id, &response)
}

/// Kept separate from Vision I/O so all pixel-safety rules can be tested with
/// synthetic contours, even where the macOS helper is unavailable.
fn paint_with_landmarks(s: &mut Session, p: &Value, colour: [f32;3], strength: f32,
                        bounds: Rect, id: LayerId, response: &Value) -> Result<Value> {
    let faces = response["faces"].as_array().map_or(0, Vec::len);
    let contours: Vec<LipContour> = response["faces"].as_array().into_iter().flatten()
        .take(8).filter_map(|face| contour_from_vision(face, bounds)).collect();
    if contours.is_empty() {
        return Err(bad(CMD, "Apple Vision chưa nhận diện được viền môi. Chọn Lasso (L) khoanh riêng môi để tô thủ công, hoặc dùng ảnh mặt rõ hơn"));
    }
    let mut changed_pixels = 0usize;
    let mut touched = Rect::EMPTY;
    let changed = run_stroke(s, "AI Lipstick (Apple Vision contours)", Some(id), p,
        |_pre, surf, _selection, _lock| {
        let fmt = surf.format();
        let mut native = [0.0f32; 8];
        for lip in &contours {
            let area = lip.rect;
            let region = Region::read(surf, area);
            let w = area.width() as usize;
            let mut out = region.data.clone();
            let mut did_change = false;
            for y in 0..area.height() as usize {
                for x in 0..w {
                    let gx = area.x0 + x as i32;
                    let gy = area.y0 + y as i32;
                    let cover = lip_coverage(lip, gx as f32 + 0.5, gy as f32 + 0.5);
                    if cover < 0.002 { continue; }
                    let idx = (y * w + x) * region.ch;
                    let old_px = to_rgba(&fmt, &region.data[idx..idx + region.ch]);
                    if old_px[3] < 0.001 { continue; }
                    let old = [old_px[0], old_px[1], old_px[2]];
                    let tinted = super::photo_ai_effects::recolor_lip(old, colour);
                    let power = cover * strength;
                    let next = [mix(old[0], tinted[0], power), mix(old[1], tinted[1], power),
                                mix(old[2], tinted[2], power), old_px[3]];
                    if (0..3).all(|k| (next[k] - old[k]).abs() < 0.0005) { continue; }
                    from_rgba_into(&fmt, next, &mut native);
                    let alpha = alpha_index(&fmt);
                    for k in 0..region.ch {
                        if Some(k) != alpha { out[idx + k] = native[k]; }
                    }
                    changed_pixels += 1;
                    did_change = true;
                }
            }
            if did_change {
                surf.write_region(area, &out);
                touched = touched.union(&area);
            }
        }
        Ok(touched)
    })?;
    Ok(json!({"effect":"lipstick", "model":"Apple Vision mouth landmarks",
        "faces":faces, "lipRegions":contours.len(), "changedPixels":changed_pixels,
        "damage":damage_json(changed), "noChange":changed.is_empty(),
        "message":if changed.is_empty() { "Môi được nhận diện nhưng ảnh chưa đổi; hãy chọn màu khác hoặc tăng cường độ" }
            else { "Đã tô son trong viền môi, bảo vệ khoảng miệng/răng; hoàn tác bằng ⌘Z" }}))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn polygon_mask_only_colours_lips_not_teeth_or_skin() {
        let lip = LipContour {
            outer: vec![(10.0,10.0),(30.0,10.0),(30.0,20.0),(10.0,20.0)],
            inner: vec![(17.0,13.0),(23.0,13.0),(23.0,17.0),(17.0,17.0)],
            rect: Rect::new(8,8,32,22),
        };
        assert_eq!(lip_coverage(&lip, 5.0, 15.0),0.0, "skin unchanged");
        assert_eq!(lip_coverage(&lip, 20.0, 15.0),0.0, "teeth unchanged");
        assert!(lip_coverage(&lip, 12.0, 15.0)>0.5, "lip takes tint");
        assert!(lip_coverage(&lip, 10.1, 15.0)<0.2, "feather near lip border");
    }
    #[test]
    fn lipstick_command_changes_only_lips_and_can_undo() {
        let mut session = Session::new();
        session.execute("file.new", json!({"width":100,"height":100,"depth":8,"mode":"rgb"})).unwrap();
        session.edit("synthetic portrait", |doc, active| {
            let bounds = doc.bounds();
            let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
            let fmt = surf.format();
            let mut data = Vec::new();
            for _ in 0..10000 {
                data.extend(photocraft_raster::from_rgba(&fmt,[0.65,0.45,0.40,1.0]));
            }
            surf.write_region(bounds, &data);
            Ok(())
        }).unwrap();
        let previous = session.active().unwrap().doc.clone();
        let id = session.active().unwrap().active_layer.unwrap();
        let face = json!({"box":[0.12,0.1,0.9,0.93],
            "outerLipsPoints":[[0.30,0.60],[0.40,0.56],[0.55,0.56],
                [0.66,0.60],[0.62,0.65],[0.50,0.67],[0.37,0.65]],
            "innerLipsPoints":[[0.43,0.605],[0.49,0.598],[0.54,0.605],
                [0.54,0.62],[0.48,0.627],[0.43,0.62]]});
        let result = paint_with_landmarks(&mut session,
            &json!({"effect":"lipstick","strength":95,"target":"pixels"}),
            [0.95,0.12,0.22],0.95,Rect::new(0,0,100,100),id,
            &json!({"faces":[face]})).unwrap();
        assert!(result["changedPixels"].as_u64().unwrap_or(0) > 20);
        let prior = Region::read(previous.layer(id).unwrap().surface().unwrap(),Rect::new(0,0,100,100));
        let now = Region::read(session.active().unwrap().doc.layer(id).unwrap().surface().unwrap(),Rect::new(0,0,100,100));
        for (x,y) in [(5,5),(20,60),(80,60),(50,61)] { // outer skin and inner mouth
            let i=(y*100+x)*prior.ch;
            assert_eq!(&now.data[i..i+prior.ch], &prior.data[i..i+prior.ch],"unprotected pixel at {x},{y}");
        }
        let lip_i=(62*100+35)*prior.ch;
        assert_ne!(&now.data[lip_i..lip_i+prior.ch],&prior.data[lip_i..lip_i+prior.ch]);
        assert!(session.undo());
        assert_eq!(session.active().unwrap().doc, previous);
    }
    #[test]
    fn missing_or_malformed_contours_cannot_colour_rectangle() {
        let bounds = Rect::new(0,0,100,100);
        let missing = json!({"box":[0.2,0.2,0.8,0.8],"mouth":[0.3,0.5,0.7,0.7]});
        assert!(contour_from_vision(&missing, bounds).is_none());
        let enormous = json!({"box":[0.2,0.2,0.8,0.8],
            "outerLipsPoints":[[0.1,0.2],[0.9,0.2],[0.9,0.3],[0.9,0.4],[0.1,0.4],[0.1,0.3]]});
        assert!(contour_from_vision(&enormous, bounds).is_none());
    }
}
