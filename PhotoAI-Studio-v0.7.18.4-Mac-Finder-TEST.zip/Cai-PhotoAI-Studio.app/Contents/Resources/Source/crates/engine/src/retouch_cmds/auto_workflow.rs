//! Local, allowlisted automation. Work on an isolated COW document and commit once.
//! Tool choice is rule-based; only the existing Apple Vision stage uses ML.
use super::*;

const CMD: &str = "paint.photoAiAuto";

fn strength(p: &Value) -> Result<f32> {
    let v = match p.get("strength") {
        None => 55.0,
        Some(v) => v.as_f64().ok_or_else(|| bad(CMD, "strength must be a number"))?,
    };
    if !v.is_finite() || !(0.0..=100.0).contains(&v) {
        return Err(bad(CMD, "strength must be 0..100"));
    }
    Ok(v as f32)
}

fn plan(goal: &str, amount: f32) -> Result<Vec<(&'static str, Value)>> {
    let effect = match goal {
        "auto" | "portrait" | "tone" => Some("autoTone"),
        "exposure" => Some("autoExposure"),
        "whiteBalance" => Some("autoWhiteBalance"),
        "contrast" => Some("autoContrast"),
        "blemish" | "skin" => None,
        _ => return Err(bad(CMD, "unknown goal")),
    };
    let mut steps = Vec::new();
    if let Some(effect) = effect {
        steps.push(("paint.photoAiEffects", json!({"effect":effect,"strength":amount,"target":"pixels"})));
    }
    // Auto is colour-only off macOS and explicitly reports the missing face stage.
    if matches!(goal, "portrait" | "blemish" | "skin") || (goal == "auto" && cfg!(target_os = "macos")) {
        steps.push(("paint.aiAutoRetouch", json!({
            "mode":if goal == "skin" || goal == "blemish" { "skinOnly" } else { "natural" },
            "blemishOnly":goal == "blemish", "strength":amount,
            "protectEyes":true,"protectLips":true,"target":"pixels"
        })));
    }
    Ok(steps)
}

pub(super) fn run(s: &mut Session, p: &Value) -> Result<Value> {
    run_with(s, p, |work, id, args| work.execute(id, args))
}

// Injection is confined to this module so tests can fail a later tool deterministically.
fn run_with(s: &mut Session, p: &Value,
    mut dispatch: impl FnMut(&mut Session, &str, Value) -> Result<Value>) -> Result<Value> {
    let goal = match p.get("goal") {
        None => "auto",
        Some(v) => v.as_str().ok_or_else(|| bad(CMD, "goal must be a string"))?,
    };
    let dry_run = match p.get("dryRun") {
        None => false,
        Some(value) => value.as_bool().ok_or_else(|| bad(CMD, "dryRun must be a boolean"))?,
    };
    let amount = strength(p)?;
    let steps = plan(goal, amount)?;
    if !targets_pixels(p) { return Err(bad(CMD, "select image pixels, not mask/channel")); }
    let st = s.active().ok_or(EngineError::NoDocument)?;
    let id = st.active_layer.ok_or_else(|| bad(CMD, "select a pixel layer"))?;
    let layer = st.doc.layer(id).ok_or_else(|| bad(CMD, "active layer missing"))?;
    if !matches!(layer.content, LayerContent::Raster(_)) || layer.locks.all || layer.locks.pixels {
        return Err(bad(CMD, "choose an unlocked raster layer"));
    }
    let bounds = st.doc.bounds();
    let n = (bounds.width() as usize).checked_mul(bounds.height() as usize).unwrap_or(usize::MAX);
    if n == 0 || n > 13_000_000 { return Err(bad(CMD, "automation supports up to 13 million pixels; use a resized copy")); }
    let before = st.doc.clone();
    let stage_list: Vec<Value> = steps.iter().map(|(cmd,args)| json!({"command":cmd,"params":args})).collect();
    let mut warnings = if goal == "auto" && !cfg!(target_os = "macos") {
        vec!["Bỏ qua chỉnh khuôn mặt: Apple Vision cần macOS; chỉ xử lý ánh sáng và màu.".to_owned()]
    } else { vec![] };
    if dry_run {
        return Ok(json!({"goal":goal,"planner":"local-rules","plannedSteps":stage_list,"warnings":warnings,"dryRun":true,"noChange":true}));
    }
    if amount == 0.0 {
        return Ok(json!({"goal":goal,"steps":[],"warnings":warnings,"appliedSteps":0,"noChange":true,"reason":"zeroStrength"}));
    }
    let mut work = Session::new();
    work.add_document((*before).clone(), None);
    if let Some(state) = work.active_mut() {
        state.active_layer = Some(id);
        state.selected_layers = vec![id];
    }
    let mut reports = Vec::new();
    let mut applied = 0usize;
    for (cmd, args) in steps {
        let prior = work.active().ok_or(EngineError::NoDocument)?.doc.clone();
        let result = dispatch(&mut work, cmd, args)
            .map_err(|e| bad(CMD, format!("{cmd} failed; original image unchanged: {e}")))?;
        let after = &work.active().ok_or(EngineError::NoDocument)?.doc;
        let changed = **after != *prior;
        // Keep nested tool warnings visible in the workflow's top-level feedback.
        if let Some(items) = result["warnings"].as_array() {
            for warning in items.iter().filter_map(Value::as_str) {
                warnings.push(warning.to_owned());
            }
        }
        applied += usize::from(changed);
        reports.push(json!({"command":cmd,"status":if changed {"applied"} else {"unchanged"},"result":result}));
    }
    let finished = work.active().ok_or(EngineError::NoDocument)?.doc.clone();
    let no_change = *finished == *before;
    if !no_change {
        // No file is overwritten. The original document becomes the one-step undo state.
        s.edit("Photo AI automatic workflow", |doc, active| {
            *doc = (*finished).clone();
            *active = Some(id);
            Ok(())
        })?;
        if let Some(state) = s.active_mut() { state.last_damage = Some(bounds); }
    }
    Ok(json!({"goal":goal,"planner":"local-rules","steps":reports,"warnings":warnings,
        "appliedSteps":applied,"noChange":no_change,"undoSteps":if no_change {0} else {1}}))
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture(depth: u32) -> Session {
        let mut s = Session::new();
        s.execute("file.new", json!({"width":64,"height":64,"mode":"rgb","depth":depth})).unwrap();
        s.edit("fixture", |doc, active| {
            let bounds = doc.bounds();
            let surf = doc.layer_mut(active.unwrap()).unwrap().surface_mut().unwrap();
            let pixel = photocraft_raster::from_rgba(&surf.format(), [0.22,0.20,0.18,1.0]);
            surf.write_region(bounds, &pixel.repeat(64*64));
            Ok(())
        }).unwrap();
        s
    }
    #[test]
    fn each_goal_uses_only_allowlisted_tools_and_face_guards() {
        for goal in ["auto","portrait","tone","exposure","whiteBalance","contrast","blemish","skin"] {
            let steps = plan(goal, 55.0).unwrap();
            assert!(!steps.is_empty() && steps.len() <= 2);
            for (cmd,args) in steps {
                assert!(matches!(cmd,"paint.photoAiEffects"|"paint.aiAutoRetouch"));
                if cmd == "paint.aiAutoRetouch" {
                    assert_eq!(args["protectEyes"],true);
                    assert_eq!(args["protectLips"],true);
                }
            }
        }
        assert!(plan("shell",55.0).is_err());
        assert_eq!(plan("blemish",55.0).unwrap()[0].1["blemishOnly"],true);
    }
    #[test]
    fn invalid_requests_and_dry_run_preserve_original() {
        let mut s=fixture(8);
        let before=s.active().unwrap().doc.clone();
        for p in [json!({"strength":-1}),json!({"strength":"55"}),json!({"goal":"bad"}),json!({"target":"mask"})] {
            assert!(run(&mut s,&p).is_err());
            assert_eq!(s.active().unwrap().doc,before);
        }
        assert_eq!(run(&mut s,&json!({"goal":"portrait","dryRun":true})).unwrap()["dryRun"],true);
        assert_eq!(s.active().unwrap().doc,before);
    }
    #[test]
    fn tone_changes_pixels_and_one_undo_restores_all_depths() {
        for depth in [8,16,32] {
            let mut s=fixture(depth);
            s.execute("select.rect",json!({"x":16,"y":16,"width":32,"height":32})).unwrap();
            let before=s.active().unwrap().doc.clone();
            let r=run(&mut s,&json!({"goal":"tone","strength":100})).unwrap();
            assert_eq!(r["noChange"],false);
            assert_eq!(r["undoSteps"],1);
            let id=s.active().unwrap().active_layer.unwrap();
            let old=Region::read(before.layer(id).unwrap().surface().unwrap(), before.bounds());
            let surf=s.active().unwrap().doc.layer(id).unwrap().surface().unwrap();
            let new=Region::read(surf,before.bounds());
            for y in 0..64 { for x in 0..64 {
                let i=(y*64+x)*old.ch;
                if !(16..48).contains(&x) || !(16..48).contains(&y) {
                    assert_eq!(&old.data[i..i+old.ch],&new.data[i..i+new.ch]);
                }
                if let Some(ai)=alpha_index(&surf.format()) { assert_eq!(old.data[i+ai],new.data[i+ai]); }
            }}
            let after=s.active().unwrap().doc.clone();
            assert!(s.undo());
            assert_eq!(s.active().unwrap().doc,before);
            assert!(s.redo());
            assert_eq!(s.active().unwrap().doc,after);
        }
    }
    #[test]
    fn failed_second_step_never_commits_first_step() {
        let mut s=fixture(8);
        let before=s.active().unwrap().clone();
        let r=run_with(&mut s,&json!({"goal":"portrait"}),|work,cmd,args| {
            if cmd=="paint.aiAutoRetouch" { Err(bad(CMD,"injected failure")) }
            else { work.execute(cmd,args) }
        });
        assert!(r.is_err());
        assert_eq!(s.active().unwrap().doc,before.doc);
        assert_eq!(s.active().unwrap().revision,before.revision);
    }
    #[test]
    fn zero_strength_does_not_dispatch_or_add_history() {
        let mut s=fixture(8);
        let revision=s.active().unwrap().revision;
        let r=run_with(&mut s,&json!({"goal":"portrait","strength":0}),|_,_,_| panic!("must not run"));
        assert_eq!(r.unwrap()["reason"],"zeroStrength");
        assert_eq!(s.active().unwrap().revision,revision);
    }

    #[test]
    fn locked_layer_and_empty_document_are_rejected() {
        assert!(run(&mut Session::new(), &json!({"goal":"tone"})).is_err());
        let mut s=fixture(8);
        s.edit("lock", |doc, active| {
            doc.layer_mut(active.unwrap()).unwrap().locks.pixels=true; Ok(())
        }).unwrap();
        let before=s.active().unwrap().doc.clone();
        assert!(run(&mut s,&json!({"goal":"tone"})).is_err());
        assert_eq!(s.active().unwrap().doc,before);
    }

    #[test]
    fn unchanged_tool_report_cannot_create_fake_success() {
        let mut s=fixture(8);
        let revision=s.active().unwrap().revision;
        let r=run_with(&mut s,&json!({"goal":"tone"}),|_,_,_| Ok(json!({"changedPixels":999}))).unwrap();
        assert_eq!(r["noChange"],true);
        assert_eq!(r["appliedSteps"],0);
        assert_eq!(s.active().unwrap().revision,revision);
    }

    #[test]
    fn malformed_dry_run_never_dispatches_or_changes_document() {
        let mut s=fixture(8);
        let before=s.active().unwrap().doc.clone();
        for value in [json!("true"),json!(1),json!(null)] {
            assert!(run_with(&mut s,&json!({"goal":"tone","dryRun":value}),|_,_,_| panic!("must not run")).is_err());
            assert_eq!(s.active().unwrap().doc,before);
        }
    }
    #[test]
    fn workflow_keeps_nested_warnings() {
        let mut s=fixture(8);
        let result=run_with(&mut s,&json!({"goal":"tone"}),|_,_,_| Ok(json!({"warnings":["Cân bằng trắng bỏ qua"]}))).unwrap();
        assert_eq!(result["warnings"],json!(["Cân bằng trắng bỏ qua"]));
        assert_eq!(result["noChange"],true);
    }
}
