//! Bounded automatic tonal correction. Deterministic, no trained model.
//! Statistics exclude transparent/invalid pixels and honor selection weights.
#[derive(Clone, Copy, Debug)]
pub(super) struct Correction { pub gain: f32, pub contrast: f32, pub wb: [f32; 3] }
impl Default for Correction {
    fn default() -> Self { Self { gain: 1.0, contrast: 1.0, wb: [1.0; 3] } }
}
fn luma(c: [f32; 3]) -> f32 { 0.2126*c[0]+0.7152*c[1]+0.0722*c[2] }

pub(super) fn analyze(samples: impl Iterator<Item=([f32;4],f32)>, mode: &str) -> Correction {
    let mut bins = [0.0f64;256];
    let mut total = 0.0f64;
    let mut neutrals = [0.0f64;3];
    let mut neutral_weight = 0.0f64;
    for (px, mask) in samples {
        if !mask.is_finite() || mask <= 0.0 || px.iter().any(|v| !v.is_finite()) || px[3] < 0.95 { continue; }
        let rgb = [px[0],px[1],px[2]];
        if rgb.iter().any(|v| !(0.0..=1.0).contains(v)) { continue; }
        let weight = f64::from(mask.clamp(0.0,1.0));
        let lum = luma(rgb);
        let bin = (lum*255.0).round().clamp(0.0,255.0) as usize;
        if let Some(v) = bins.get_mut(bin) { *v += weight; }
        total += weight;
        let hi = rgb.into_iter().fold(0.0f32,f32::max);
        let lo = rgb.into_iter().fold(1.0f32,f32::min);
        // Avoid gray-world correction of skin, foliage and other dominant colors.
        if (0.15..=0.85).contains(&lum) && hi-lo <= 0.10 {
            for (sum,c) in neutrals.iter_mut().zip(rgb) { *sum += f64::from(c)*weight; }
            neutral_weight += weight;
        }
    }
    let mut out = Correction::default();
    if total < 32.0 { return out; }
    let percentile = |fraction: f64| -> f32 {
        let mut sum=0.0;
        for (i,weight) in bins.iter().enumerate() {
            sum += weight;
            if sum >= total*fraction { return i as f32/255.0; }
        }
        1.0
    };
    let low=percentile(0.02); let mid=percentile(0.50); let high=percentile(0.98);
    if matches!(mode,"autoTone"|"autoExposure") && mid > 0.015 && mid < 0.98 {
        // Conservative target band avoids changing already balanced scenes.
        let target=mid.clamp(0.35,0.65);
        out.gain=(target/mid).clamp(0.70,1.45);
        if out.gain > 1.0 && high > 0.0 { out.gain=out.gain.min((0.98/high).max(1.0)); }
    }
    let span=high-low;
    if matches!(mode,"autoTone"|"autoContrast") && (0.05..0.65).contains(&span) {
        out.contrast=(0.65/span).clamp(1.0,1.12);
    }
    if matches!(mode,"autoTone"|"autoWhiteBalance") && neutral_weight >= 32.0 {
        let mean=neutrals.map(|v| (v/neutral_weight) as f32);
        let target=(mean[0]+mean[1]+mean[2])/3.0;
        out.wb=mean.map(|v| (target/v.max(0.01)).clamp(0.90,1.10));
    }
    out
}

pub(super) fn apply(rgb: [f32;3], c: Correction) -> [f32;3] {
    // Gain, mild white balance, then monotonic contrast; no geometry or blur.
    std::array::from_fn(|i| {
        let v=(rgb[i]*c.wb[i]*c.gain).clamp(0.0,1.0);
        ((v-0.5)*c.contrast+0.5).clamp(0.0,1.0)
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn dark_scene_brightens_and_white_is_preserved() {
        let c=analyze(std::iter::repeat_n(([0.2,0.2,0.2,1.0],1.0),64),"autoExposure");
        assert!(apply([0.2;3],c)[0]>0.2);
        let c=analyze(std::iter::repeat_n(([1.0;4],1.0),64),"autoTone");
        assert_eq!(apply([1.0;3],c),[1.0;3]);
    }
    #[test] fn neutral_cast_reduces_without_gray_world_on_saturated_scene() {
        let c=analyze(std::iter::repeat_n(([0.48,0.45,0.40,1.0],1.0),64),"autoWhiteBalance");
        let p=apply([0.48,0.45,0.40],c);
        assert!((p[0]-p[2]).abs()<0.08);
        let c=analyze(std::iter::repeat_n(([0.7,0.3,0.1,1.0],1.0),64),"autoWhiteBalance");
        assert_eq!(c.wb,[1.0;3]);
    }
    #[test] fn excluded_invalid_and_transparent_pixels_do_not_bias_analysis() {
        for px in [[1.0,1.0,1.0,0.0],[f32::NAN,0.1,0.1,1.0]] {
            let c=analyze(std::iter::repeat_n((px,1.0),64),"autoTone");
            assert_eq!(c.gain,1.0); assert_eq!(c.wb,[1.0;3]);
        }
        let c=analyze(std::iter::repeat_n(([0.1,0.1,0.1,1.0],0.0),64),"autoTone");
        assert_eq!(c.gain,1.0);
    }
    #[test] fn contrast_is_bounded_and_monotonic() {
        let c=analyze((0..256).map(|i| {let v=0.3+i as f32/255.0*0.3;([v,v,v,1.0],1.0)}),"autoContrast");
        assert!(c.contrast>1.0 && c.contrast<=1.12);
        let mut last=0.0;
        for i in 0..256 {let v=apply([i as f32/255.0;3],c)[0];assert!(v>=last && v<=1.0);last=v;}
    }
}
