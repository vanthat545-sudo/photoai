# Photo AI Studio v0.7.16.2 — Tự dọn phiên bản cũ sau khi cài

- Chỉ thay thế `~/Applications/PhotoAI Retouch Preview.app` (xác nhận bundle ID).
- Biên dịch, test, ký ứng dụng, xác minh `codesign`, và yêu cầu mở được app mới trước khi dọn.
- Nếu quá trình cài/mở không đạt, thử khôi phục Preview vừa sao lưu; không xóa các bản cũ.
- Sau khi app mới mở thành công: xóa các `PhotoAI Retouch Preview-backup-YYYYMMDD-HHMMSS-PID.app` đúng bundle ID do bộ cài tạo, kể cả bản cũ của những lần cài trước.
- Dọn `target/` của **chính bộ mã nguồn vừa cài** để giải phóng cache Rust; nếu đặt `CARGO_TARGET_DIR` riêng, giữ nguyên thư mục ấy.
- Không xóa `Photo AI.app`, ảnh, dự án, preset cá nhân, ZIP tải về, mã nguồn, dữ liệu người dùng, hay ứng dụng không cùng bundle ID.
- Việc dọn sau cài đặt không cải thiện thuật toán chỉnh ảnh và không chứng minh các chức năng đã hoàn thiện.
- QA mới: `python3 -m unittest discover -s qa -p 'test_auto_cleanup.py'`.
- CHƯA kiểm chứng quy trình cài/mở trên Mac trong môi trường tạo gói này.
