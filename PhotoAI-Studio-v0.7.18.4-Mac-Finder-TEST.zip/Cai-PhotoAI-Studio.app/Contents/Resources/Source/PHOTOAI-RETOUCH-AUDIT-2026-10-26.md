# Photo AI Retouch — rà soát và giao diện chờ kiểm thử

Ngày: 26/10/2026. Nền: v0.7.8. Đây là mã nguồn ứng viên, KHÔNG phải bản phát hành đã test đạt hay app Mac đã biên dịch.

## Thay đổi trong đợt này
- Thu icon công cụ từ 30 xuống 22 pt; ô công cụ từ 86 xuống 64 pt.
- Kéo thả tab AI Beauty/Pro Retouch hoặc nhãn Bảng chỉnh sửa để tách cả bảng tại vị trí thả chuột. Hai tab vẫn nằm chung một bảng, chưa tách thành hai cửa sổ độc lập.
- Bảng nổi có thanh tiêu đề di chuyển, thay đổi kích thước, thu gọn và nút gắn lại. Khóa Workspace ngăn kéo/thay đổi kích thước.
- Thêm vùng cuộn; giữ các giá trị điều chỉnh theo ID dùng chung khi chuyển giữa dock và bảng nổi. Vị trí/trạng thái mới chỉ lưu trong phiên hiện tại.
- Workspace tùy chỉnh có bảng Retouch nổi để tránh mất toàn bộ Retouch khi đường render bỏ qua dock cũ.
- Thêm icon vector gốc hình nhân vật đội mũ trùm, nhúng vào ứng dụng; không cần font biểu tượng hay tải mạng.
- Bộ cài bắt buộc chạy qa/check-release.sh trước biên dịch và thay app. Một test thất bại hoặc thiếu công cụ sẽ chặn bước tiếp theo.

## Kết quả thực thi
- CHECK-TESTS-v078.py: đạt kiểm tra tĩnh. Chỉ xác nhận một số liên kết mã nguồn và cú pháp shell; không chứng minh retouch hoạt động.
- qa/test_release_gate.py: 4/4 đạt. Ba bài dùng công cụ giả để kiểm tra dừng khi thiếu công cụ, dừng khi engine test lỗi, và thứ tự chạy. Một bài kiểm tra vị trí gọi gate trước build/cài. KHÔNG phải test engine/UI.
- bash -n: cú pháp hai script đạt.
- qa/check-release.sh trên môi trường thật: BLOCKED, exit 2, thiếu cargo. Chưa chạy Rust test, clippy, wasm hay panic_hunt.
- Kiểm thử giao diện kéo tab, khóa workspace và giữ trạng thái: CHƯA CHẠY; các tình huống chấp nhận được liệt kê bên dưới.
- Chưa render UI từ ứng dụng; chưa có ảnh chụp kết quả thật. Không dùng mockup thay bằng chứng.

## Phát hiện còn mở
1. Cao — retouch đồng bộ có thể chặn giao diện khi Vision chậm/treo. ai_auto_retouch.rs: apple_vision dùng ghi stdin và wait_with_output không có timeout; lỗi ghi trả về trước khi kill/wait tiến trình con. Chưa tái hiện trên macOS.
2. Cao — photo_ai_effects.rs: pro_sharpen/skin_pixel/fabric_pixel đọc điểm ảnh lân cận không kiểm tra finite/alpha. Việc bỏ qua tâm pixel không hợp lệ ở vòng ngoài không ngăn NaN/Inf ở hàng xóm ảnh hưởng kết quả. Xác nhận qua đọc mã, chưa chạy test Rust để xác định biểu hiện đầu ra từng độ sâu.
3. Vừa — Rust chỉ chặn tổng 13 triệu pixel, Swift còn chặn mỗi chiều 8000; ảnh dài dưới 13 MP có thể lọt bước Rust rồi bị helper từ chối.
4. Vừa — mặt nhỏ hơn 65 pixel bị bỏ qua; vùng chọn <0.98 bị bỏ qua trong retouch tự động. Đây là điều kiện giới hạn hiện hữu, có thể làm nút xoá mụn không thay đổi ảnh, không chứng minh đó là nguyên nhân trên ảnh của Đô.
5. Vừa — thông báo noChange của AI ghi đè thông báo không nhận diện mặt; strength=0 vẫn có thể hiển thị như lỗi nhận diện/chỉnh sửa.
6. Chặn phát hành — chưa có kết quả compile/native UI; tài liệu docs/architecture.md, docs/development.md, docs/contributing.md mà AGENTS.md tham chiếu vắng trong gói.
7. Bộ cài vẫn là script build cần Rust/Xcode; chưa đáp ứng bản .app độc lập cài bằng click không cần công cụ phát triển.

## Bắt buộc trước phát hành
- Chạy toàn bộ gate trên máy có Rust phù hợp; sửa mọi lỗi compile/test/clippy. Chạy benchmark nếu sửa đường xử lý ảnh.
- Build trên macOS và kiểm thử Apple Vision với ảnh có/không có mặt, ảnh 4032×3024, ảnh quá giới hạn, lớp khóa và vùng chọn mềm.
- So sánh ảnh trước/sau xoá mụn ở 200%; mắt/môi không đổi; undo/redo; lưu/mở lại và xuất ảnh.
- UI: kéo từng tab tới bốn góc và giữa canvas; kéo thanh tiêu đề; thu/phóng cửa sổ; khóa workspace; gắn lại; chuyển Pro/Studio; kiểm tra thanh trượt giữ giá trị, bảng không che mất điều khiển và không sửa ảnh khi kéo.
- Chụp ảnh màn hình thật của dock gọn và bảng nổi có icon. Hiện mục này CHƯA ĐẠT.

Không xác nhận đã sửa xong lỗi xoá mụn. Các thay đổi xử lý ảnh chưa được thực hiện trong đợt UI/gate này.
