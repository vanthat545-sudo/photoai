# PhotoAI v0.7 — Auto AI Retouch (experimental)

## What this release implements
- **Real face, eye and mouth localization by Apple's Vision ML** (macOS offline), via `native/macos/PhotoAIVision.swift` helper. No internet access or model download at runtime.
- **One-button orchestration** (`paint.aiAutoRetouch`) within one undo action: find faces, locate likely red blemishes, run existing spot-healing, smooth skin within safe facial masks, optionally brighten beneath eyes.
- **Modes**: Natural, Portrait, Skin only; intensity slider 0–100; no manual lasso needed on raster layer.
- **Safety**: do not edit outside detected faces; skip eye/lip landmarks and (if missing) broad vulnerable zones; respect manual selection if present; cap input at 12 MP; no geometric reshaping; preserve original alpha; allow Undo.
- Mac install script compiles the helper via `swiftc`, the app via `cargo`, signs both locally, backs up previous `~/Applications/PhotoAI.app`, installs without deleting user projects.

## What is NOT implemented
- Acne itself is **not recognized by a trained ML blemish model**. The existing red-spot detector and classical repair remain approximate; severe acne, scars, dark spots, variable lighting and dark/very light skin tones need better model/data tests.
- No cloud AI, generative restoration, automatic lipstick, automatic body manipulation, hair segmentation or semantic clothing repair.
- Cannot claim equivalence with a generated Before/After UI image.
- This modifies the **separate PhotoAI Retouch project**, not the distinct camera-icon Photo AI program (its source/app was not provided).

## Validation matrix
| Item | Status |
|---|---|
| Swift source parses with `swiftc -frontend -parse` | PASS in Linux Swift parser (NOT macOS Vision type/link check) |
| Installer syntax `bash -n` | PASS |
| Rust command referenced by UI and registered | PASS static check |
| Bundled icons referenced exist | PASS static check |
| ZIP integrity | PASS |
| Rust compile/tests on macOS | NOT RUN — Rust unavailable in this environment |
| Swift compile/link with macOS Vision | NOT RUN — macOS SDK unavailable here |
| Open PhotoAI.app on M1 | NOT RUN |
| Real portrait accuracy + visual comparison | NOT RUN |
| One-step Undo integration | Implemented, runtime not verified |

After building, `Test-AI-AutoRetouch-Mac.command` runs Rust unit tests and a blank-frame Apple Vision smoke test. This is not a real-portrait quality test.

## Repro steps on Mac
1. Back up valuable images and projects separately.
2. Extract ZIP; run `Build-and-Install-PhotoAI-Mac.command` (Rust and Xcode Command Line Tools required).
3. Open a copied portrait with a **selected unlocked pixel layer**; use **AI Beauty → AI TỰ ĐỘNG CHỈNH**; choose mode Natural/Portrait/Skin only.
4. Check status: detected faces, spots actually healed, smoothed pixels, under-eye pixels. Compare at 100% and use Command-Z.
5. Run `cargo test -p photocraft-engine --lib ai_auto_retouch` in the source directory if compilation works; paste all errors if it fails. Build must complete before the old app is replaced.
