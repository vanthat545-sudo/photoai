# PhotoAI 0.6.2 – Retouch tabs

- AI Beauty tab: manual skin tools, bounded auto-blemish region detection, lipstick and contour, under-eye, eyelid, iris colour, face slimming (selection required where shown).
- Pro Retouch tab: 25 colour presets, brightness, fabric wrinkle smoothing.
- Tabs preserve original existing commands, parameters and shared strength/colour state.
- No automatic leg stretching or AI face parsing is claimed. No automated full face AI is added.
- Static source validation only; no Rust toolchain/macOS runtime in delivery environment. Run on Mac to confirm compilation, appearance, editing and undo.
